import { View, Text, StyleSheet } from 'react-native';
import { Colors, Fonts, Spacing, Radius } from '@/constants/theme';

type BadgeVariant = 'primary' | 'success' | 'warning' | 'error' | 'neutral' | 'teal';

interface BadgeProps {
  label: string;
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
}

export default function Badge({ label, variant = 'primary', size = 'sm' }: BadgeProps) {
  return (
    <View style={[styles.base, styles[variant], size === 'md' && styles.sizeMd]}>
      <Text style={[styles.text, styles[`text_${variant}`], size === 'md' && styles.textMd]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  base: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: Radius.full,
    alignSelf: 'flex-start',
  },
  sizeMd: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
  },
  primary: { backgroundColor: Colors.primary[50] },
  success: { backgroundColor: Colors.success[50] },
  warning: { backgroundColor: Colors.warning[50] },
  error: { backgroundColor: Colors.error[50] },
  neutral: { backgroundColor: Colors.neutral[100] },
  teal: { backgroundColor: Colors.teal[50] },

  text: {
    fontFamily: Fonts.medium,
    fontSize: 11,
    letterSpacing: 0.3,
  },
  textMd: { fontSize: 13 },
  text_primary: { color: Colors.primary[600] },
  text_success: { color: Colors.success[700] },
  text_warning: { color: Colors.warning[700] },
  text_error: { color: Colors.error[700] },
  text_neutral: { color: Colors.neutral[600] },
  text_teal: { color: Colors.teal[600] },
});
