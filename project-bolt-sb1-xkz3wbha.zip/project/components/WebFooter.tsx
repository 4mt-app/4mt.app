import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing } from '@/constants/theme';
import { Shield } from 'lucide-react-native';

export default function WebFooter() {
  if (Platform.OS !== 'web') return null;

  return (
    <View style={styles.footer}>
      <View style={styles.inner}>
        <View style={styles.topRow}>
          <View style={styles.brand}>
            <View style={styles.logoMark}>
              <Text style={styles.logoMarkText}>4MT</Text>
            </View>
            <Text style={styles.brandName}>For My Transition</Text>
            <Text style={styles.brandDesc}>
              La plateforme tout-en-un pour anticiper sa fin de vie avec sérénité et transmettre ce qui compte.
            </Text>
            <View style={styles.securityBadge}>
              <Shield size={14} color={Colors.success[500]} strokeWidth={1.5} />
              <Text style={styles.securityText}>Données chiffrées · RGPD · Hébergé en France</Text>
            </View>
          </View>

          <View style={styles.linksGroup}>
            <Text style={styles.linksTitle}>Particuliers</Text>
            <Text style={styles.link}>Mon compte</Text>
            <Text style={styles.link}>Mes volontés</Text>
            <Text style={styles.link}>Héritage émotionnel</Text>
            <Text style={styles.link}>Questionnaire IA</Text>
          </View>

          <View style={styles.linksGroup}>
            <Text style={styles.linksTitle}>Professionnels</Text>
            <Text style={styles.link}>Pompes funèbres</Text>
            <Text style={styles.link}>Notaires</Text>
            <Text style={styles.link}>Assurances</Text>
            <Text style={styles.link}>Mairies</Text>
          </View>

          <View style={styles.linksGroup}>
            <Text style={styles.linksTitle}>Informations</Text>
            <Text style={styles.link}>À propos</Text>
            <Text style={styles.link}>Tarifs</Text>
            <Text style={styles.link}>Sécurité</Text>
            <Text style={styles.link}>Contact</Text>
          </View>
        </View>

        <View style={styles.bottomRow}>
          <Text style={styles.copyright}>© 2026 4MT — For My Transition. Tous droits réservés.</Text>
          <View style={styles.legalLinks}>
            <Text style={styles.legalLink}>Mentions légales</Text>
            <Text style={styles.legalDot}>·</Text>
            <Text style={styles.legalLink}>CGU</Text>
            <Text style={styles.legalDot}>·</Text>
            <Text style={styles.legalLink}>Confidentialité</Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  footer: {
    backgroundColor: Colors.neutral[900],
    paddingTop: 64,
    paddingBottom: Spacing.xl,
  },
  inner: {
    maxWidth: 1200,
    alignSelf: 'center',
    width: '100%',
    paddingHorizontal: Spacing.xl,
  },
  topRow: {
    flexDirection: 'row',
    gap: 48,
    flexWrap: 'wrap',
    marginBottom: 48,
  },
  brand: {
    flex: 2,
    gap: Spacing.md,
    minWidth: 200,
  },
  logoMark: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoMarkText: {
    fontFamily: Fonts.bold,
    fontSize: 16,
    color: '#fff',
    letterSpacing: 0.5,
  },
  brandName: {
    fontFamily: Fonts.bold,
    fontSize: 18,
    color: Colors.neutral[0],
  },
  brandDesc: {
    fontFamily: Fonts.regular,
    fontSize: 14,
    color: Colors.neutral[400],
    lineHeight: 22,
    maxWidth: 280,
  },
  securityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: Spacing.xs,
  },
  securityText: {
    fontFamily: Fonts.medium,
    fontSize: 12,
    color: Colors.neutral[400],
  },
  linksGroup: {
    flex: 1,
    gap: Spacing.sm,
    minWidth: 130,
  },
  linksTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 13,
    color: Colors.neutral[200],
    marginBottom: Spacing.xs,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  link: {
    fontFamily: Fonts.regular,
    fontSize: 14,
    color: Colors.neutral[500],
  },
  bottomRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[800],
    paddingTop: Spacing.lg,
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  copyright: {
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: Colors.neutral[600],
  },
  legalLinks: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  legalLink: {
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: Colors.neutral[500],
  },
  legalDot: {
    color: Colors.neutral[700],
  },
});
