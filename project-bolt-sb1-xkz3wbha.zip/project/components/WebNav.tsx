import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { useRouter, usePathname } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import { Shield, Menu, X } from 'lucide-react-native';
import { useState } from 'react';

const navLinks = [
  { label: 'Accueil', href: '/web' },
  { label: 'Mon espace', href: '/web/dashboard' },
  { label: 'Professionnels', href: '/web/pro' },
  { label: 'Confiance', href: '/web/confiance' },
  { label: 'Démo', href: '/web/demo', isDemo: true },
];

export default function WebNav() {
  const router = useRouter();
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);

  if (Platform.OS !== 'web') return null;

  return (
    <View style={styles.nav}>
      <View style={styles.inner}>
        {/* Logo */}
        <TouchableOpacity onPress={() => router.push('/web' as any)} style={styles.logo} activeOpacity={0.8}>
          <View style={styles.logoMark}>
            <Text style={styles.logoMarkText}>4MT</Text>
          </View>
          <View>
            <Text style={styles.logoName}>For My Transition</Text>
            <Text style={styles.logoTag}>Votre héritage, sécurisé</Text>
          </View>
        </TouchableOpacity>

        {/* Nav links */}
        <View style={styles.desktopLinks}>
          {navLinks.map((link) => {
            const isActive = pathname === link.href;
            if ((link as any).isDemo) {
              return (
                <TouchableOpacity
                  key={link.href}
                  onPress={() => router.push(link.href as any)}
                  activeOpacity={0.7}
                  style={styles.demoNavLink}
                >
                  <Text style={styles.demoNavLinkText}>Démo</Text>
                </TouchableOpacity>
              );
            }
            return (
              <TouchableOpacity
                key={link.href}
                onPress={() => router.push(link.href as any)}
                activeOpacity={0.7}
                style={[styles.navLink, isActive && styles.navLinkActive]}
              >
                <Text style={[styles.navLinkText, isActive && styles.navLinkTextActive]}>
                  {link.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* CTA buttons */}
        <View style={styles.ctaRow}>
          <TouchableOpacity
            onPress={() => router.push('/auth/login' as any)}
            style={styles.loginBtn}
            activeOpacity={0.8}
          >
            <Text style={styles.loginBtnText}>Connexion</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push('/auth/register' as any)}
            style={styles.registerBtn}
            activeOpacity={0.85}
          >
            <Text style={styles.registerBtnText}>Commencer gratuitement</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Mobile menu drawer */}
      {menuOpen && (
        <View style={styles.mobileMenu}>
          {navLinks.map((link) => (
            <TouchableOpacity
              key={link.href}
              onPress={() => { router.push(link.href as any); setMenuOpen(false); }}
              style={styles.mobileLink}
              activeOpacity={0.7}
            >
              <Text style={styles.mobileLinkText}>{link.label}</Text>
            </TouchableOpacity>
          ))}
          <View style={styles.mobileCtas}>
            <TouchableOpacity onPress={() => router.push('/auth/login' as any)} style={[styles.loginBtn, { flex: 1 }]} activeOpacity={0.8}>
              <Text style={styles.loginBtnText}>Connexion</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => router.push('/auth/register' as any)} style={[styles.registerBtn, { flex: 1 }]} activeOpacity={0.85}>
              <Text style={styles.registerBtnText}>Créer un compte</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  nav: {
    backgroundColor: Colors.neutral[0],
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
    zIndex: 100,
    ...Shadow.sm,
  },
  inner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    maxWidth: 1200,
    alignSelf: 'center',
    width: '100%',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  logo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  logoMark: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoMarkText: {
    fontFamily: Fonts.bold,
    fontSize: 16,
    color: '#fff',
    letterSpacing: 0.5,
  },
  logoName: {
    fontFamily: Fonts.bold,
    fontSize: 16,
    color: Colors.neutral[800],
  },
  logoTag: {
    fontFamily: Fonts.regular,
    fontSize: 11,
    color: Colors.neutral[400],
  },
  desktopLinks: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    flexWrap: 'wrap',
  },
  navLink: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.sm,
  },
  navLinkActive: {
    backgroundColor: Colors.primary[50],
  },
  navLinkText: {
    fontFamily: Fonts.medium,
    fontSize: 14,
    color: Colors.neutral[600],
  },
  navLinkTextActive: {
    color: Colors.primary[600],
  },
  ctaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  loginBtn: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.sm,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
    alignItems: 'center',
  },
  loginBtnText: {
    fontFamily: Fonts.medium,
    fontSize: 14,
    color: Colors.neutral[700],
  },
  registerBtn: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.sm,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
  },
  registerBtnText: {
    fontFamily: Fonts.semiBold,
    fontSize: 14,
    color: '#fff',
  },
  mobileMenu: {
    backgroundColor: Colors.neutral[0],
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    gap: Spacing.xs,
  },
  mobileLink: {
    paddingVertical: Spacing.sm + 2,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  mobileLinkText: {
    fontFamily: Fonts.medium,
    fontSize: 15,
    color: Colors.neutral[700],
  },
  mobileCtas: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginTop: Spacing.sm,
  },
  demoNavLink: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.sm,
    backgroundColor: Colors.primary[500],
  },
  demoNavLinkText: {
    fontFamily: Fonts.semiBold,
    fontSize: 14,
    color: '#fff',
  },
});