import { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Dimensions, TextInput
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import Card from '@/components/Card';
import Button from '@/components/Button';
import ProgressBar from '@/components/ProgressBar';
import { X, Sparkles, ChevronRight, ChevronLeft, CircleCheck } from 'lucide-react-native';

const { width } = Dimensions.get('window');

type Question = {
  id: string;
  step: number;
  category: string;
  question: string;
  type: 'single' | 'multi' | 'text' | 'scale';
  options?: { value: string; label: string; emoji?: string }[];
  placeholder?: string;
};

const questions: Question[] = [
  {
    id: 'belief',
    step: 1,
    category: 'Croyances',
    question: 'Quelle orientation spirituelle ou philosophique vous correspond ?',
    type: 'single',
    options: [
      { value: 'laique', label: 'Laïque', emoji: '🤝' },
      { value: 'catholique', label: 'Catholique', emoji: '⛪' },
      { value: 'protestant', label: 'Protestant', emoji: '✝️' },
      { value: 'musulman', label: 'Musulman', emoji: '☪️' },
      { value: 'juif', label: 'Juif', emoji: '✡️' },
      { value: 'bouddhiste', label: 'Bouddhiste', emoji: '☸️' },
      { value: 'spirituel', label: 'Spirituel non-religieux', emoji: '🌿' },
      { value: 'autre', label: 'Autre / Je ne sais pas', emoji: '💭' },
    ],
  },
  {
    id: 'ambiance',
    step: 2,
    category: 'Ambiance',
    question: 'Quelle ambiance souhaiteriez-vous pour votre cérémonie ?',
    type: 'multi',
    options: [
      { value: 'intime', label: 'Intime et recueillie', emoji: '🕯️' },
      { value: 'joyeuse', label: 'Joyeuse et célébratoire', emoji: '🌸' },
      { value: 'nature', label: 'Proche de la nature', emoji: '🌿' },
      { value: 'sobre', label: 'Simple et sobre', emoji: '⬜' },
      { value: 'musicale', label: 'Musicale et artistique', emoji: '🎵' },
      { value: 'familiale', label: 'Familiale et chaleureuse', emoji: '🏡' },
    ],
  },
  {
    id: 'location',
    step: 3,
    category: 'Lieu',
    question: 'Quel type de lieu vous correspond le mieux ?',
    type: 'single',
    options: [
      { value: 'religieux', label: 'Lieu de culte', emoji: '⛪' },
      { value: 'nature', label: 'En pleine nature', emoji: '🌲' },
      { value: 'laique', label: 'Espace laïque (salle)', emoji: '🏛️' },
      { value: 'symbolique', label: 'Lieu symbolique personnel', emoji: '📍' },
      { value: 'crematorium', label: 'Crématorium', emoji: '🕊️' },
      { value: 'indefini', label: 'Pas de préférence', emoji: '💭' },
    ],
  },
  {
    id: 'music',
    step: 4,
    category: 'Musique',
    question: 'Quel style musical correspond le mieux à ce que vous souhaitez partager ?',
    type: 'multi',
    options: [
      { value: 'classique', label: 'Classique', emoji: '🎻' },
      { value: 'jazz', label: 'Jazz / Soul', emoji: '🎷' },
      { value: 'pop', label: 'Pop / Rock', emoji: '🎸' },
      { value: 'folk', label: 'Folk / Acoustique', emoji: '🎵' },
      { value: 'spirituel', label: 'Chants spirituels', emoji: '🙏' },
      { value: 'mondial', label: 'Musique du monde', emoji: '🌍' },
    ],
  },
  {
    id: 'values',
    step: 5,
    category: 'Valeurs',
    question: 'Quelles valeurs souhaitez-vous transmettre à vos proches ?',
    type: 'multi',
    options: [
      { value: 'amour', label: 'Amour et liens familiaux', emoji: '❤️' },
      { value: 'liberte', label: 'Liberté et authenticité', emoji: '🕊️' },
      { value: 'nature', label: 'Respect de la nature', emoji: '🌱' },
      { value: 'joie', label: 'Légèreté et joie de vivre', emoji: '😊' },
      { value: 'foi', label: 'Foi et espérance', emoji: '✨' },
      { value: 'gratitude', label: 'Gratitude et paix', emoji: '🙏' },
    ],
  },
  {
    id: 'message',
    step: 6,
    category: 'Message final',
    question: 'Y a-t-il un message ou une intention particulière que vous souhaitez partager avec vos proches ?',
    type: 'text',
    placeholder: 'Écrivez librement ce que vous souhaitez leur transmettre...',
  },
];

const TOTAL_STEPS = questions.length;

export default function QuestionnaireScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});
  const [showResult, setShowResult] = useState(false);

  const question = questions[currentStep];
  const answer = answers[question.id];
  const progress = (currentStep + 1) / TOTAL_STEPS;

  const isAnswered = () => {
    if (!answer) return false;
    if (Array.isArray(answer)) return answer.length > 0;
    return answer.trim().length > 0;
  };

  const toggleSingle = (val: string) => {
    setAnswers(prev => ({ ...prev, [question.id]: val }));
  };

  const toggleMulti = (val: string) => {
    const current = (answers[question.id] as string[]) || [];
    const updated = current.includes(val)
      ? current.filter(v => v !== val)
      : [...current, val];
    setAnswers(prev => ({ ...prev, [question.id]: updated }));
  };

  const handleNext = () => {
    if (currentStep < TOTAL_STEPS - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowResult(true);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) setCurrentStep(currentStep - 1);
  };

  if (showResult) {
    return <QuestionnaireResult onClose={() => router.back()} insets={insets} />;
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeBtn} activeOpacity={0.7}>
          <X size={20} color={Colors.neutral[600]} strokeWidth={2} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerCategory}>{question.category}</Text>
          <Text style={styles.headerStep}>{currentStep + 1} / {TOTAL_STEPS}</Text>
        </View>
        <View style={{ width: 36 }} />
      </View>

      <ProgressBar progress={progress} color={Colors.primary[500]} height={4} />

      <View style={styles.aiChip}>
        <Sparkles size={13} color={Colors.primary[500]} strokeWidth={1.5} />
        <Text style={styles.aiChipText}>Guidé par l'intelligence artificielle</Text>
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.question}>{question.question}</Text>

        {question.type === 'single' && question.options && (
          <View style={styles.optionsGrid}>
            {question.options.map((opt) => {
              const isSelected = answer === opt.value;
              return (
                <TouchableOpacity
                  key={opt.value}
                  style={[styles.optionChip, isSelected && styles.optionChipSelected]}
                  onPress={() => toggleSingle(opt.value)}
                  activeOpacity={0.75}
                >
                  {opt.emoji && <Text style={styles.optionEmoji}>{opt.emoji}</Text>}
                  <Text style={[styles.optionLabel, isSelected && styles.optionLabelSelected]}>
                    {opt.label}
                  </Text>
                  {isSelected && (
                    <View style={styles.optionCheck}>
                      <CircleCheck size={14} color={Colors.primary[500]} strokeWidth={2} />
                    </View>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {question.type === 'multi' && question.options && (
          <View style={styles.optionsGrid}>
            {question.options.map((opt) => {
              const isSelected = Array.isArray(answer) && answer.includes(opt.value);
              return (
                <TouchableOpacity
                  key={opt.value}
                  style={[styles.optionChip, isSelected && styles.optionChipSelected]}
                  onPress={() => toggleMulti(opt.value)}
                  activeOpacity={0.75}
                >
                  {opt.emoji && <Text style={styles.optionEmoji}>{opt.emoji}</Text>}
                  <Text style={[styles.optionLabel, isSelected && styles.optionLabelSelected]}>
                    {opt.label}
                  </Text>
                  {isSelected && (
                    <View style={styles.optionCheck}>
                      <CircleCheck size={14} color={Colors.primary[500]} strokeWidth={2} />
                    </View>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {question.type === 'text' && (
          <TextInput
            style={styles.textArea}
            placeholder={question.placeholder}
            placeholderTextColor={Colors.neutral[400]}
            value={(answer as string) || ''}
            onChangeText={val => setAnswers(prev => ({ ...prev, [question.id]: val }))}
            multiline
            numberOfLines={6}
            textAlignVertical="top"
          />
        )}
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: insets.bottom + Spacing.md }]}>
        <TouchableOpacity
          onPress={handlePrev}
          disabled={currentStep === 0}
          style={[styles.prevBtn, currentStep === 0 && styles.prevBtnDisabled]}
          activeOpacity={0.7}
        >
          <ChevronLeft size={20} color={currentStep === 0 ? Colors.neutral[300] : Colors.neutral[600]} strokeWidth={2} />
        </TouchableOpacity>

        <Button
          label={currentStep === TOTAL_STEPS - 1 ? 'Voir ma recommandation IA' : 'Continuer'}
          onPress={handleNext}
          variant="primary"
          size="lg"
          style={styles.nextBtn}
          disabled={!isAnswered()}
        />
      </View>
    </View>
  );
}

function QuestionnaireResult({ onClose, insets }: { onClose: () => void; insets: any }) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.resultContent, { paddingTop: insets.top + Spacing.md }]}
    >
      <View style={styles.resultHeader}>
        <View style={styles.resultAiIcon}>
          <Sparkles size={32} color={Colors.primary[500]} strokeWidth={1.5} />
        </View>
        <Text style={styles.resultTitle}>Votre recommandation IA</Text>
        <Text style={styles.resultSub}>Basée sur vos réponses, voici notre suggestion personnalisée</Text>
      </View>

      <Card variant="elevated" style={styles.resultMain}>
        <Text style={styles.resultSectionLabel}>Type de cérémonie suggéré</Text>
        <Text style={styles.resultHighlight}>Cérémonie laïque en plein air</Text>
        <Text style={styles.resultText}>
          Sobre, intime et proche de la nature. Une cérémonie sans protocole religieux, axée sur le partage et la mémoire.
        </Text>
      </Card>

      <Card variant="default" style={styles.resultSection}>
        <Text style={styles.resultSectionLabel}>Lieu recommandé</Text>
        <Text style={styles.resultItem}>🌲 Espace naturel (forêt, jardin, parc)</Text>
        <Text style={styles.resultItem}>🏛️ Salle de réception laïque comme alternative</Text>
      </Card>

      <Card variant="default" style={styles.resultSection}>
        <Text style={styles.resultSectionLabel}>Ambiance musicale</Text>
        <Text style={styles.resultItem}>🎵 Musique acoustique / folk douce</Text>
        <Text style={styles.resultItem}>🎻 Quelques notes de musique classique apaisante</Text>
      </Card>

      <Card variant="default" style={styles.resultSection}>
        <Text style={styles.resultSectionLabel}>Textes & lectures suggérés</Text>
        <Text style={styles.resultItem}>📖 Poème de Pablo Neruda — "Je veux faire avec toi"</Text>
        <Text style={styles.resultItem}>📖 Extrait de "Le Petit Prince" — l'essentiel est invisible</Text>
      </Card>

      <Card variant="tinted">
        <Text style={styles.resultNote}>
          Ces suggestions sont des orientations, pas des obligations. Vous pouvez les modifier librement dans la section "Funérailles".
        </Text>
      </Card>

      <View style={styles.resultActions}>
        <Button label="Appliquer ces suggestions" onPress={onClose} variant="primary" size="lg" fullWidth />
        <Button label="Revenir plus tard" onPress={onClose} variant="ghost" size="md" fullWidth />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[0] },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
  },
  closeBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerCenter: { alignItems: 'center' },
  headerCategory: { fontFamily: Fonts.semiBold, fontSize: 15, color: Colors.neutral[800] },
  headerStep: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[400], marginTop: 2 },

  aiChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    alignSelf: 'center',
    backgroundColor: Colors.primary[50],
    borderRadius: Radius.full,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    marginTop: Spacing.md,
    marginBottom: Spacing.xs,
  },
  aiChipText: { fontFamily: Fonts.medium, fontSize: 12, color: Colors.primary[600] },

  scroll: { flex: 1 },
  scrollContent: { padding: Spacing.lg, paddingTop: Spacing.md },

  question: {
    fontFamily: Fonts.bold,
    fontSize: 22,
    color: Colors.neutral[800],
    lineHeight: 30,
    marginBottom: Spacing.xl,
  },

  optionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  optionChip: {
    width: (width - Spacing.lg * 2 - Spacing.sm) / 2,
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
    padding: Spacing.md,
    gap: 6,
    position: 'relative',
  },
  optionChipSelected: {
    borderColor: Colors.primary[400],
    backgroundColor: Colors.primary[50],
  },
  optionEmoji: { fontSize: 24 },
  optionLabel: {
    fontFamily: Fonts.medium,
    fontSize: 13,
    color: Colors.neutral[700],
    lineHeight: 17,
  },
  optionLabelSelected: { color: Colors.primary[700] },
  optionCheck: { position: 'absolute', top: 8, right: 8 },

  textArea: {
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
    padding: Spacing.md,
    fontFamily: Fonts.regular,
    fontSize: 15,
    color: Colors.neutral[800],
    minHeight: 150,
    lineHeight: 22,
  },

  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
    backgroundColor: Colors.neutral[0],
  },
  prevBtn: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  prevBtnDisabled: { opacity: 0.4 },
  nextBtn: { flex: 1 },

  resultContent: { padding: Spacing.lg, gap: Spacing.md },
  resultHeader: { alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.md },
  resultAiIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  resultTitle: { fontFamily: Fonts.bold, fontSize: 24, color: Colors.neutral[800], textAlign: 'center' },
  resultSub: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[500], textAlign: 'center', lineHeight: 20 },
  resultMain: { gap: Spacing.sm },
  resultSection: { gap: Spacing.sm },
  resultSectionLabel: { fontFamily: Fonts.semiBold, fontSize: 12, color: Colors.neutral[400], textTransform: 'uppercase', letterSpacing: 0.8 },
  resultHighlight: { fontFamily: Fonts.bold, fontSize: 18, color: Colors.primary[600] },
  resultText: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[600], lineHeight: 20 },
  resultItem: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[700], lineHeight: 22 },
  resultNote: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.primary[600], lineHeight: 19 },
  resultActions: { gap: Spacing.xs, marginTop: Spacing.md },
});
