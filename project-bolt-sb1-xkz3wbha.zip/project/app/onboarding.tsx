import { useState } from 'react';
import { View, Text, StyleSheet, Dimensions, TouchableOpacity, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Fonts, Spacing, Radius } from '@/constants/theme';
import Button from '@/components/Button';
import { Heart, FileText, Shield, Users, Sparkles, ChevronRight } from 'lucide-react-native';

const { width, height } = Dimensions.get('window');

const slides = [
  {
    icon: Heart,
    iconColor: Colors.teal[400],
    iconBg: Colors.teal[50],
    title: 'Un héritage\némotionnel',
    body: 'Laissez des messages, vidéos et enregistrements audio à ceux que vous aimez. Ces trésors resteront accessibles après votre départ.',
    accent: Colors.teal[500],
  },
  {
    icon: Sparkles,
    iconColor: Colors.primary[500],
    iconBg: Colors.primary[50],
    title: 'Guidé par\nl\'intelligence artificielle',
    body: 'Notre questionnaire IA vous aide à organiser vos funérailles selon vos croyances, vos valeurs et vos préférences, à votre rythme.',
    accent: Colors.primary[500],
  },
  {
    icon: FileText,
    iconColor: Colors.sage[600],
    iconBg: Colors.sage[50],
    title: 'Démarches\nadministratives simplifiées',
    body: 'Vos volontés sont transmises automatiquement aux organismes concernés : banques, assurances, mairie, notaire...',
    accent: Colors.sage[600],
  },
  {
    icon: Shield,
    iconColor: Colors.primary[600],
    iconBg: Colors.primary[50],
    title: 'Sécurité\net confidentialité',
    body: 'Données chiffrées, accès contrôlés, conformité RGPD. Seule votre personne de confiance peut activer votre dossier.',
    accent: Colors.primary[600],
  },
  {
    icon: Users,
    iconColor: Colors.teal[600],
    iconBg: Colors.teal[50],
    title: 'Accessible\nà tous',
    body: 'Synthèse vocale, sous-titres, navigation simplifiée. L\'application est conçue pour être utilisée par chacun, sans exception.',
    accent: Colors.teal[600],
  },
];

export default function OnboardingScreen() {
  const [current, setCurrent] = useState(0);
  const router = useRouter();

  const slide = slides[current];
  const Icon = slide.icon;
  const isLast = current === slides.length - 1;

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[Colors.neutral[50], Colors.neutral[0]]}
        style={styles.bg}
      />

      <View style={styles.skipRow}>
        <TouchableOpacity onPress={() => router.push('/auth/register')} activeOpacity={0.7}>
          <Text style={styles.skip}>Passer</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.main}>
        <View style={[styles.iconWrap, { backgroundColor: slide.iconBg }]}>
          <Icon size={44} color={slide.iconColor} strokeWidth={1.5} />
        </View>

        <Text style={styles.title}>{slide.title}</Text>
        <Text style={styles.body}>{slide.body}</Text>
      </View>

      <View style={styles.dots}>
        {slides.map((_, i) => (
          <View
            key={i}
            style={[
              styles.dot,
              i === current
                ? [styles.dotActive, { backgroundColor: slide.accent }]
                : styles.dotInactive,
            ]}
          />
        ))}
      </View>

      <View style={styles.actions}>
        {isLast ? (
          <Button
            label="Créer mon compte"
            onPress={() => router.push('/auth/register')}
            variant="primary"
            size="lg"
            fullWidth
          />
        ) : (
          <Button
            label="Suivant"
            onPress={() => setCurrent(current + 1)}
            variant="primary"
            size="lg"
            fullWidth
          />
        )}
        {current > 0 && (
          <Button
            label="Précédent"
            onPress={() => setCurrent(current - 1)}
            variant="ghost"
            size="md"
            fullWidth
          />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[0] },
  bg: { position: 'absolute', width, height },
  skipRow: {
    paddingTop: 60,
    paddingHorizontal: Spacing.lg,
    alignItems: 'flex-end',
  },
  skip: {
    fontFamily: Fonts.medium,
    fontSize: 15,
    color: Colors.neutral[500],
  },
  main: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.xl,
  },
  iconWrap: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.xl,
  },
  title: {
    fontFamily: Fonts.bold,
    fontSize: 30,
    color: Colors.neutral[800],
    textAlign: 'center',
    lineHeight: 38,
    marginBottom: Spacing.md,
  },
  body: {
    fontFamily: Fonts.regular,
    fontSize: 16,
    color: Colors.neutral[500],
    textAlign: 'center',
    lineHeight: 25,
    maxWidth: 340,
  },
  dots: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    marginBottom: Spacing.xl,
  },
  dot: {
    height: 6,
    borderRadius: 3,
  },
  dotActive: {
    width: 24,
  },
  dotInactive: {
    width: 6,
    backgroundColor: Colors.neutral[300],
  },
  actions: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: 48,
    gap: Spacing.xs,
  },
});
