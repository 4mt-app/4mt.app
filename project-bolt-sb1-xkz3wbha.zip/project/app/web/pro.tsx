import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import Card from '@/components/Card';
import Badge from '@/components/Badge';
import {
  Building2, Scale, Landmark, FileText, ChevronRight,
  CircleCheck, Clock, Bell, Upload, Search, Shield,
  Users, Send, TriangleAlert as AlertTriangle, Plus
} from 'lucide-react-native';
import { useDemo } from '@/lib/demoContext';

type ProfType = 'funeraire' | 'notaire' | 'assurance' | 'mairie';

const profTypes: { key: ProfType; label: string; icon: any; desc: string }[] = [
  { key: 'funeraire', label: 'Pompes funèbres', icon: Building2, desc: 'Déclarer un décès, activer un dossier' },
  { key: 'notaire', label: 'Notaire', icon: Scale, desc: 'Accéder aux volontés, gérer la succession' },
  { key: 'assurance', label: 'Assurance', icon: Landmark, desc: 'Déclencher les assurances décès' },
  { key: 'mairie', label: 'Mairie', icon: FileText, desc: 'Transmettre l\'acte de décès' },
];

const recentDossiers = [
  { id: 'D-2026-0091', name: 'Henri Moreau', date: '22 avril 2026', status: 'active', trust: 'Pauline Moreau' },
  { id: 'D-2026-0088', name: 'Simone Legrand', date: '18 avril 2026', status: 'pending', trust: 'Marc Legrand' },
  { id: 'D-2026-0082', name: 'Robert Faure', date: '10 avril 2026', status: 'complete', trust: 'Sophie Faure' },
];

const statusConfig = {
  active: { label: 'En cours', badge: 'warning' as const },
  pending: { label: 'En attente', badge: 'neutral' as const },
  complete: { label: 'Traité', badge: 'success' as const },
};

const stats = [
  { value: '12', label: 'Dossiers actifs', color: Colors.primary[500] },
  { value: '3', label: 'En attente', color: Colors.warning[500] },
  { value: '47', label: 'Traités ce mois', color: Colors.success[500] },
  { value: '98%', label: 'Taux de satisfaction', color: Colors.teal[500] },
];

export default function WebProPage() {
  const router = useRouter();
  const { isDemo } = useDemo();
  const [selectedType, setSelectedType] = useState<ProfType>('funeraire');
  const [view, setView] = useState<'landing' | 'dashboard'>('landing');

  if (view === 'dashboard' || isDemo) {
    return <ProDashboard onLogout={() => setView('landing')} />;
  }

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Bandeau prototype */}
      <View style={styles.demoBanner}>
        <AlertTriangle size={13} color={Colors.warning[700]} strokeWidth={1.5} />
        <Text style={styles.demoBannerText}>Prototype · Espace professionnel en cours de développement — les fonctionnalités sont simulées</Text>
      </View>

      {/* Hero */}
      <View style={styles.hero}>
        <View style={styles.heroBadge}>
          <Shield size={13} color={Colors.teal[300]} strokeWidth={1.5} />
          <Text style={styles.heroBadgeText}>Interface B2B sécurisée · Accès professionnel</Text>
        </View>
        <Text style={styles.heroTitle}>Espace professionnel 4MT</Text>
        <Text style={styles.heroSub}>
          Déclarez des décès, activez des dossiers, transmettez des documents — le tout depuis une interface sécurisée et centralisée.
        </Text>
      </View>

      {/* Type selector */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Je suis...</Text>
        <View style={styles.typeGrid}>
          {profTypes.map((t) => {
            const Icon = t.icon;
            const isSelected = selectedType === t.key;
            return (
              <TouchableOpacity
                key={t.key}
                style={[styles.typeCard, isSelected && styles.typeCardSelected]}
                onPress={() => setSelectedType(t.key)}
                activeOpacity={0.8}
              >
                <View style={[styles.typeIcon, isSelected && styles.typeIconSelected]}>
                  <Icon size={24} color={isSelected ? Colors.primary[500] : Colors.neutral[500]} strokeWidth={1.5} />
                </View>
                <Text style={[styles.typeLabel, isSelected && styles.typeLabelSelected]}>{t.label}</Text>
                <Text style={styles.typeDesc}>{t.desc}</Text>
                {isSelected && (
                  <View style={styles.typeCheckWrap}>
                    <CircleCheck size={16} color={Colors.primary[500]} strokeWidth={2} />
                  </View>
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      {/* Features for pro */}
      <View style={[styles.section, styles.sectionAlt]}>
        <Text style={styles.sectionTitle}>Ce que vous pouvez faire</Text>
        <View style={styles.featuresGrid}>
          {[
            { icon: FileText, title: 'Déclarer un décès', desc: 'Saisie rapide et sécurisée d\'un décès avec validation de l\'identité.' },
            { icon: Shield, title: 'Activer un dossier 4MT', desc: 'Accès contrôlé aux volontés du défunt après validation documentaire.' },
            { icon: Upload, title: 'Transmettre des documents', desc: 'Envoi sécurisé de l\'acte de décès aux organismes concernés.' },
            { icon: Send, title: 'Courriers automatiques IA', desc: 'Génération et envoi automatique des notifications aux organismes.' },
            { icon: Users, title: 'Contacter la famille', desc: 'Coordination sécurisée avec la personne de confiance désignée.' },
            { icon: Clock, title: 'Suivi en temps réel', desc: 'Tableau de bord pour suivre l\'avancement des dossiers.' },
          ].map((f, i) => {
            const Icon = f.icon;
            return (
              <View key={i} style={styles.featureCard}>
                <View style={styles.featureIconWrap}>
                  <Icon size={22} color={Colors.primary[500]} strokeWidth={1.5} />
                </View>
                <Text style={styles.featureTitle}>{f.title}</Text>
                <Text style={styles.featureDesc}>{f.desc}</Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* Login */}
      <View style={styles.loginSection}>
        <Card variant="elevated" style={styles.loginCard}>
          <View style={styles.loginHeader}>
            <View style={styles.loginIconWrap}>
              <Shield size={28} color={Colors.primary[500]} strokeWidth={1.5} />
            </View>
            <Text style={styles.loginTitle}>Accéder à mon espace</Text>
            <Text style={styles.loginSub}>Authentification sécurisée requise</Text>
          </View>

          <TouchableOpacity
            style={styles.franceConnectBtn}
            activeOpacity={0.88}
          >
            <Shield size={18} color={Colors.primary[600]} strokeWidth={1.5} />
            <Text style={styles.franceConnectText}>Se connecter avec FranceConnect Pro</Text>
          </TouchableOpacity>

          <View style={styles.dividerRow}>
            <View style={styles.divider} />
            <Text style={styles.dividerText}>ou</Text>
            <View style={styles.divider} />
          </View>

          <TouchableOpacity
            style={styles.loginDemoBtn}
            onPress={() => setView('dashboard')}
            activeOpacity={0.85}
          >
            <Text style={styles.loginDemoBtnText}>Voir la démonstration</Text>
          </TouchableOpacity>

          <Text style={styles.loginNote}>
            Accès réservé aux professionnels habilités. Votre identité sera vérifiée.
          </Text>
        </Card>
      </View>
    </ScrollView>
  );
}

function ProDashboard({ onLogout }: { onLogout: () => void }) {
  const router = useRouter();
  const [search, setSearch] = useState('');

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.dashContent} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.dashHeader}>
        <View>
          <Text style={styles.dashTitle}>Tableau de bord professionnel</Text>
          <Text style={styles.dashSub}>Établissements Renard · Pompes funèbres · Bordeaux</Text>
        </View>
        <View style={styles.dashHeaderRight}>
          <TouchableOpacity style={styles.notifBtn} activeOpacity={0.7}>
            <Bell size={18} color={Colors.neutral[600]} strokeWidth={1.5} />
            <View style={styles.notifDot} />
          </TouchableOpacity>
          <Badge label="Professionnel habilité" variant="success" size="md" />
          <TouchableOpacity onPress={onLogout} style={styles.logoutBtn} activeOpacity={0.8}>
            <Text style={styles.logoutText}>Déconnexion</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Stats */}
      <View style={styles.statsGrid}>
        {stats.map((s, i) => (
          <View key={i} style={styles.statCard}>
            <Text style={[styles.statValue, { color: s.color }]}>{s.value}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* New declaration */}
      <Card variant="elevated" style={styles.newDeclCard}>
        <View style={styles.newDeclContent}>
          <View style={styles.newDeclIcon}>
            <Plus size={24} color={Colors.primary[500]} strokeWidth={1.5} />
          </View>
          <View style={styles.newDeclText}>
            <Text style={styles.newDeclTitle}>Déclarer un nouveau décès</Text>
            <Text style={styles.newDeclSub}>Saisissez les informations du défunt pour activer son dossier 4MT et notifier les organismes.</Text>
          </View>
          <TouchableOpacity style={styles.newDeclBtn} activeOpacity={0.88}>
            <Text style={styles.newDeclBtnText}>Commencer la déclaration</Text>
            <ChevronRight size={16} color="#fff" strokeWidth={2} />
          </TouchableOpacity>
        </View>
      </Card>

      {/* Dossiers */}
      <View style={styles.dossiersHeader}>
        <Text style={styles.dossiersTitle}>Dossiers récents</Text>
        <TouchableOpacity style={styles.searchBtn} activeOpacity={0.8}>
          <Search size={16} color={Colors.neutral[500]} strokeWidth={1.5} />
          <Text style={styles.searchText}>Rechercher un dossier...</Text>
        </TouchableOpacity>
      </View>

      <Card variant="bordered" padding="none">
        <View style={styles.tableHeader}>
          <Text style={[styles.tableCell, styles.tableCellHeader, { flex: 1 }]}>Référence</Text>
          <Text style={[styles.tableCell, styles.tableCellHeader, { flex: 2 }]}>Défunt</Text>
          <Text style={[styles.tableCell, styles.tableCellHeader, { flex: 2 }]}>Personne de confiance</Text>
          <Text style={[styles.tableCell, styles.tableCellHeader, { flex: 1 }]}>Date</Text>
          <Text style={[styles.tableCell, styles.tableCellHeader, { flex: 1 }]}>Statut</Text>
          <Text style={[styles.tableCell, styles.tableCellHeader, { flex: 1 }]}>Action</Text>
        </View>
        {recentDossiers.map((d, i) => {
          const cfg = statusConfig[d.status];
          return (
            <View key={d.id} style={[styles.tableRow, i < recentDossiers.length - 1 && styles.tableRowBorder]}>
              <Text style={[styles.tableCell, { flex: 1, fontFamily: Fonts.medium, color: Colors.primary[600] }]}>{d.id}</Text>
              <Text style={[styles.tableCell, { flex: 2 }]}>{d.name}</Text>
              <Text style={[styles.tableCell, { flex: 2, color: Colors.neutral[500] }]}>{d.trust}</Text>
              <Text style={[styles.tableCell, { flex: 1, color: Colors.neutral[400] }]}>{d.date}</Text>
              <View style={[styles.tableCell, { flex: 1 }]}>
                <Badge label={cfg.label} variant={cfg.badge} />
              </View>
              <TouchableOpacity style={[styles.tableCell, { flex: 1 }]} activeOpacity={0.8}>
                <Text style={styles.tableAction}>Ouvrir →</Text>
              </TouchableOpacity>
            </View>
          );
        })}
      </Card>

      {/* Alerts */}
      <Card variant="bordered" style={styles.alertCard}>
        <View style={styles.alertRow}>
          <AlertTriangle size={18} color={Colors.warning[500]} strokeWidth={1.5} />
          <Text style={styles.alertText}>
            2 dossiers nécessitent une action : documents manquants ou validation en attente.
          </Text>
          <TouchableOpacity activeOpacity={0.8}>
            <Text style={styles.alertCta}>Voir →</Text>
          </TouchableOpacity>
        </View>
      </Card>

      <View style={{ height: Spacing.xl }} />
    </ScrollView>
  );
}

const maxW = 1200;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[50] },

  hero: {
    backgroundColor: Colors.neutral[800],
    paddingVertical: 64,
    paddingHorizontal: Spacing.xl,
    alignItems: 'center',
    gap: Spacing.md,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: Radius.full,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
  },
  heroBadgeText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[200] },
  heroTitle: { fontFamily: Fonts.bold, fontSize: 40, color: '#fff', textAlign: 'center' },
  heroSub: {
    fontFamily: Fonts.regular,
    fontSize: 16,
    color: Colors.neutral[400],
    textAlign: 'center',
    lineHeight: 26,
    maxWidth: 600,
  },

  section: {
    paddingVertical: 56,
    paddingHorizontal: Spacing.xl,
    maxWidth: maxW,
    alignSelf: 'center',
    width: '100%',
    gap: Spacing.lg,
  },
  sectionAlt: {
    maxWidth: '100%',
    backgroundColor: Colors.neutral[50],
    paddingVertical: 56,
    paddingHorizontal: Spacing.xl,
  },
  sectionTitle: { fontFamily: Fonts.bold, fontSize: 24, color: Colors.neutral[800] },

  typeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  typeCard: {
    flex: 1,
    minWidth: 200,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    gap: Spacing.sm,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
    position: 'relative',
    ...Shadow.sm,
  },
  typeCardSelected: {
    borderColor: Colors.primary[400],
    backgroundColor: Colors.primary[50],
  },
  typeIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  typeIconSelected: { backgroundColor: Colors.primary[100] },
  typeLabel: { fontFamily: Fonts.semiBold, fontSize: 16, color: Colors.neutral[700] },
  typeLabelSelected: { color: Colors.primary[700] },
  typeDesc: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[500], lineHeight: 18 },
  typeCheckWrap: { position: 'absolute', top: Spacing.md, right: Spacing.md },

  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
    maxWidth: maxW,
    alignSelf: 'center',
    width: '100%',
    paddingHorizontal: Spacing.xl,
  },
  featureCard: {
    flex: 1,
    minWidth: 240,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    gap: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
    ...Shadow.sm,
  },
  featureIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  featureTitle: { fontFamily: Fonts.semiBold, fontSize: 15, color: Colors.neutral[800] },
  featureDesc: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[500], lineHeight: 19 },

  loginSection: {
    paddingVertical: 56,
    paddingHorizontal: Spacing.xl,
    alignItems: 'center',
  },
  loginCard: {
    width: '100%',
    maxWidth: 440,
    gap: Spacing.md,
    alignItems: 'center',
  },
  loginHeader: { alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.sm },
  loginIconWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  loginTitle: { fontFamily: Fonts.bold, fontSize: 22, color: Colors.neutral[800] },
  loginSub: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[500] },
  franceConnectBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    width: '100%',
    backgroundColor: Colors.primary[50],
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    borderWidth: 1.5,
    borderColor: Colors.primary[200],
  },
  franceConnectText: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.primary[600] },
  dividerRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, width: '100%' },
  divider: { flex: 1, height: 1, backgroundColor: Colors.neutral[200] },
  dividerText: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[400] },
  loginDemoBtn: {
    width: '100%',
    backgroundColor: Colors.neutral[100],
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    alignItems: 'center',
  },
  loginDemoBtnText: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.neutral[700] },
  loginNote: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.neutral[400],
    textAlign: 'center',
    lineHeight: 17,
  },

  dashContent: { padding: Spacing.xl, gap: Spacing.lg, maxWidth: maxW, alignSelf: 'center', width: '100%' },
  dashHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  dashTitle: { fontFamily: Fonts.bold, fontSize: 24, color: Colors.neutral[800] },
  dashSub: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[500], marginTop: 3 },
  dashHeaderRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    flexWrap: 'wrap',
  },
  notifBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  notifDot: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 7,
    height: 7,
    borderRadius: 3.5,
    backgroundColor: Colors.error[500],
  },
  logoutBtn: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.sm,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
  },
  logoutText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[600] },

  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  statCard: {
    flex: 1,
    minWidth: 140,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    gap: 4,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
    ...Shadow.sm,
  },
  statValue: { fontFamily: Fonts.bold, fontSize: 32 },
  statLabel: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[500] },

  newDeclCard: {},
  newDeclContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.lg,
    flexWrap: 'wrap',
  },
  newDeclIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  newDeclText: { flex: 1, minWidth: 200 },
  newDeclTitle: { fontFamily: Fonts.semiBold, fontSize: 18, color: Colors.neutral[800] },
  newDeclSub: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[500], marginTop: 4, lineHeight: 20 },
  newDeclBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.primary[500],
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
  },
  newDeclBtnText: { fontFamily: Fonts.semiBold, fontSize: 14, color: '#fff' },

  dossiersHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dossiersTitle: { fontFamily: Fonts.semiBold, fontSize: 18, color: Colors.neutral[800] },
  searchBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.sm,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    backgroundColor: Colors.neutral[0],
  },
  searchText: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[400] },

  tableHeader: {
    flexDirection: 'row',
    backgroundColor: Colors.neutral[50],
    borderTopLeftRadius: Radius.lg,
    borderTopRightRadius: Radius.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm + 2,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  tableRow: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    alignItems: 'center',
  },
  tableRowBorder: { borderBottomWidth: 1, borderBottomColor: Colors.neutral[100] },
  tableCell: {
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: Colors.neutral[700],
    paddingRight: Spacing.sm,
  },
  tableCellHeader: {
    fontFamily: Fonts.semiBold,
    fontSize: 12,
    color: Colors.neutral[500],
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  tableAction: { fontFamily: Fonts.semiBold, fontSize: 13, color: Colors.primary[500] },

  alertCard: {},
  alertRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  alertText: { flex: 1, fontFamily: Fonts.medium, fontSize: 13, color: Colors.warning[700] },
  alertCta: { fontFamily: Fonts.semiBold, fontSize: 13, color: Colors.warning[600] },
  demoBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: Colors.warning[50],
    borderBottomWidth: 1,
    borderBottomColor: Colors.warning[200],
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    justifyContent: 'center',
  },
  demoBannerText: {
    fontFamily: Fonts.medium,
    fontSize: 12,
    color: Colors.warning[700],
    textAlign: 'center',
  },
});
