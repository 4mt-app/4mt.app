import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import Card from '@/components/Card';
import Badge from '@/components/Badge';
import { Shield, Heart, FileText, Users, ChevronRight, Lock, Mail, Key, CircleCheck, CircleAlert as AlertCircle, Download, Send, Eye, Clock } from 'lucide-react-native';
import { useDemo } from '@/lib/demoContext';

export default function WebConfiancePage() {
  const { isDemo } = useDemo();
  const [step, setStep] = useState<'landing' | 'verify' | 'access'>('landing');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleVerify = () => {
    if (!email) { setError('Veuillez saisir votre adresse email.'); return; }
    setLoading(true);
    setError(null);
    setTimeout(() => { setLoading(false); setStep('verify'); }, 1000);
  };

  const handleCode = () => {
    if (code.length < 6) { setError('Code invalide.'); return; }
    setLoading(true);
    setError(null);
    setTimeout(() => { setLoading(false); setStep('access'); }, 1000);
  };

  if (step === 'access' || isDemo) {
    return <ConfianceAccess />;
  }

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Bandeau prototype */}
      <View style={styles.demoBanner}>
        <AlertCircle size={13} color={Colors.warning[700]} strokeWidth={1.5} />
        <Text style={styles.demoBannerText}>Prototype · Vérification d'identité et accès au dossier simulés</Text>
      </View>

      {/* Hero */}
      <View style={styles.hero}>
        <View style={styles.heroBadge}>
          <Shield size={13} color={Colors.teal[300]} strokeWidth={1.5} />
          <Text style={styles.heroBadgeText}>Accès sécurisé · Personne de confiance</Text>
        </View>
        <Text style={styles.heroTitle}>Espace personne{'\n'}de confiance</Text>
        <Text style={styles.heroSub}>
          Vous avez été désigné(e) comme personne de confiance par quelqu'un qui vous fait confiance. Cet espace vous permet d'accéder à son dossier 4MT au moment venu.
        </Text>
      </View>

      {/* Info cards */}
      <View style={styles.section}>
        <View style={styles.infoGrid}>
          {[
            { icon: Shield, title: 'Accès sécurisé', desc: 'Votre identité est vérifiée à chaque connexion. Les données sont chiffrées.' },
            { icon: Heart, title: 'Un rôle essentiel', desc: 'Vous serez notifié(e) par email sécurisé et pourrez activer le dossier après le décès.' },
            { icon: Lock, title: 'Confidentialité totale', desc: 'Aucun accès avant activation. Toutes vos actions sont tracées pour la sécurité.' },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <View key={i} style={styles.infoCard}>
                <View style={styles.infoIcon}>
                  <Icon size={22} color={Colors.primary[500]} strokeWidth={1.5} />
                </View>
                <Text style={styles.infoTitle}>{item.title}</Text>
                <Text style={styles.infoDesc}>{item.desc}</Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* Login form */}
      <View style={styles.loginSection}>
        <Card variant="elevated" style={styles.loginCard}>
          <View style={styles.loginHeader}>
            <View style={styles.loginIconWrap}>
              {step === 'landing'
                ? <Mail size={28} color={Colors.primary[500]} strokeWidth={1.5} />
                : <Key size={28} color={Colors.teal[500]} strokeWidth={1.5} />
              }
            </View>
            <Text style={styles.loginTitle}>
              {step === 'landing' ? 'Vérification de votre identité' : 'Code de vérification'}
            </Text>
            <Text style={styles.loginSub}>
              {step === 'landing'
                ? 'Saisissez l\'adresse email sur laquelle vous avez reçu la notification.'
                : `Un code à 6 chiffres a été envoyé à ${email}`
              }
            </Text>
          </View>

          {error && (
            <View style={styles.errorBox}>
              <AlertCircle size={14} color={Colors.error[600]} strokeWidth={1.5} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          {step === 'landing' && (
            <>
              <View style={styles.fieldGroup}>
                <Text style={styles.label}>Adresse email</Text>
                <View style={styles.inputRow}>
                  <Mail size={16} color={Colors.neutral[400]} strokeWidth={1.5} />
                  <TextInput
                    style={styles.input}
                    placeholder="votre@email.com"
                    placeholderTextColor={Colors.neutral[400]}
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                </View>
              </View>
              <TouchableOpacity
                style={styles.submitBtn}
                onPress={handleVerify}
                activeOpacity={0.88}
              >
                <Text style={styles.submitBtnText}>{loading ? 'Vérification...' : 'Vérifier mon identité'}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.franceConnectBtn} activeOpacity={0.85}>
                <Shield size={16} color={Colors.primary[600]} strokeWidth={1.5} />
                <Text style={styles.franceConnectText}>Ou avec FranceConnect</Text>
              </TouchableOpacity>
            </>
          )}

          {step === 'verify' && (
            <>
              <View style={styles.fieldGroup}>
                <Text style={styles.label}>Code à 6 chiffres</Text>
                <View style={styles.inputRow}>
                  <Key size={16} color={Colors.neutral[400]} strokeWidth={1.5} />
                  <TextInput
                    style={[styles.input, styles.codeInput]}
                    placeholder="000000"
                    placeholderTextColor={Colors.neutral[400]}
                    value={code}
                    onChangeText={setCode}
                    keyboardType="number-pad"
                    maxLength={6}
                  />
                </View>
              </View>
              <TouchableOpacity
                style={styles.submitBtn}
                onPress={handleCode}
                activeOpacity={0.88}
              >
                <Text style={styles.submitBtnText}>{loading ? 'Vérification...' : 'Accéder au dossier'}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.resendBtn} activeOpacity={0.8}>
                <Text style={styles.resendText}>Renvoyer le code</Text>
              </TouchableOpacity>
            </>
          )}

          <Text style={styles.loginNote}>
            Cet accès est protégé et confidentiel. Conformité RGPD garantie.
          </Text>
        </Card>
      </View>
    </ScrollView>
  );
}

function ConfianceAccess() {
  const dossier = {
    name: 'Henri Moreau',
    date: '22 avril 2026',
    trusted: 'Pauline Moreau',
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.accessContent} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.accessHeader}>
        <View style={styles.accessIcon}>
          <CircleCheck size={32} color={Colors.success[500]} strokeWidth={1.5} />
        </View>
        <Text style={styles.accessTitle}>Dossier de {dossier.name}</Text>
        <Text style={styles.accessSub}>Vous avez été désigné(e) comme personne de confiance</Text>
        <Badge label="Accès autorisé" variant="success" size="md" />
      </View>

      {/* Alert action required */}
      <View style={styles.activationAlert}>
        <AlertCircle size={20} color={Colors.warning[600]} strokeWidth={1.5} />
        <View style={styles.activationAlertContent}>
          <Text style={styles.activationAlertTitle}>Action requise</Text>
          <Text style={styles.activationAlertText}>
            Pour activer le dossier, vous devez valider l'acte de décès officiel. Cette action déclenchera la transmission aux organismes désignés.
          </Text>
        </View>
      </View>

      {/* Sections */}
      <Text style={styles.sectionTitle}>Contenu du dossier</Text>
      <View style={styles.accessGrid}>
        {[
          { icon: Heart, label: 'Messages posthumes', desc: '3 messages à transmettre', color: Colors.teal[500], status: 'En attente d\'activation' },
          { icon: FileText, label: 'Volontés funéraires', desc: 'Cérémonial laïque, en nature', color: Colors.primary[500], status: 'Complet' },
          { icon: Send, label: 'Démarches admin.', desc: '7 organismes à notifier', color: Colors.sage[600], status: 'Prêt à envoyer' },
          { icon: Users, label: 'Gestion des biens', desc: 'Instructions définies', color: Colors.neutral[600], status: 'Complet' },
        ].map((item, i) => {
          const Icon = item.icon;
          return (
            <TouchableOpacity key={i} style={styles.accessCard} activeOpacity={0.85}>
              <View style={[styles.accessCardIcon, { backgroundColor: `${item.color}18` }]}>
                <Icon size={22} color={item.color} strokeWidth={1.5} />
              </View>
              <View style={styles.accessCardContent}>
                <Text style={styles.accessCardLabel}>{item.label}</Text>
                <Text style={styles.accessCardDesc}>{item.desc}</Text>
                <Text style={[styles.accessCardStatus, { color: item.color }]}>{item.status}</Text>
              </View>
              <ChevronRight size={16} color={Colors.neutral[300]} strokeWidth={2} />
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Actions */}
      <Text style={styles.sectionTitle}>Actions disponibles</Text>
      <View style={styles.actionsGrid}>
        <TouchableOpacity style={styles.actionCardPrimary} activeOpacity={0.88}>
          <CircleCheck size={20} color="#fff" strokeWidth={1.5} />
          <Text style={styles.actionCardPrimaryText}>Activer le dossier 4MT</Text>
          <Text style={styles.actionCardPrimaryDesc}>Valider le document officiel et déclencher les procédures</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionCard} activeOpacity={0.85}>
          <Download size={18} color={Colors.primary[500]} strokeWidth={1.5} />
          <Text style={styles.actionCardText}>Télécharger le récapitulatif</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionCard} activeOpacity={0.85}>
          <Eye size={18} color={Colors.neutral[600]} strokeWidth={1.5} />
          <Text style={styles.actionCardText}>Consulter les volontés</Text>
        </TouchableOpacity>
      </View>

      {/* Timeline */}
      <Text style={styles.sectionTitle}>Historique</Text>
      <Card variant="bordered">
        {[
          { text: 'Dossier créé par Henri Moreau', time: '15 janvier 2025', icon: CircleCheck, done: true },
          { text: 'Personne de confiance désignée', time: '16 janvier 2025', icon: Users, done: true },
          { text: 'Dossier complété à 85%', time: '3 mars 2026', icon: FileText, done: true },
          { text: 'Décès déclaré par les pompes funèbres', time: '22 avril 2026', icon: AlertCircle, done: true },
          { text: 'Activation du dossier par la personne de confiance', time: 'En attente', icon: Clock, done: false },
        ].map((e, i, arr) => {
          const Icon = e.icon;
          return (
            <View key={i} style={[styles.timelineItem, i < arr.length - 1 && styles.timelineItemBorder]}>
              <View style={[styles.timelineIcon, e.done ? styles.timelineIconDone : styles.timelineIconPending]}>
                <Icon size={12} color={e.done ? Colors.success[600] : Colors.neutral[400]} strokeWidth={2} />
              </View>
              <View style={styles.timelineContent}>
                <Text style={[styles.timelineText, !e.done && styles.timelineTextPending]}>{e.text}</Text>
                <Text style={styles.timelineTime}>{e.time}</Text>
              </View>
            </View>
          );
        })}
      </Card>

      <View style={{ height: Spacing.xl }} />
    </ScrollView>
  );
}

const maxW = 900;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[50] },

  hero: {
    backgroundColor: Colors.teal[700],
    paddingVertical: 64,
    paddingHorizontal: Spacing.xl,
    alignItems: 'center',
    gap: Spacing.md,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderRadius: Radius.full,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
  },
  heroBadgeText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[200] },
  heroTitle: { fontFamily: Fonts.bold, fontSize: 40, color: '#fff', textAlign: 'center', lineHeight: 50 },
  heroSub: {
    fontFamily: Fonts.regular,
    fontSize: 16,
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
    lineHeight: 26,
    maxWidth: 560,
  },

  section: {
    paddingVertical: 48,
    paddingHorizontal: Spacing.xl,
    maxWidth: maxW,
    alignSelf: 'center',
    width: '100%',
  },
  infoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.lg,
  },
  infoCard: {
    flex: 1,
    minWidth: 220,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    gap: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
    ...Shadow.sm,
  },
  infoIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoTitle: { fontFamily: Fonts.semiBold, fontSize: 16, color: Colors.neutral[800] },
  infoDesc: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[500], lineHeight: 19 },

  loginSection: {
    paddingVertical: 48,
    paddingHorizontal: Spacing.xl,
    alignItems: 'center',
  },
  loginCard: {
    width: '100%',
    maxWidth: 460,
    gap: Spacing.md,
  },
  loginHeader: { alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.sm },
  loginIconWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: Colors.teal[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  loginTitle: { fontFamily: Fonts.bold, fontSize: 20, color: Colors.neutral[800], textAlign: 'center' },
  loginSub: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[500], textAlign: 'center', lineHeight: 20 },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.error[50],
    borderRadius: Radius.sm,
    padding: Spacing.sm + 2,
  },
  errorText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.error[700] },
  fieldGroup: { gap: Spacing.xs },
  label: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[700] },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm + 4,
  },
  input: {
    flex: 1,
    fontFamily: Fonts.regular,
    fontSize: 15,
    color: Colors.neutral[800],
  },
  codeInput: {
    fontFamily: Fonts.bold,
    fontSize: 24,
    letterSpacing: 8,
    textAlign: 'center',
  },
  submitBtn: {
    backgroundColor: Colors.teal[500],
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    alignItems: 'center',
  },
  submitBtnText: { fontFamily: Fonts.semiBold, fontSize: 15, color: '#fff' },
  franceConnectBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.primary[50],
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.primary[100],
  },
  franceConnectText: { fontFamily: Fonts.medium, fontSize: 14, color: Colors.primary[600] },
  resendBtn: { alignItems: 'center', paddingVertical: Spacing.sm },
  resendText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.teal[500] },
  loginNote: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.neutral[400],
    textAlign: 'center',
    lineHeight: 17,
  },

  accessContent: { padding: Spacing.xl, gap: Spacing.lg, maxWidth: maxW, alignSelf: 'center', width: '100%' },
  accessHeader: { alignItems: 'center', gap: Spacing.sm, paddingBottom: Spacing.md },
  accessIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.success[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  accessTitle: { fontFamily: Fonts.bold, fontSize: 26, color: Colors.neutral[800] },
  accessSub: { fontFamily: Fonts.regular, fontSize: 15, color: Colors.neutral[500] },

  activationAlert: {
    flexDirection: 'row',
    gap: Spacing.md,
    backgroundColor: '#FEF9EC',
    borderRadius: Radius.md,
    padding: Spacing.md,
    borderWidth: 1.5,
    borderColor: '#FDE68A',
  },
  activationAlertContent: { flex: 1 },
  activationAlertTitle: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.warning[700] },
  activationAlertText: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.warning[600], marginTop: 3, lineHeight: 18 },

  sectionTitle: { fontFamily: Fonts.semiBold, fontSize: 18, color: Colors.neutral[700] },
  accessGrid: { gap: Spacing.sm },
  accessCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
    ...Shadow.sm,
  },
  accessCardIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  accessCardContent: { flex: 1 },
  accessCardLabel: { fontFamily: Fonts.semiBold, fontSize: 15, color: Colors.neutral[800] },
  accessCardDesc: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[500], marginTop: 2 },
  accessCardStatus: { fontFamily: Fonts.medium, fontSize: 12, marginTop: 3 },

  actionsGrid: { gap: Spacing.sm },
  actionCardPrimary: {
    backgroundColor: Colors.teal[500],
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    gap: Spacing.sm,
    ...Shadow.md,
  },
  actionCardPrimaryText: { fontFamily: Fonts.bold, fontSize: 16, color: '#fff' },
  actionCardPrimaryDesc: { fontFamily: Fonts.regular, fontSize: 13, color: 'rgba(255,255,255,0.8)', lineHeight: 18 },
  actionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.md,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
    ...Shadow.sm,
  },
  actionCardText: { fontFamily: Fonts.medium, fontSize: 14, color: Colors.neutral[700] },

  timelineItem: {
    flexDirection: 'row',
    gap: Spacing.md,
    paddingVertical: Spacing.sm + 2,
    alignItems: 'flex-start',
  },
  timelineItemBorder: { borderBottomWidth: 1, borderBottomColor: Colors.neutral[100] },
  timelineIcon: {
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  timelineIconDone: { backgroundColor: Colors.success[50] },
  timelineIconPending: { backgroundColor: Colors.neutral[100] },
  timelineContent: { flex: 1 },
  timelineText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[700] },
  timelineTextPending: { color: Colors.neutral[400] },
  timelineTime: { fontFamily: Fonts.regular, fontSize: 11, color: Colors.neutral[400], marginTop: 2 },
  demoBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: Colors.warning[50],
    borderBottomWidth: 1,
    borderBottomColor: Colors.warning[200],
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    justifyContent: 'center',
  },
  demoBannerText: {
    fontFamily: Fonts.medium,
    fontSize: 12,
    color: Colors.warning[700],
    textAlign: 'center',
  },
});
