import { Stack } from 'expo-router';
import { View, StyleSheet } from 'react-native';
import WebNav from '@/components/WebNav';
import { Colors } from '@/constants/theme';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function WebLayout() {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <WebNav />
      <View style={styles.page}>
        <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: Colors.neutral[0] } }} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  page: {
    flex: 1,
  },
});
