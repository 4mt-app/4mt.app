import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Image, Dimensions, Platform
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import { Heart, FileText, Shield, Users, Sparkles, ChevronRight, Star, Building2, Scale, Landmark, CircleCheck as CheckCircle2, Play } from 'lucide-react-native';
import WebFooter from '@/components/WebFooter';

const { width } = Dimensions.get('window');
const isWeb = Platform.OS === 'web';

const features = [
  {
    icon: Heart,
    color: Colors.teal[500],
    bg: Colors.teal[50],
    title: 'Héritage émotionnel',
    desc: 'Rédigez des messages, enregistrez votre voix ou filmez une vidéo posthume pour vos proches. Vos mots traverseront le temps.',
  },
  {
    icon: Sparkles,
    color: Colors.primary[500],
    bg: Colors.primary[50],
    title: 'Questionnaire guidé par IA',
    desc: "Notre intelligence artificielle vous accompagne pas à pas pour organiser votre cérémonie selon vos croyances, valeurs et préférences.",
  },
  {
    icon: FileText,
    color: Colors.sage[600],
    bg: Colors.sage[50],
    title: 'Démarches simplifiées',
    desc: "L'IA génère automatiquement les courriers pour chaque organisme (banque, assurance, impôts...) afin d'alléger la charge de vos proches.",
  },
  {
    icon: Shield,
    color: Colors.primary[600],
    bg: Colors.primary[50],
    title: 'Sécurité maximale',
    desc: 'Données chiffrées, conformité RGPD, hébergement France. Accès contrôlé via FranceConnect. Votre vie privée est notre priorité.',
  },
  {
    icon: Users,
    color: Colors.neutral[600],
    bg: Colors.neutral[100],
    title: 'Personne de confiance',
    desc: 'Désignez quelqu\'un de confiance qui recevra une notification sécurisée et pourra activer votre dossier au moment venu.',
  },
  {
    icon: CheckCircle2,
    color: Colors.success[500],
    bg: Colors.success[50],
    title: 'Accessible à tous',
    desc: 'Synthèse vocale, sous-titres, navigation simplifiée. Conçu pour être utilisé par toutes et tous, sans exception.',
  },
];

const proPartners = [
  { icon: Building2, label: 'Pompes funèbres' },
  { icon: Scale, label: 'Notaires' },
  { icon: Landmark, label: 'Assurances' },
  { icon: FileText, label: 'Mairies' },
];

const testimonials = [
  {
    text: '"J\'ai pu préparer mes volontés en moins d\'une heure. Le questionnaire m\'a vraiment guidée, je ne savais pas par où commencer."',
    author: 'Marie, 67 ans',
    location: 'Lyon',
  },
  {
    text: '"Grâce à 4MT, ma famille n\'a pas eu à se préoccuper des démarches administratives. Tout était déjà organisé."',
    author: 'Jean-Pierre, famille',
    location: 'Paris',
  },
  {
    text: '"Comme pompes funèbres, nous avons gagné un temps précieux grâce à l\'intégration avec 4MT. Un outil indispensable."',
    author: 'Établissements Renard',
    location: 'Bordeaux',
  },
];

const pricingPlans = [
  {
    name: 'Gratuit',
    price: '0€',
    period: 'pour toujours',
    color: Colors.neutral[700],
    features: [
      'Création de compte sécurisé',
      'Messages texte illimités',
      'Questionnaire IA',
      'Volontés funéraires',
      'Personne de confiance',
      'Démarches administratives',
    ],
    cta: 'Commencer gratuitement',
    variant: 'outline' as const,
  },
  {
    name: 'Premium',
    price: '9,90€',
    period: 'par mois',
    color: Colors.primary[500],
    badge: 'Populaire',
    features: [
      'Tout du plan Gratuit',
      'Vidéo posthume HD',
      'Messages audio illimités',
      'Hologramme (bêta)',
      'Réalité augmentée (bêta)',
      'Diffusion cérémonie',
    ],
    cta: 'Essai 30 jours gratuit',
    variant: 'primary' as const,
  },
  {
    name: 'Professionnel',
    price: 'Sur devis',
    period: 'abonnement',
    color: Colors.teal[600],
    features: [
      'Interface B2B dédiée',
      'Déclaration de décès',
      'Activation dossier 4MT',
      'Transmission documents',
      'Tableau de bord pro',
      'Support prioritaire',
    ],
    cta: 'Nous contacter',
    variant: 'secondary' as const,
  },
];

export default function WebHomePage() {
  const router = useRouter();

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Bandeau prototype */}
      <View style={styles.demoBanner}>
        <Text style={styles.demoBannerText}>
          Version prototype — Cette plateforme est en cours de développement. Certaines fonctionnalités sont simulées à des fins de démonstration.
        </Text>
      </View>

      {/* HERO */}
      <View style={styles.hero}>
        <Image
          source={{ uri: 'https://images.pexels.com/photos/1266808/pexels-photo-1266808.jpeg?auto=compress&cs=tinysrgb&w=1200' }}
          style={StyleSheet.absoluteFillObject}
          resizeMode="cover"
        />
        <LinearGradient
          colors={['rgba(13,22,32,0.45)', 'rgba(13,22,32,0.82)']}
          style={StyleSheet.absoluteFillObject}
        />
        <View style={styles.heroContent}>
          <View style={styles.heroBadge}>
            <Shield size={13} color={Colors.teal[300]} strokeWidth={1.5} />
            <Text style={styles.heroBadgeText}>Données sécurisées · RGPD · France</Text>
          </View>
          <Text style={styles.heroTitle}>
            Transmettez ce qui{'\n'}compte vraiment
          </Text>
          <Text style={styles.heroSub}>
            4MT est la plateforme tout-en-un pour anticiper sa fin de vie avec sérénité — héritage émotionnel, volontés funéraires et démarches administratives, accessibles depuis votre mobile ou ordinateur.
          </Text>
          <View style={styles.heroActions}>
            <TouchableOpacity
              style={styles.heroCta}
              onPress={() => router.push('/auth/register')}
              activeOpacity={0.88}
            >
              <Text style={styles.heroCtaText}>Créer mon dossier gratuitement</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.heroSecondary}
              onPress={() => router.push('/web/pro' as any)}
              activeOpacity={0.85}
            >
              <Text style={styles.heroSecondaryText}>Espace professionnel</Text>
              <ChevronRight size={16} color={Colors.neutral[200]} strokeWidth={2} />
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            style={styles.demoBtn}
            onPress={() => router.push('/web/demo' as any)}
            activeOpacity={0.88}
          >
            <Play size={16} color={Colors.primary[900]} strokeWidth={2} />
            <Text style={styles.demoBtnText}>Lancer une démo complète 4MT</Text>
          </TouchableOpacity>
          <View style={styles.heroStats}>
            {[
              { val: '100%', label: 'Gratuit pour les particuliers' },
              { val: 'RGPD', label: 'Conformité totale' },
              { val: 'IA', label: 'Questionnaire guidé' },
            ].map((s, i) => (
              <View key={i} style={styles.heroStat}>
                <Text style={styles.heroStatVal}>{s.val}</Text>
                <Text style={styles.heroStatLabel}>{s.label}</Text>
              </View>
            ))}
          </View>
        </View>
      </View>

      {/* FEATURES */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionPre}>Fonctionnalités</Text>
          <Text style={styles.sectionTitle}>Une solution complète{'\n'}pour l'essentiel</Text>
          <Text style={styles.sectionDesc}>
            4MT centralise tout ce dont vous avez besoin pour préparer sereinement la suite — et alléger vos proches.
          </Text>
        </View>
        <View style={styles.featureGrid}>
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <View key={i} style={styles.featureCard}>
                <View style={[styles.featureIcon, { backgroundColor: f.bg }]}>
                  <Icon size={26} color={f.color} strokeWidth={1.5} />
                </View>
                <Text style={styles.featureTitle}>{f.title}</Text>
                <Text style={styles.featureDesc}>{f.desc}</Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* HOW IT WORKS */}
      <View style={[styles.section, styles.sectionAlt]}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionPre}>Comment ça marche</Text>
          <Text style={styles.sectionTitle}>Simple en 4 étapes</Text>
        </View>
        <View style={styles.stepsRow}>
          {[
            { num: '01', title: 'Créez votre compte', desc: 'Inscription gratuite, sécurisée, sans engagement.' },
            { num: '02', title: 'Répondez au questionnaire IA', desc: 'Notre IA vous guide selon vos valeurs et croyances.' },
            { num: '03', title: 'Complétez votre dossier', desc: 'Messages, volontés funéraires, biens, organismes.' },
            { num: '04', title: 'Désignez une personne de confiance', desc: 'Elle activera votre dossier au moment venu.' },
          ].map((s, i) => (
            <View key={i} style={styles.step}>
              <View style={styles.stepNum}>
                <Text style={styles.stepNumText}>{s.num}</Text>
              </View>
              {i < 3 && <View style={styles.stepLine} />}
              <Text style={styles.stepTitle}>{s.title}</Text>
              <Text style={styles.stepDesc}>{s.desc}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* MULTIPLATFORM */}
      <View style={styles.section}>
        <View style={styles.platformBanner}>
          <Image
            source={{ uri: 'https://images.pexels.com/photos/5081971/pexels-photo-5081971.jpeg?auto=compress&cs=tinysrgb&w=800' }}
            style={styles.platformImage}
            resizeMode="cover"
          />
          <View style={styles.platformContent}>
            <Text style={styles.sectionPre}>Multiplateforme</Text>
            <Text style={styles.platformTitle}>Disponible sur mobile{'\n'}et sur ordinateur</Text>
            <Text style={styles.platformDesc}>
              Utilisez 4MT où que vous soyez — depuis votre smartphone, tablette ou ordinateur. Vos données sont synchronisées en temps réel et sécurisées en permanence.
            </Text>
            <View style={styles.platformFeatures}>
              {[
                'Application mobile iOS & Android',
                'Site web responsive',
                'Synchronisation temps réel',
                'Accès hors connexion (mobile)',
              ].map((f, i) => (
                <View key={i} style={styles.platformFeatureRow}>
                  <CheckCircle2 size={16} color={Colors.success[500]} strokeWidth={2} />
                  <Text style={styles.platformFeatureText}>{f}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>
      </View>

      {/* PROFESSIONALS */}
      <View style={[styles.section, styles.sectionAlt]}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionPre}>Espace B2B</Text>
          <Text style={styles.sectionTitle}>Pour les professionnels</Text>
          <Text style={styles.sectionDesc}>
            Une interface dédiée pour les pompes funèbres, notaires, assurances et mairies.
          </Text>
        </View>
        <View style={styles.proGrid}>
          {proPartners.map((p, i) => {
            const Icon = p.icon;
            return (
              <View key={i} style={styles.proCard}>
                <View style={styles.proIcon}>
                  <Icon size={28} color={Colors.primary[500]} strokeWidth={1.5} />
                </View>
                <Text style={styles.proLabel}>{p.label}</Text>
              </View>
            );
          })}
        </View>
        <View style={styles.proBenefits}>
          {[
            'Déclarer un décès en quelques clics',
            'Activer un dossier 4MT sécurisé',
            'Transmettre des documents en toute sécurité',
            'Gagner du temps sur les procédures',
          ].map((b, i) => (
            <View key={i} style={styles.benefitRow}>
              <CheckCircle2 size={16} color={Colors.teal[500]} strokeWidth={2} />
              <Text style={styles.benefitText}>{b}</Text>
            </View>
          ))}
        </View>
        <TouchableOpacity
          style={styles.proCtaBtn}
          onPress={() => router.push('/web/pro' as any)}
          activeOpacity={0.88}
        >
          <Text style={styles.proCtaBtnText}>Accéder à l'espace professionnel</Text>
          <ChevronRight size={16} color="#fff" strokeWidth={2} />
        </TouchableOpacity>
      </View>

      {/* TESTIMONIALS */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionPre}>Témoignages</Text>
          <Text style={styles.sectionTitle}>Ils nous font confiance</Text>
        </View>
        <View style={styles.testimonialsRow}>
          {testimonials.map((t, i) => (
            <View key={i} style={styles.testimonialCard}>
              <View style={styles.stars}>
                {Array.from({ length: 5 }).map((_, si) => (
                  <Star key={si} size={14} color={Colors.warning[500]} fill={Colors.warning[500]} strokeWidth={0} />
                ))}
              </View>
              <Text style={styles.testimonialText}>{t.text}</Text>
              <View style={styles.testimonialAuthor}>
                <View style={styles.testimonialAvatar}>
                  <Text style={styles.testimonialAvatarText}>{t.author[0]}</Text>
                </View>
                <View>
                  <Text style={styles.testimonialName}>{t.author}</Text>
                  <Text style={styles.testimonialLocation}>{t.location}</Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      </View>

      {/* PRICING */}
      <View style={[styles.section, styles.sectionAlt]}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionPre}>Tarifs</Text>
          <Text style={styles.sectionTitle}>Transparent et accessible</Text>
        </View>
        <View style={styles.pricingGrid}>
          {pricingPlans.map((plan, i) => (
            <View key={i} style={[styles.pricingCard, plan.badge && styles.pricingCardFeatured]}>
              {plan.badge && (
                <View style={styles.pricingBadge}>
                  <Text style={styles.pricingBadgeText}>{plan.badge}</Text>
                </View>
              )}
              <Text style={[styles.pricingName, { color: plan.color }]}>{plan.name}</Text>
              <View style={styles.pricingPrice}>
                <Text style={styles.pricingAmount}>{plan.price}</Text>
                <Text style={styles.pricingPeriod}>{plan.period}</Text>
              </View>
              <View style={styles.pricingFeatures}>
                {plan.features.map((f, fi) => (
                  <View key={fi} style={styles.pricingFeatureRow}>
                    <CheckCircle2 size={14} color={Colors.success[500]} strokeWidth={2} />
                    <Text style={styles.pricingFeatureText}>{f}</Text>
                  </View>
                ))}
              </View>
              <TouchableOpacity
                style={[
                  styles.pricingCta,
                  plan.variant === 'primary' && styles.pricingCtaPrimary,
                  plan.variant === 'secondary' && styles.pricingCtaSecondary,
                  plan.variant === 'outline' && styles.pricingCtaOutline,
                ]}
                onPress={() => router.push('/auth/register')}
                activeOpacity={0.85}
              >
                <Text style={[
                  styles.pricingCtaText,
                  plan.variant === 'outline' && styles.pricingCtaTextOutline,
                ]}>
                  {plan.cta}
                </Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>
      </View>

      {/* FINAL CTA */}
      <View style={styles.finalCta}>
        <LinearGradient
          colors={[Colors.primary[600], Colors.primary[800]]}
          style={StyleSheet.absoluteFillObject}
        />
        <Text style={styles.finalCtaTitle}>Prêt à préparer votre héritage ?</Text>
        <Text style={styles.finalCtaSub}>
          Rejoignez des milliers de personnes qui ont choisi 4MT pour transmettre ce qui compte vraiment.
        </Text>
        <TouchableOpacity
          style={styles.finalCtaBtn}
          onPress={() => router.push('/auth/register')}
          activeOpacity={0.88}
        >
          <Text style={styles.finalCtaBtnText}>Commencer gratuitement</Text>
        </TouchableOpacity>
        <Text style={styles.finalCtaNote}>Sans carte bancaire · Inscription en 2 minutes</Text>
      </View>
      <WebFooter />
    </ScrollView>
  );
}

const maxW = 1200;
const sectionPad = Spacing.xl;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[0] },

  hero: {
    height: 680,
    justifyContent: 'flex-end',
    overflow: 'hidden',
  },
  heroContent: {
    maxWidth: maxW,
    alignSelf: 'center',
    width: '100%',
    paddingHorizontal: sectionPad,
    paddingBottom: 72,
    gap: Spacing.lg,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: Radius.full,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  heroBadgeText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[200] },
  heroTitle: {
    fontFamily: Fonts.bold,
    fontSize: 54,
    color: '#fff',
    lineHeight: 64,
  },
  heroSub: {
    fontFamily: Fonts.regular,
    fontSize: 18,
    color: Colors.neutral[300],
    lineHeight: 28,
    maxWidth: 620,
  },
  heroActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    flexWrap: 'wrap',
  },
  heroCta: {
    backgroundColor: Colors.primary[500],
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
  },
  heroCtaText: { fontFamily: Fonts.semiBold, fontSize: 16, color: '#fff' },
  heroSecondary: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  heroSecondaryText: { fontFamily: Fonts.medium, fontSize: 15, color: Colors.neutral[200] },
  heroStats: {
    flexDirection: 'row',
    gap: Spacing.xl,
    flexWrap: 'wrap',
  },
  heroStat: { gap: 3 },
  heroStatVal: { fontFamily: Fonts.bold, fontSize: 22, color: '#fff' },
  heroStatLabel: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[400] },

  section: {
    paddingVertical: 72,
    paddingHorizontal: sectionPad,
    maxWidth: maxW,
    alignSelf: 'center',
    width: '100%',
  },
  sectionAlt: {
    maxWidth: '100%',
    backgroundColor: Colors.neutral[50],
    paddingVertical: 72,
  },
  sectionHeader: {
    alignItems: 'center',
    marginBottom: 48,
    gap: Spacing.sm,
  },
  sectionPre: {
    fontFamily: Fonts.semiBold,
    fontSize: 13,
    color: Colors.primary[500],
    textTransform: 'uppercase',
    letterSpacing: 1.2,
  },
  sectionTitle: {
    fontFamily: Fonts.bold,
    fontSize: 36,
    color: Colors.neutral[800],
    textAlign: 'center',
    lineHeight: 44,
  },
  sectionDesc: {
    fontFamily: Fonts.regular,
    fontSize: 16,
    color: Colors.neutral[500],
    textAlign: 'center',
    lineHeight: 26,
    maxWidth: 580,
  },

  featureGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.lg,
    justifyContent: 'center',
  },
  featureCard: {
    width: 340,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    gap: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
    ...Shadow.sm,
  },
  featureIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.xs,
  },
  featureTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 18,
    color: Colors.neutral[800],
  },
  featureDesc: {
    fontFamily: Fonts.regular,
    fontSize: 14,
    color: Colors.neutral[500],
    lineHeight: 22,
  },

  stepsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.lg,
    justifyContent: 'center',
    maxWidth: maxW,
    alignSelf: 'center',
    width: '100%',
    paddingHorizontal: sectionPad,
  },
  step: {
    width: 220,
    alignItems: 'center',
    gap: Spacing.sm,
    position: 'relative',
  },
  stepNum: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary[50],
    borderWidth: 2,
    borderColor: Colors.primary[200],
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepNumText: {
    fontFamily: Fonts.bold,
    fontSize: 18,
    color: Colors.primary[600],
  },
  stepLine: {
    position: 'absolute',
    top: 28,
    left: '60%',
    right: '-60%',
    height: 2,
    backgroundColor: Colors.primary[100],
  },
  stepTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 16,
    color: Colors.neutral[800],
    textAlign: 'center',
  },
  stepDesc: {
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: Colors.neutral[500],
    textAlign: 'center',
    lineHeight: 18,
  },

  platformBanner: {
    flexDirection: 'row',
    borderRadius: Radius.xl,
    overflow: 'hidden',
    ...Shadow.md,
    flexWrap: 'wrap',
  },
  platformImage: {
    flex: 1,
    minHeight: 380,
    minWidth: 280,
  },
  platformContent: {
    flex: 1,
    backgroundColor: Colors.neutral[800],
    padding: Spacing.xl,
    gap: Spacing.md,
    minWidth: 300,
  },
  platformTitle: {
    fontFamily: Fonts.bold,
    fontSize: 30,
    color: Colors.neutral[0],
    lineHeight: 38,
  },
  platformDesc: {
    fontFamily: Fonts.regular,
    fontSize: 15,
    color: Colors.neutral[400],
    lineHeight: 24,
  },
  platformFeatures: { gap: Spacing.sm },
  platformFeatureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  platformFeatureText: {
    fontFamily: Fonts.medium,
    fontSize: 14,
    color: Colors.neutral[200],
  },

  proGrid: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: Spacing.lg,
    flexWrap: 'wrap',
    marginBottom: Spacing.xl,
    maxWidth: maxW,
    alignSelf: 'center',
    width: '100%',
    paddingHorizontal: sectionPad,
  },
  proCard: {
    alignItems: 'center',
    gap: Spacing.sm,
    width: 140,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.xl,
    paddingVertical: Spacing.lg,
    paddingHorizontal: Spacing.md,
    ...Shadow.sm,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
  },
  proIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  proLabel: {
    fontFamily: Fonts.semiBold,
    fontSize: 13,
    color: Colors.neutral[700],
    textAlign: 'center',
  },
  proBenefits: {
    gap: Spacing.sm,
    maxWidth: 500,
    alignSelf: 'center',
    width: '100%',
    marginBottom: Spacing.xl,
  },
  benefitRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  benefitText: {
    fontFamily: Fonts.medium,
    fontSize: 15,
    color: Colors.neutral[700],
  },
  proCtaBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.teal[500],
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
    alignSelf: 'center',
  },
  proCtaBtnText: { fontFamily: Fonts.semiBold, fontSize: 15, color: '#fff' },

  testimonialsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.lg,
    justifyContent: 'center',
  },
  testimonialCard: {
    width: 340,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    gap: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
    ...Shadow.sm,
  },
  stars: { flexDirection: 'row', gap: 3 },
  testimonialText: {
    fontFamily: Fonts.regular,
    fontSize: 15,
    color: Colors.neutral[700],
    lineHeight: 23,
    fontStyle: 'italic',
  },
  testimonialAuthor: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  testimonialAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
  },
  testimonialAvatarText: { fontFamily: Fonts.bold, fontSize: 14, color: '#fff' },
  testimonialName: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.neutral[800] },
  testimonialLocation: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[400] },

  pricingGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.lg,
    justifyContent: 'center',
    maxWidth: maxW,
    alignSelf: 'center',
    width: '100%',
    paddingHorizontal: sectionPad,
  },
  pricingCard: {
    width: 320,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    gap: Spacing.md,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
    position: 'relative',
  },
  pricingCardFeatured: {
    borderColor: Colors.primary[400],
    ...Shadow.md,
  },
  pricingBadge: {
    position: 'absolute',
    top: -12,
    alignSelf: 'center',
    backgroundColor: Colors.primary[500],
    paddingHorizontal: Spacing.md,
    paddingVertical: 4,
    borderRadius: Radius.full,
  },
  pricingBadgeText: { fontFamily: Fonts.semiBold, fontSize: 12, color: '#fff' },
  pricingName: { fontFamily: Fonts.bold, fontSize: 18 },
  pricingPrice: { gap: 2 },
  pricingAmount: { fontFamily: Fonts.bold, fontSize: 32, color: Colors.neutral[800] },
  pricingPeriod: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[400] },
  pricingFeatures: { gap: Spacing.sm },
  pricingFeatureRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  pricingFeatureText: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[600] },
  pricingCta: {
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
    alignItems: 'center',
    marginTop: Spacing.sm,
  },
  pricingCtaPrimary: { backgroundColor: Colors.primary[500] },
  pricingCtaSecondary: { backgroundColor: Colors.teal[500] },
  pricingCtaOutline: { borderWidth: 1.5, borderColor: Colors.neutral[300] },
  pricingCtaText: { fontFamily: Fonts.semiBold, fontSize: 15, color: '#fff' },
  pricingCtaTextOutline: { color: Colors.neutral[700] },

  finalCta: {
    paddingVertical: 80,
    alignItems: 'center',
    gap: Spacing.lg,
    overflow: 'hidden',
    paddingHorizontal: sectionPad,
  },
  finalCtaTitle: {
    fontFamily: Fonts.bold,
    fontSize: 36,
    color: '#fff',
    textAlign: 'center',
    lineHeight: 44,
  },
  finalCtaSub: {
    fontFamily: Fonts.regular,
    fontSize: 18,
    color: 'rgba(255,255,255,0.75)',
    textAlign: 'center',
    lineHeight: 28,
    maxWidth: 520,
  },
  finalCtaBtn: {
    backgroundColor: '#fff',
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
    marginTop: Spacing.sm,
  },
  finalCtaBtnText: {
    fontFamily: Fonts.semiBold,
    fontSize: 16,
    color: Colors.primary[600],
  },
  finalCtaNote: {
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: 'rgba(255,255,255,0.5)',
  },
  demoBanner: {
    backgroundColor: Colors.warning[50],
    borderBottomWidth: 1,
    borderBottomColor: Colors.warning[200],
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    alignItems: 'center',
  },
  demoBannerText: {
    fontFamily: Fonts.medium,
    fontSize: 12,
    color: Colors.warning[700],
    textAlign: 'center',
    lineHeight: 18,
  },
  demoBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.35)',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm + 2,
    borderRadius: Radius.md,
    marginTop: Spacing.md,
    alignSelf: 'flex-start',
  },
  demoBtnText: {
    fontFamily: Fonts.semiBold,
    fontSize: 14,
    color: '#fff',
  },
});
