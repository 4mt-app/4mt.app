import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import { useDemo } from '@/lib/demoContext';
import {
  Building2, FileText, Shield, CircleCheck, ChevronRight,
  Sparkles, Heart, Flower2, Users, Clock, ArrowRight,
  Play, RotateCcw
} from 'lucide-react-native';

const SCENARIO_STEPS = [
  {
    key: 'declaration',
    actor: 'Pompes funèbres',
    icon: Building2,
    color: Colors.primary[500],
    title: 'Déclaration de décès',
    desc: 'Les pompes funèbres (Société Moreau & Fils) déclarent le décès de Henri Moreau, né le 12 mars 1948, sur la plateforme 4MT. Le dossier est identifié par son numéro 4MT-2026-0091.',
    action: 'Valider la déclaration',
    badge: 'Pompes funèbres',
  },
  {
    key: 'mairie',
    actor: 'Mairie',
    icon: FileText,
    color: Colors.teal[500],
    title: 'Validation par la Mairie',
    desc: 'La Mairie de Lyon 3e reçoit la notification et valide l\'identité du défunt. Le décès est enregistré dans le registre civil avec le numéro 2026-LYON-04892.',
    action: 'Enregistrer et valider',
    badge: 'Mairie',
  },
  {
    key: 'acte',
    actor: 'Système',
    icon: Shield,
    color: Colors.sage[500],
    title: 'Génération de l\'acte de décès',
    desc: 'L\'acte de décès numérique est généré automatiquement et transmis aux organismes concernés : BNP Paribas, AXA Vie, Direction des Finances Publiques, CAF, employeur, bailleur et notaire.',
    action: 'Générer et transmettre',
    badge: 'Automatique',
  },
  {
    key: 'activation',
    actor: 'Système 4MT',
    icon: CircleCheck,
    color: Colors.success[500],
    title: 'Activation du dossier 4MT',
    desc: 'Le dossier 4MT de Henri Moreau est activé. La personne de confiance (Pauline Moreau) est notifiée par email sécurisé. Tous les accès sont débloqués.',
    action: 'Activer le dossier complet',
    badge: 'Activation',
  },
];

const DEMO_MODULES = [
  { label: 'Espace utilisateur', sub: 'Héritage, funérailles, questionnaire IA', icon: Heart, color: Colors.teal[400], route: '/web/dashboard' },
  { label: 'Personne de confiance', sub: 'Accès dossier, timeline, actions', icon: Users, color: Colors.primary[500], route: '/web/confiance' },
  { label: 'Interface B2B', sub: 'Dossiers, transmission, statuts', icon: Building2, color: Colors.sage[500], route: '/web/pro' },
  { label: 'Démarches & courriers', sub: 'Organismes, courriers IA générés', icon: FileText, color: Colors.success[500], route: '/(tabs)/demarches' },
  { label: 'Questionnaire IA', sub: 'Recommandations personnalisées', icon: Sparkles, color: Colors.warning[500], route: '/questionnaire' },
  { label: 'Volontés funéraires', sub: 'Cérémonie, musique, lieu', icon: Flower2, color: Colors.primary[400], route: '/(tabs)/funerailles' },
];

export default function DemoPage() {
  const router = useRouter();
  const { step, startDemo, advanceStep, resetDemo, isDemo } = useDemo();
  const [animating, setAnimating] = useState(false);

  const currentStepIdx = ['idle', 'declaration', 'mairie', 'acte', 'activation', 'active'].indexOf(step);
  const isComplete = step === 'active';

  const handleAction = () => {
    setAnimating(true);
    setTimeout(() => {
      advanceStep();
      setAnimating(false);
    }, 800);
  };

  const handleStart = () => {
    startDemo();
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerBadge}>
          <Play size={12} color={Colors.primary[400]} strokeWidth={2} />
          <Text style={styles.headerBadgeText}>Mode démonstration interactif</Text>
        </View>
        <Text style={styles.headerTitle}>Démo complète 4MT</Text>
        <Text style={styles.headerSub}>
          Simulez le processus complet depuis la déclaration de décès jusqu'à l'activation du dossier et l'accès à tous les espaces.
        </Text>
      </View>

      {/* Dossier simulé */}
      <View style={styles.dossierCard}>
        <View style={styles.dossierLeft}>
          <View style={styles.dossierAvatar}>
            <Text style={styles.dossierAvatarText}>HM</Text>
          </View>
          <View>
            <Text style={styles.dossierName}>Henri Moreau</Text>
            <Text style={styles.dossierSub}>Dossier 4MT-2026-0091 · Lyon 3e</Text>
            <Text style={styles.dossierDate}>Décès : 22 avril 2026</Text>
          </View>
        </View>
        <View style={[styles.dossierStatus, isComplete && styles.dossierStatusActive]}>
          <Text style={[styles.dossierStatusText, isComplete && styles.dossierStatusTextActive]}>
            {isComplete ? 'Actif' : step === 'idle' ? 'En attente' : 'En cours'}
          </Text>
        </View>
      </View>

      {/* Scénario steps */}
      {step === 'idle' ? (
        <View style={styles.startBlock}>
          <View style={styles.startIconWrap}>
            <Play size={36} color={Colors.primary[500]} strokeWidth={1.5} />
          </View>
          <Text style={styles.startTitle}>Prêt à lancer la démonstration</Text>
          <Text style={styles.startSub}>
            Le scénario simulera la déclaration de décès par les pompes funèbres, la validation par la mairie, la génération de l'acte et l'activation complète du dossier 4MT.
          </Text>
          <TouchableOpacity style={styles.startBtn} onPress={handleStart} activeOpacity={0.88}>
            <Play size={18} color="#fff" strokeWidth={2} />
            <Text style={styles.startBtnText}>Lancer le scénario</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.stepsBlock}>
          <Text style={styles.stepsTitle}>Scénario en cours</Text>
          {SCENARIO_STEPS.map((s, i) => {
            const Icon = s.icon;
            const stepIdx = i + 1;
            const isDone = currentStepIdx > stepIdx;
            const isCurrent = currentStepIdx === stepIdx;
            const isPending = currentStepIdx < stepIdx;

            return (
              <View key={s.key} style={[styles.stepRow, isDone && styles.stepRowDone]}>
                <View style={[styles.stepNum, isDone && styles.stepNumDone, isCurrent && { backgroundColor: s.color }]}>
                  {isDone
                    ? <CircleCheck size={16} color="#fff" strokeWidth={2} />
                    : <Text style={[styles.stepNumText, (isCurrent) && { color: '#fff' }]}>{stepIdx}</Text>
                  }
                </View>
                <View style={styles.stepBody}>
                  <View style={styles.stepActorRow}>
                    <Icon size={14} color={isPending ? Colors.neutral[400] : s.color} strokeWidth={1.5} />
                    <Text style={[styles.stepActor, isPending && styles.stepActorPending]}>{s.actor}</Text>
                    {isDone && (
                      <View style={styles.stepDoneBadge}>
                        <Text style={styles.stepDoneBadgeText}>Effectué</Text>
                      </View>
                    )}
                  </View>
                  <Text style={[styles.stepTitle, isPending && styles.stepTitlePending]}>{s.title}</Text>
                  {isCurrent && (
                    <>
                      <Text style={styles.stepDesc}>{s.desc}</Text>
                      <TouchableOpacity
                        style={[styles.stepBtn, { backgroundColor: s.color }, animating && styles.stepBtnLoading]}
                        onPress={handleAction}
                        activeOpacity={0.85}
                        disabled={animating}
                      >
                        <Text style={styles.stepBtnText}>
                          {animating ? 'Traitement...' : s.action}
                        </Text>
                        {!animating && <ChevronRight size={14} color="#fff" strokeWidth={2} />}
                      </TouchableOpacity>
                    </>
                  )}
                </View>
              </View>
            );
          })}
        </View>
      )}

      {/* Modules débloqués */}
      {isComplete && (
        <View style={styles.modulesBlock}>
          <View style={styles.modulesHeader}>
            <CircleCheck size={22} color={Colors.success[500]} strokeWidth={1.5} />
            <Text style={styles.modulesTitle}>Dossier activé — tous les espaces sont accessibles</Text>
          </View>
          <Text style={styles.modulesSub}>
            Naviguez librement dans chaque module. Toutes les données sont simulées pour la démonstration.
          </Text>
          <View style={styles.modulesGrid}>
            {DEMO_MODULES.map((m, i) => {
              const Icon = m.icon;
              return (
                <TouchableOpacity
                  key={i}
                  style={styles.moduleCard}
                  onPress={() => router.push(m.route as any)}
                  activeOpacity={0.85}
                >
                  <View style={[styles.moduleIcon, { backgroundColor: `${m.color}18` }]}>
                    <Icon size={22} color={m.color} strokeWidth={1.5} />
                  </View>
                  <Text style={styles.moduleLabel}>{m.label}</Text>
                  <Text style={styles.moduleSub}>{m.sub}</Text>
                  <View style={styles.moduleArrow}>
                    <ArrowRight size={14} color={m.color} strokeWidth={2} />
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>

          <TouchableOpacity style={styles.resetBtn} onPress={resetDemo} activeOpacity={0.8}>
            <RotateCcw size={14} color={Colors.neutral[500]} strokeWidth={2} />
            <Text style={styles.resetBtnText}>Recommencer la démonstration</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[50] },
  content: { paddingBottom: 48 },

  header: {
    backgroundColor: Colors.neutral[900],
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xxl,
    paddingBottom: Spacing.xl,
    alignItems: 'center',
  },
  headerBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: Spacing.md,
    paddingVertical: 5,
    borderRadius: Radius.full,
    marginBottom: Spacing.md,
  },
  headerBadgeText: { fontFamily: Fonts.medium, fontSize: 12, color: Colors.primary[300] },
  headerTitle: { fontFamily: Fonts.bold, fontSize: 28, color: '#fff', textAlign: 'center', marginBottom: Spacing.sm },
  headerSub: { fontFamily: Fonts.regular, fontSize: 15, color: Colors.neutral[400], textAlign: 'center', lineHeight: 22, maxWidth: 520 },

  dossierCard: {
    marginHorizontal: Spacing.lg,
    marginTop: Spacing.lg,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.lg,
    padding: Spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...Shadow.sm,
  },
  dossierLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  dossierAvatar: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: Colors.primary[100],
    alignItems: 'center', justifyContent: 'center',
  },
  dossierAvatarText: { fontFamily: Fonts.bold, fontSize: 16, color: Colors.primary[600] },
  dossierName: { fontFamily: Fonts.semiBold, fontSize: 15, color: Colors.neutral[800] },
  dossierSub: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500], marginTop: 2 },
  dossierDate: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[400] },
  dossierStatus: {
    paddingHorizontal: Spacing.sm, paddingVertical: 4,
    borderRadius: Radius.full,
    backgroundColor: Colors.neutral[100],
  },
  dossierStatusActive: { backgroundColor: Colors.success[50] },
  dossierStatusText: { fontFamily: Fonts.semiBold, fontSize: 12, color: Colors.neutral[500] },
  dossierStatusTextActive: { color: Colors.success[600] },

  startBlock: {
    margin: Spacing.lg,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.lg,
    padding: Spacing.xl,
    alignItems: 'center',
    ...Shadow.sm,
  },
  startIconWrap: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: Colors.primary[50],
    alignItems: 'center', justifyContent: 'center',
    marginBottom: Spacing.md,
  },
  startTitle: { fontFamily: Fonts.bold, fontSize: 20, color: Colors.neutral[800], marginBottom: Spacing.sm, textAlign: 'center' },
  startSub: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[500], textAlign: 'center', lineHeight: 21, marginBottom: Spacing.lg, maxWidth: 480 },
  startBtn: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.primary[500],
    paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md,
    borderRadius: Radius.md,
  },
  startBtnText: { fontFamily: Fonts.semiBold, fontSize: 16, color: '#fff' },

  stepsBlock: {
    margin: Spacing.lg,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    ...Shadow.sm,
  },
  stepsTitle: { fontFamily: Fonts.semiBold, fontSize: 13, color: Colors.neutral[500], textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: Spacing.md },
  stepRow: {
    flexDirection: 'row',
    gap: Spacing.md,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  stepRowDone: { opacity: 0.6 },
  stepNum: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center', justifyContent: 'center',
    marginTop: 2, flexShrink: 0,
  },
  stepNumDone: { backgroundColor: Colors.success[500] },
  stepNumText: { fontFamily: Fonts.bold, fontSize: 13, color: Colors.neutral[500] },
  stepBody: { flex: 1, gap: Spacing.xs },
  stepActorRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  stepActor: { fontFamily: Fonts.semiBold, fontSize: 12, color: Colors.neutral[600] },
  stepActorPending: { color: Colors.neutral[400] },
  stepDoneBadge: {
    backgroundColor: Colors.success[50], borderRadius: Radius.full,
    paddingHorizontal: 8, paddingVertical: 2,
  },
  stepDoneBadgeText: { fontFamily: Fonts.semiBold, fontSize: 11, color: Colors.success[600] },
  stepTitle: { fontFamily: Fonts.semiBold, fontSize: 15, color: Colors.neutral[800] },
  stepTitlePending: { color: Colors.neutral[400] },
  stepDesc: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[600], lineHeight: 19, marginTop: 2 },
  stepBtn: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.xs,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderRadius: Radius.md, alignSelf: 'flex-start', marginTop: Spacing.sm,
  },
  stepBtnLoading: { opacity: 0.7 },
  stepBtnText: { fontFamily: Fonts.semiBold, fontSize: 14, color: '#fff' },

  modulesBlock: {
    margin: Spacing.lg,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    ...Shadow.sm,
  },
  modulesHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.xs },
  modulesTitle: { fontFamily: Fonts.bold, fontSize: 17, color: Colors.neutral[800], flex: 1 },
  modulesSub: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[500], lineHeight: 19, marginBottom: Spacing.lg },
  modulesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },
  moduleCard: {
    flex: 1, minWidth: 240,
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.md,
    padding: Spacing.md,
    gap: Spacing.xs,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
  },
  moduleIcon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  moduleLabel: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.neutral[800] },
  moduleSub: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500] },
  moduleArrow: { marginTop: Spacing.xs },

  resetBtn: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.xs,
    alignSelf: 'center', marginTop: Spacing.lg,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.neutral[200],
  },
  resetBtnText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[500] },
});
