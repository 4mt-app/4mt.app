import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import Card from '@/components/Card';
import Badge from '@/components/Badge';
import ProgressBar from '@/components/ProgressBar';
import { Heart, FileText, Flower2, Users, Sparkles, ChevronRight, Shield, CircleCheck, Clock, Bell, Download, LogOut, Settings, Building2, Lock, CircleAlert as AlertCircle } from 'lucide-react-native';

const sections = [
  { key: 'heritage', label: 'Héritage émotionnel', icon: Heart, progress: 0.6, color: Colors.teal[400], route: '/(tabs)/heritage' },
  { key: 'funerailles', label: 'Volontés funéraires', icon: Flower2, progress: 0.3, color: Colors.primary[400], route: '/(tabs)/funerailles' },
  { key: 'demarches', label: 'Démarches admin.', icon: FileText, progress: 0.1, color: Colors.sage[500], route: '/(tabs)/demarches' },
  { key: 'confiance', label: 'Personne de confiance', icon: Users, progress: 1.0, color: Colors.success[500], route: '/(tabs)/profil' },
];

const recentActivity = [
  { icon: CircleCheck, text: 'Personne de confiance désignée', time: 'Hier à 14h32', color: Colors.success[500] },
  { icon: Heart, text: 'Message ajouté pour Léa & Thomas', time: 'Il y a 3 jours', color: Colors.teal[500] },
  { icon: Clock, text: 'Questionnaire IA en cours (40%)', time: 'Il y a 5 jours', color: Colors.warning[500] },
  { icon: FileText, text: 'Organisme "BNP Paribas" ajouté', time: 'Il y a 1 semaine', color: Colors.neutral[500] },
];

const notifications = [
  { text: 'Complétez vos volontés funéraires (30%)', type: 'warning' },
  { text: 'Questionnaire IA non terminé', type: 'info' },
];

export default function WebDashboard() {
  const router = useRouter();
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const overallProgress = sections.reduce((sum, s) => sum + s.progress, 0) / sections.length;

  return (
    <View style={styles.root}>
      {/* Sidebar */}
      <View style={styles.sidebar}>
        <View style={styles.sidebarTop}>
          <View style={styles.sidebarAvatar}>
            <Text style={styles.sidebarAvatarText}>MD</Text>
          </View>
          <Text style={styles.sidebarName}>Marie Dupont</Text>
          <Text style={styles.sidebarEmail}>marie.dupont@exemple.fr</Text>
          <Badge label="Compte gratuit" variant="neutral" />
        </View>

        <View style={styles.sidebarNav}>
          {[
            { icon: Sparkles, label: 'Questionnaire IA', route: '/questionnaire' },
            { icon: Heart, label: 'Héritage', route: '/(tabs)/heritage' },
            { icon: Flower2, label: 'Funérailles', route: '/(tabs)/funerailles' },
            { icon: FileText, label: 'Démarches', route: '/(tabs)/demarches' },
            { icon: Users, label: 'Personne de confiance', route: '/(tabs)/profil' },
            { icon: Shield, label: 'Sécurité', route: '/(tabs)/profil' },
            { icon: Settings, label: 'Paramètres', route: '/(tabs)/profil' },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <TouchableOpacity
                key={i}
                style={styles.sidebarNavItem}
                onPress={() => router.push(item.route as any)}
                activeOpacity={0.7}
              >
                <Icon size={18} color={Colors.neutral[500]} strokeWidth={1.5} />
                <Text style={styles.sidebarNavLabel}>{item.label}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <TouchableOpacity
          style={styles.sidebarLogout}
          onPress={() => router.replace('/')}
          activeOpacity={0.8}
        >
          <LogOut size={16} color={Colors.neutral[400]} strokeWidth={1.5} />
          <Text style={styles.sidebarLogoutText}>Se déconnecter</Text>
        </TouchableOpacity>
      </View>

      {/* Main content */}
      <ScrollView style={styles.main} contentContainerStyle={styles.mainContent} showsVerticalScrollIndicator={false}>
        {/* Bandeau prototype */}
        <View style={styles.demoBanner}>
          <AlertCircle size={13} color={Colors.warning[700]} strokeWidth={1.5} />
          <Text style={styles.demoBannerText}>Prototype · Données de démonstration — connexion et données simulées</Text>
        </View>

        {/* Header */}
        <View style={styles.mainHeader}>
          <View>
            <Text style={styles.welcomeTitle}>Bonjour, Marie</Text>
            <Text style={styles.welcomeDate}>Vendredi 24 avril 2026 · Dossier en cours</Text>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.notifBtn} activeOpacity={0.7}>
              <Bell size={20} color={Colors.neutral[600]} strokeWidth={1.5} />
              <View style={styles.notifDot} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.exportBtn} activeOpacity={0.8}>
              <Download size={16} color={Colors.primary[500]} strokeWidth={1.5} />
              <Text style={styles.exportText}>Exporter mon dossier</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Notifications */}
        {notifications.map((n, i) => (
          <View key={i} style={[styles.notifBanner, n.type === 'warning' && styles.notifBannerWarning]}>
            <AlertCircle size={16} color={n.type === 'warning' ? Colors.warning[600] : Colors.primary[600]} strokeWidth={1.5} />
            <Text style={[styles.notifBannerText, n.type === 'warning' && styles.notifBannerTextWarning]}>
              {n.text}
            </Text>
            <TouchableOpacity activeOpacity={0.7}>
              <Text style={styles.notifBannerCta}>Compléter →</Text>
            </TouchableOpacity>
          </View>
        ))}

        {/* Progress overview */}
        <View style={styles.row}>
          <Card variant="elevated" style={styles.progressCard}>
            <View style={styles.progressTop}>
              <View>
                <Text style={styles.cardTitle}>Mon dossier 4MT</Text>
                <Text style={styles.cardSub}>Complétion globale</Text>
              </View>
              <View style={styles.percentCircle}>
                <Text style={styles.percentText}>{Math.round(overallProgress * 100)}%</Text>
              </View>
            </View>
            <ProgressBar progress={overallProgress} color={Colors.primary[500]} height={10} />
            <View style={styles.sectionsGrid}>
              {sections.map((s) => {
                const Icon = s.icon;
                return (
                  <TouchableOpacity
                    key={s.key}
                    style={styles.sectionItem}
                    onPress={() => router.push(s.route as any)}
                    activeOpacity={0.8}
                  >
                    <View style={[styles.sectionItemIcon, { backgroundColor: `${s.color}18` }]}>
                      <Icon size={16} color={s.color} strokeWidth={1.5} />
                    </View>
                    <Text style={styles.sectionItemLabel}>{s.label}</Text>
                    <ProgressBar progress={s.progress} color={s.color} height={4} />
                    <Text style={[styles.sectionItemPct, { color: s.color }]}>
                      {Math.round(s.progress * 100)}%
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </Card>

          {/* AI banner */}
          <View style={styles.rightCol}>
            <TouchableOpacity
              style={styles.aiBanner}
              onPress={() => router.push('/questionnaire')}
              activeOpacity={0.88}
            >
              <View style={styles.aiIconWrap}>
                <Sparkles size={28} color={Colors.primary[500]} strokeWidth={1.5} />
              </View>
              <Text style={styles.aiBannerTitle}>Questionnaire IA</Text>
              <Text style={styles.aiBannerSub}>
                Continuez votre questionnaire guidé pour obtenir votre recommandation de cérémonie personnalisée.
              </Text>
              <ProgressBar progress={0.4} color={Colors.primary[400]} height={6} />
              <Text style={styles.aiBannerPct}>40% complété</Text>
              <View style={styles.aiBannerBtn}>
                <Text style={styles.aiBannerBtnText}>Reprendre</Text>
                <ChevronRight size={14} color="#fff" strokeWidth={2} />
              </View>
            </TouchableOpacity>

            {/* Security card */}
            <Card variant="bordered">
              <View style={styles.securityRow}>
                <Shield size={20} color={Colors.success[500]} strokeWidth={1.5} />
                <View style={styles.securityText}>
                  <Text style={styles.securityTitle}>Données sécurisées</Text>
                  <Text style={styles.securityBody}>Chiffrement AES-256 · RGPD · FranceConnect</Text>
                </View>
                <Badge label="Actif" variant="success" />
              </View>
            </Card>
          </View>
        </View>

        {/* Quick access */}
        <Text style={styles.sectionTitle}>Accès rapide</Text>
        <View style={styles.quickGrid}>
          {sections.map((s) => {
            const Icon = s.icon;
            return (
              <TouchableOpacity
                key={s.key}
                style={styles.quickCard}
                onPress={() => router.push(s.route as any)}
                activeOpacity={0.85}
              >
                <View style={[styles.quickIcon, { backgroundColor: `${s.color}18` }]}>
                  <Icon size={22} color={s.color} strokeWidth={1.5} />
                </View>
                <Text style={styles.quickLabel}>{s.label}</Text>
                <Badge
                  label={s.progress === 1 ? 'Complet' : s.progress > 0.5 ? 'En cours' : 'À commencer'}
                  variant={s.progress === 1 ? 'success' : s.progress > 0.5 ? 'warning' : 'neutral'}
                />
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Recent activity */}
        <Text style={styles.sectionTitle}>Activité récente</Text>
        <Card variant="bordered">
          {recentActivity.map((a, i) => {
            const Icon = a.icon;
            return (
              <View key={i} style={[styles.activityRow, i < recentActivity.length - 1 && styles.activityDivider]}>
                <View style={[styles.activityIcon, { backgroundColor: `${a.color}18` }]}>
                  <Icon size={14} color={a.color} strokeWidth={2} />
                </View>
                <Text style={styles.activityText}>{a.text}</Text>
                <Text style={styles.activityTime}>{a.time}</Text>
              </View>
            );
          })}
        </Card>

        <View style={{ height: Spacing.xl }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: Colors.neutral[50],
    minHeight: 600,
  },
  sidebar: {
    width: 260,
    backgroundColor: Colors.neutral[0],
    borderRightWidth: 1,
    borderRightColor: Colors.neutral[100],
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.lg,
    justifyContent: 'space-between',
  },
  sidebarTop: {
    alignItems: 'center',
    gap: Spacing.sm,
    paddingBottom: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
    marginBottom: Spacing.md,
  },
  sidebarAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
  },
  sidebarAvatarText: { fontFamily: Fonts.bold, fontSize: 22, color: '#fff' },
  sidebarName: { fontFamily: Fonts.semiBold, fontSize: 16, color: Colors.neutral[800] },
  sidebarEmail: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500] },
  sidebarNav: { flex: 1, gap: Spacing.xs },
  sidebarNavItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm + 2,
    borderRadius: Radius.sm,
  },
  sidebarNavLabel: { fontFamily: Fonts.medium, fontSize: 14, color: Colors.neutral[600] },
  sidebarLogout: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  sidebarLogoutText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[400] },

  main: { flex: 1 },
  mainContent: { padding: Spacing.xl, gap: Spacing.lg },
  mainHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  welcomeTitle: { fontFamily: Fonts.bold, fontSize: 26, color: Colors.neutral[800] },
  welcomeDate: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[500], marginTop: 3 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  notifBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.neutral[0],
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.sm,
    position: 'relative',
  },
  notifDot: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.error[500],
    borderWidth: 1.5,
    borderColor: Colors.neutral[0],
  },
  exportBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    backgroundColor: Colors.primary[50],
    borderRadius: Radius.sm,
    borderWidth: 1,
    borderColor: Colors.primary[100],
  },
  exportText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.primary[600] },

  notifBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.primary[50],
    borderRadius: Radius.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm + 2,
    borderLeftWidth: 3,
    borderLeftColor: Colors.primary[400],
  },
  notifBannerWarning: {
    backgroundColor: Colors.warning[50],
    borderLeftColor: Colors.warning[500],
  },
  notifBannerText: {
    flex: 1,
    fontFamily: Fonts.medium,
    fontSize: 13,
    color: Colors.primary[700],
  },
  notifBannerTextWarning: { color: Colors.warning[700] },
  notifBannerCta: { fontFamily: Fonts.semiBold, fontSize: 13, color: Colors.primary[500] },

  row: { flexDirection: 'row', gap: Spacing.lg, flexWrap: 'wrap', alignItems: 'flex-start' },
  progressCard: { flex: 2, minWidth: 300, gap: Spacing.md },
  progressTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  cardTitle: { fontFamily: Fonts.bold, fontSize: 18, color: Colors.neutral[800] },
  cardSub: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500], marginTop: 2 },
  percentCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary[50],
    borderWidth: 2,
    borderColor: Colors.primary[200],
    alignItems: 'center',
    justifyContent: 'center',
  },
  percentText: { fontFamily: Fonts.bold, fontSize: 16, color: Colors.primary[600] },
  sectionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
    marginTop: Spacing.sm,
  },
  sectionItem: {
    flex: 1,
    minWidth: 140,
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.md,
    padding: Spacing.md,
    gap: 6,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
  },
  sectionItemIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionItemLabel: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[700] },
  sectionItemPct: { fontFamily: Fonts.semiBold, fontSize: 13 },

  rightCol: { flex: 1, minWidth: 240, gap: Spacing.md },
  aiBanner: {
    backgroundColor: Colors.primary[600],
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    gap: Spacing.sm,
  },
  aiIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  aiBannerTitle: { fontFamily: Fonts.bold, fontSize: 18, color: '#fff' },
  aiBannerSub: { fontFamily: Fonts.regular, fontSize: 13, color: 'rgba(255,255,255,0.75)', lineHeight: 19 },
  aiBannerPct: { fontFamily: Fonts.medium, fontSize: 12, color: 'rgba(255,255,255,0.6)' },
  aiBannerBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: Radius.sm,
    paddingVertical: Spacing.sm + 2,
    marginTop: Spacing.xs,
  },
  aiBannerBtnText: { fontFamily: Fonts.semiBold, fontSize: 14, color: '#fff' },

  securityRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  securityText: { flex: 1 },
  securityTitle: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.neutral[800] },
  securityBody: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500], marginTop: 2 },

  sectionTitle: { fontFamily: Fonts.semiBold, fontSize: 17, color: Colors.neutral[700] },
  quickGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  quickCard: {
    flex: 1,
    minWidth: 160,
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.lg,
    padding: Spacing.md,
    gap: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.neutral[100],
    ...Shadow.sm,
  },
  quickIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickLabel: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.neutral[800] },

  activityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.sm + 2,
  },
  activityDivider: { borderBottomWidth: 1, borderBottomColor: Colors.neutral[100] },
  activityIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activityText: { flex: 1, fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[700] },
  activityTime: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[400] },
  demoBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: Colors.warning[50],
    borderRadius: Radius.sm,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.warning[200],
  },
  demoBannerText: {
    fontFamily: Fonts.medium,
    fontSize: 12,
    color: Colors.warning[700],
  },
});
