import { useState } from 'react';
import { ScrollView, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import Card from '@/components/Card';
import Badge from '@/components/Badge';
import {
  Plus, Heart, Mic, Video, FileText, Users, ChevronRight,
  Lock, Star, Sparkles, Play
} from 'lucide-react-native';

type MessageType = 'text' | 'audio' | 'video';

const messages = [
  {
    id: '1',
    type: 'text' as MessageType,
    title: 'À mes enfants',
    preview: 'Mes chères Léa et Thomas, je voulais vous dire combien...',
    recipient: 'Léa & Thomas',
    date: 'Modifié il y a 3 jours',
    isPremium: false,
  },
  {
    id: '2',
    type: 'audio' as MessageType,
    title: 'Pour mon anniversaire de mariage',
    preview: 'Enregistrement de 3 min 42 sec',
    recipient: 'Marie-Claire',
    date: 'Modifié il y a 1 semaine',
    isPremium: false,
  },
  {
    id: '3',
    type: 'video' as MessageType,
    title: 'Message vidéo posthume',
    preview: 'Vidéo de 8 minutes',
    recipient: 'Toute la famille',
    date: 'Non diffusé',
    isPremium: true,
  },
];

const premiumOptions = [
  { label: 'Vidéo posthume', icon: Video, desc: 'Enregistrez un message vidéo diffusé lors de la cérémonie' },
  { label: 'Message audio', icon: Mic, desc: 'Votre voix, préservée pour toujours' },
  { label: 'Hologramme', icon: Sparkles, desc: 'Technologie holographique pour la cérémonie' },
  { label: 'Réalité augmentée', icon: Star, desc: 'Expérience immersive pour vos proches' },
];

const typeIcons = {
  text: FileText,
  audio: Mic,
  video: Video,
};

const typeColors = {
  text: Colors.primary[500],
  audio: Colors.teal[500],
  video: Colors.sage[600],
};

const typeBg = {
  text: Colors.primary[50],
  audio: Colors.teal[50],
  video: Colors.sage[50],
};

export default function HeritageScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [tab, setTab] = useState<'messages' | 'premium'>('messages');

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.content, { paddingTop: insets.top + Spacing.md }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Héritage émotionnel</Text>
          <Text style={styles.subtitle}>Vos messages pour l'après</Text>
        </View>
        <TouchableOpacity
          style={styles.addBtn}
          activeOpacity={0.8}
          onPress={() => router.push('/message/new')}
        >
          <Plus size={22} color="#fff" strokeWidth={2} />
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={styles.tabRow}>
        <TouchableOpacity
          style={[styles.tabBtn, tab === 'messages' && styles.tabBtnActive]}
          onPress={() => setTab('messages')}
          activeOpacity={0.7}
        >
          <Text style={[styles.tabLabel, tab === 'messages' && styles.tabLabelActive]}>
            Mes messages ({messages.length})
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabBtn, tab === 'premium' && styles.tabBtnActive]}
          onPress={() => setTab('premium')}
          activeOpacity={0.7}
        >
          <Star size={12} color={tab === 'premium' ? Colors.primary[500] : Colors.neutral[400]} strokeWidth={2} />
          <Text style={[styles.tabLabel, tab === 'premium' && styles.tabLabelActive]}>Premium</Text>
        </TouchableOpacity>
      </View>

      {tab === 'messages' ? (
        <>
          {/* Info banner */}
          <Card variant="tinted" style={styles.infoBanner}>
            <View style={styles.infoBannerRow}>
              <Heart size={18} color={Colors.primary[500]} strokeWidth={1.5} />
              <Text style={styles.infoBannerText}>
                Vos messages seront transmis à vos destinataires après validation par votre personne de confiance.
              </Text>
            </View>
          </Card>

          {/* Messages */}
          <View style={styles.messageList}>
            {messages.map((msg) => {
              const Icon = typeIcons[msg.type];
              return (
                <TouchableOpacity key={msg.id} activeOpacity={0.85}>
                  <Card variant="default" style={styles.messageCard}>
                    <View style={styles.messageTop}>
                      <View style={[styles.msgIcon, { backgroundColor: typeBg[msg.type] }]}>
                        <Icon size={18} color={typeColors[msg.type]} strokeWidth={1.5} />
                      </View>
                      <View style={styles.msgInfo}>
                        <View style={styles.msgTitleRow}>
                          <Text style={styles.msgTitle}>{msg.title}</Text>
                          {msg.isPremium && <Badge label="Premium" variant="warning" />}
                        </View>
                        <Text style={styles.msgPreview} numberOfLines={2}>{msg.preview}</Text>
                      </View>
                      <ChevronRight size={16} color={Colors.neutral[300]} strokeWidth={2} />
                    </View>
                    <View style={styles.msgMeta}>
                      <View style={styles.msgRecipient}>
                        <Users size={12} color={Colors.neutral[400]} strokeWidth={1.5} />
                        <Text style={styles.msgRecipientText}>Pour : {msg.recipient}</Text>
                      </View>
                      <Text style={styles.msgDate}>{msg.date}</Text>
                    </View>
                    {msg.type === 'audio' && (
                      <View style={styles.audioPlayer}>
                        <TouchableOpacity style={styles.playBtn} activeOpacity={0.8}>
                          <Play size={14} color="#fff" strokeWidth={2} fill="#fff" />
                        </TouchableOpacity>
                        <View style={styles.waveform}>
                          {Array.from({ length: 30 }).map((_, i) => (
                            <View
                              key={i}
                              style={[styles.waveBar, {
                                height: 4 + Math.sin(i * 0.8) * 8 + Math.random() * 6,
                                backgroundColor: i < 10 ? Colors.teal[400] : Colors.neutral[200]
                              }]}
                            />
                          ))}
                        </View>
                        <Text style={styles.audioTime}>3:42</Text>
                      </View>
                    )}
                  </Card>
                </TouchableOpacity>
              );
            })}
          </View>

          <TouchableOpacity
            style={styles.newMsgBtn}
            activeOpacity={0.85}
            onPress={() => router.push('/message/new')}
          >
            <Plus size={18} color={Colors.primary[500]} strokeWidth={2} />
            <Text style={styles.newMsgText}>Ajouter un nouveau message</Text>
          </TouchableOpacity>
        </>
      ) : (
        <>
          <Card variant="tinted" style={styles.premiumBanner}>
            <View style={styles.premiumBannerContent}>
              <Star size={24} color={Colors.warning[500]} strokeWidth={1.5} />
              <Text style={styles.premiumTitle}>Options Premium</Text>
              <Text style={styles.premiumDesc}>
                Offrez à vos proches une expérience de transmission unique et mémorable grâce à nos options avancées.
              </Text>
            </View>
          </Card>

          <View style={styles.premiumList}>
            {premiumOptions.map((opt, i) => {
              const Icon = opt.icon;
              return (
                <Card key={i} variant="default" style={styles.premiumItem}>
                  <View style={styles.premiumRow}>
                    <View style={styles.premiumIconWrap}>
                      <Icon size={22} color={Colors.primary[500]} strokeWidth={1.5} />
                    </View>
                    <View style={styles.premiumInfo}>
                      <Text style={styles.premiumLabel}>{opt.label}</Text>
                      <Text style={styles.premiumItemDesc}>{opt.desc}</Text>
                    </View>
                    <Badge label="Premium" variant="warning" />
                  </View>
                </Card>
              );
            })}
          </View>

          <TouchableOpacity style={styles.upgradeCta} activeOpacity={0.88}>
            <Star size={16} color="#fff" strokeWidth={1.5} />
            <Text style={styles.upgradeCtaText}>Passer à Premium</Text>
          </TouchableOpacity>
        </>
      )}

      <View style={{ height: Spacing.xl }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[50] },
  content: { paddingHorizontal: Spacing.md, gap: Spacing.md },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    fontFamily: Fonts.bold,
    fontSize: 22,
    color: Colors.neutral[800],
  },
  subtitle: {
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: Colors.neutral[500],
    marginTop: 2,
  },
  addBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.md,
  },
  tabRow: {
    flexDirection: 'row',
    backgroundColor: Colors.neutral[100],
    borderRadius: Radius.md,
    padding: 3,
    gap: 3,
  },
  tabBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.sm,
  },
  tabBtnActive: {
    backgroundColor: Colors.neutral[0],
    ...Shadow.sm,
  },
  tabLabel: {
    fontFamily: Fonts.medium,
    fontSize: 13,
    color: Colors.neutral[400],
  },
  tabLabelActive: {
    color: Colors.neutral[800],
  },
  infoBanner: {},
  infoBannerRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
  },
  infoBannerText: {
    flex: 1,
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: Colors.primary[700],
    lineHeight: 18,
  },
  messageList: { gap: Spacing.sm },
  messageCard: { gap: Spacing.sm },
  messageTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
  },
  msgIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  msgInfo: { flex: 1, gap: 3 },
  msgTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    flexWrap: 'wrap',
  },
  msgTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 15,
    color: Colors.neutral[800],
  },
  msgPreview: {
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: Colors.neutral[500],
    lineHeight: 18,
  },
  msgMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: Spacing.xs,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
  },
  msgRecipient: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  msgRecipientText: {
    fontFamily: Fonts.regular,
    fontSize: 11,
    color: Colors.neutral[500],
  },
  msgDate: {
    fontFamily: Fonts.regular,
    fontSize: 11,
    color: Colors.neutral[400],
  },
  audioPlayer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.sm,
    padding: Spacing.sm,
  },
  playBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: Colors.teal[500],
    alignItems: 'center',
    justifyContent: 'center',
  },
  waveform: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 1.5,
    height: 24,
  },
  waveBar: {
    width: 2.5,
    borderRadius: 2,
  },
  audioTime: {
    fontFamily: Fonts.medium,
    fontSize: 11,
    color: Colors.neutral[500],
  },
  newMsgBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.primary[200],
    borderStyle: 'dashed',
    backgroundColor: Colors.primary[50],
  },
  newMsgText: {
    fontFamily: Fonts.medium,
    fontSize: 14,
    color: Colors.primary[500],
  },
  premiumBanner: { alignItems: 'center' },
  premiumBannerContent: {
    alignItems: 'center',
    gap: Spacing.sm,
  },
  premiumTitle: {
    fontFamily: Fonts.bold,
    fontSize: 18,
    color: Colors.primary[700],
  },
  premiumDesc: {
    fontFamily: Fonts.regular,
    fontSize: 14,
    color: Colors.primary[600],
    textAlign: 'center',
    lineHeight: 20,
  },
  premiumList: { gap: Spacing.sm },
  premiumItem: {},
  premiumRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  premiumIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  premiumInfo: { flex: 1 },
  premiumLabel: {
    fontFamily: Fonts.semiBold,
    fontSize: 14,
    color: Colors.neutral[800],
  },
  premiumItemDesc: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.neutral[500],
    marginTop: 2,
    lineHeight: 16,
  },
  upgradeCta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.warning[500],
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    ...Shadow.md,
  },
  upgradeCtaText: {
    fontFamily: Fonts.semiBold,
    fontSize: 15,
    color: '#fff',
  },
});
