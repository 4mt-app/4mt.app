import { useState } from 'react';
import { ScrollView, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import Card from '@/components/Card';
import Badge from '@/components/Badge';
import {
  Sparkles, ChevronRight, Music, MapPin, Shirt, Flower,
  BookOpen, Users, CircleCheck, CircleDashed, Info, Package
} from 'lucide-react-native';

type SectionStatus = 'done' | 'partial' | 'empty';

const sections = [
  {
    key: 'celebrant',
    label: 'Célébrant',
    icon: Users,
    status: 'done' as SectionStatus,
    summary: 'Cérémonial laïque — Maître Lefebvre',
  },
  {
    key: 'ambiance',
    label: 'Ambiance & cadre',
    icon: MapPin,
    status: 'partial' as SectionStatus,
    summary: 'Jardin / extérieur — À compléter',
  },
  {
    key: 'musique',
    label: 'Musiques',
    icon: Music,
    status: 'partial' as SectionStatus,
    summary: '3 titres sélectionnés',
  },
  {
    key: 'textes',
    label: 'Textes & lectures',
    icon: BookOpen,
    status: 'empty' as SectionStatus,
    summary: 'Aucun texte ajouté',
  },
  {
    key: 'tenue',
    label: 'Tenue vestimentaire',
    icon: Shirt,
    status: 'done' as SectionStatus,
    summary: 'Vêtements décrits et enregistrés',
  },
  {
    key: 'fleurs',
    label: 'Fleurs & décorations',
    icon: Flower,
    status: 'partial' as SectionStatus,
    summary: 'Pivoines et eucalyptus — partiel',
  },
  {
    key: 'objets',
    label: 'Objets dans le cercueil',
    icon: Package,
    status: 'empty' as SectionStatus,
    summary: 'Aucun objet défini',
  },
];

const statusConfig = {
  done: { badge: 'success' as const, label: 'Complété', icon: CircleCheck, color: Colors.success[500] },
  partial: { badge: 'warning' as const, label: 'Partiel', icon: CircleDashed, color: Colors.warning[500] },
  empty: { badge: 'neutral' as const, label: 'À remplir', icon: CircleDashed, color: Colors.neutral[400] },
};

const beliefOptions = [
  { key: 'laïque', label: 'Laïque', desc: 'Cérémonie civile', emoji: '🤝' },
  { key: 'catholique', label: 'Catholique', desc: 'Messe de funérailles', emoji: '⛪' },
  { key: 'protestant', label: 'Protestant', desc: 'Service funèbre', emoji: '✝️' },
  { key: 'musulman', label: 'Musulman', desc: 'Janaza', emoji: '☪️' },
  { key: 'juif', label: 'Juif', desc: 'Levaya', emoji: '✡️' },
  { key: 'bouddhiste', label: 'Bouddhiste', desc: 'Rite bouddhiste', emoji: '☸️' },
  { key: 'autre', label: 'Autre / Mixte', desc: 'Selon mes valeurs', emoji: '🌿' },
];

export default function FuneraillesScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [selectedBelief, setSelectedBelief] = useState('laïque');

  const doneCount = sections.filter(s => s.status === 'done').length;
  const progress = doneCount / sections.length;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.content, { paddingTop: insets.top + Spacing.md }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Mes funérailles</Text>
        <Text style={styles.subtitle}>Organisez selon vos souhaits</Text>
      </View>

      {/* AI Suggestion Banner */}
      <TouchableOpacity
        style={styles.aiSuggestion}
        activeOpacity={0.88}
        onPress={() => router.push('/questionnaire')}
      >
        <View style={styles.aiLeft}>
          <View style={styles.aiIcon}>
            <Sparkles size={20} color={Colors.primary[500]} strokeWidth={1.5} />
          </View>
          <View>
            <Text style={styles.aiTitle}>Suggestion de l'IA</Text>
            <Text style={styles.aiSub}>
              Cérémonie nature, musique douce, textes philosophiques
            </Text>
          </View>
        </View>
        <ChevronRight size={16} color={Colors.primary[500]} strokeWidth={2} />
      </TouchableOpacity>

      {/* Beliefs */}
      <Text style={styles.sectionTitle}>Mes croyances</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.beliefsScroll}>
        <View style={styles.beliefsRow}>
          {beliefOptions.map((b) => (
            <TouchableOpacity
              key={b.key}
              style={[styles.beliefChip, selectedBelief === b.key && styles.beliefChipActive]}
              onPress={() => setSelectedBelief(b.key)}
              activeOpacity={0.75}
            >
              <Text style={styles.beliefEmoji}>{b.emoji}</Text>
              <Text style={[styles.beliefLabel, selectedBelief === b.key && styles.beliefLabelActive]}>
                {b.label}
              </Text>
              <Text style={[styles.beliefDesc, selectedBelief === b.key && styles.beliefDescActive]}>
                {b.desc}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Sections */}
      <Text style={styles.sectionTitle}>
        Mes volontés ({doneCount}/{sections.length} complétés)
      </Text>

      <View style={styles.sectionList}>
        {sections.map((s) => {
          const Icon = s.icon;
          const cfg = statusConfig[s.status];
          const StatusIcon = cfg.icon;
          return (
            <TouchableOpacity key={s.key} activeOpacity={0.85}>
              <Card variant="default" style={styles.sectionCard}>
                <View style={styles.sectionRow}>
                  <View style={[styles.sectionIcon, { backgroundColor: Colors.primary[50] }]}>
                    <Icon size={18} color={Colors.primary[500]} strokeWidth={1.5} />
                  </View>
                  <View style={styles.sectionInfo}>
                    <Text style={styles.sectionLabel}>{s.label}</Text>
                    <Text style={styles.sectionSummary}>{s.summary}</Text>
                  </View>
                  <View style={styles.sectionRight}>
                    <StatusIcon size={16} color={cfg.color} strokeWidth={1.5} />
                    <Badge label={cfg.label} variant={cfg.badge} />
                  </View>
                </View>
              </Card>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Legal notice */}
      <Card variant="bordered" style={styles.legalCard}>
        <View style={styles.legalRow}>
          <Info size={18} color={Colors.neutral[400]} strokeWidth={1.5} />
          <View style={styles.legalContent}>
            <Text style={styles.legalTitle}>Cadre juridique</Text>
            <Text style={styles.legalText}>
              Cette plateforme ne remplace pas un document juridique officiel. Pour donner une valeur légale à vos souhaits, recopiez-les à la main, datez et signez (testament olographe), puis conservez-les avec une pièce d'identité.
            </Text>
            <TouchableOpacity style={styles.legalBtn} activeOpacity={0.8}>
              <Text style={styles.legalBtnText}>Générer un récapitulatif imprimable</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Card>

      <View style={{ height: Spacing.xl }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[50] },
  content: { paddingHorizontal: Spacing.md, gap: Spacing.md },
  header: { marginBottom: Spacing.xs },
  title: {
    fontFamily: Fonts.bold,
    fontSize: 22,
    color: Colors.neutral[800],
  },
  subtitle: {
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: Colors.neutral[500],
    marginTop: 2,
  },
  aiSuggestion: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.primary[50],
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1.5,
    borderColor: Colors.primary[100],
  },
  aiLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    flex: 1,
  },
  aiIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.neutral[0],
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.sm,
  },
  aiTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 14,
    color: Colors.primary[700],
  },
  aiSub: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.primary[500],
    marginTop: 2,
    lineHeight: 16,
    maxWidth: 220,
  },
  sectionTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 16,
    color: Colors.neutral[700],
  },
  beliefsScroll: { marginHorizontal: -Spacing.md },
  beliefsRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
  },
  beliefChip: {
    width: 100,
    padding: Spacing.sm,
    borderRadius: Radius.md,
    backgroundColor: Colors.neutral[0],
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
    gap: 4,
    alignItems: 'center',
    ...Shadow.sm,
  },
  beliefChipActive: {
    borderColor: Colors.primary[400],
    backgroundColor: Colors.primary[50],
  },
  beliefEmoji: { fontSize: 22 },
  beliefLabel: {
    fontFamily: Fonts.semiBold,
    fontSize: 12,
    color: Colors.neutral[700],
    textAlign: 'center',
  },
  beliefLabelActive: { color: Colors.primary[700] },
  beliefDesc: {
    fontFamily: Fonts.regular,
    fontSize: 10,
    color: Colors.neutral[400],
    textAlign: 'center',
    lineHeight: 13,
  },
  beliefDescActive: { color: Colors.primary[500] },
  sectionList: { gap: Spacing.sm },
  sectionCard: {},
  sectionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  sectionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionInfo: { flex: 1 },
  sectionLabel: {
    fontFamily: Fonts.semiBold,
    fontSize: 14,
    color: Colors.neutral[800],
  },
  sectionSummary: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.neutral[500],
    marginTop: 2,
  },
  sectionRight: {
    alignItems: 'flex-end',
    gap: 4,
  },
  legalCard: {},
  legalRow: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  legalContent: { flex: 1, gap: Spacing.sm },
  legalTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 14,
    color: Colors.neutral[700],
  },
  legalText: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.neutral[500],
    lineHeight: 18,
  },
  legalBtn: {
    backgroundColor: Colors.neutral[100],
    borderRadius: Radius.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs + 2,
    alignSelf: 'flex-start',
  },
  legalBtnText: {
    fontFamily: Fonts.medium,
    fontSize: 12,
    color: Colors.neutral[700],
  },
});
