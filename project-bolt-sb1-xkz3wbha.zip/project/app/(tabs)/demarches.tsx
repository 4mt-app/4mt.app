import { useState } from 'react';
import { ScrollView, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import Card from '@/components/Card';
import Badge from '@/components/Badge';
import { Building2, Landmark, Zap, Hop as Home, Receipt, Scale, Briefcase, ChevronRight, Sparkles, Send, CircleCheck, Clock, CircleAlert as AlertCircle, FileText, Dog, Package, Users, Info } from 'lucide-react-native';

type OrgStatus = 'sent' | 'pending' | 'todo';

const organisms = [
  { key: 'bank', label: 'Banque principale', sub: 'BNP Paribas', icon: Building2, status: 'sent' as OrgStatus },
  { key: 'insurance', label: 'Assurance décès', sub: 'AXA Vie', icon: Landmark, status: 'sent' as OrgStatus },
  { key: 'energy', label: 'Fournisseur énergie', sub: 'EDF', icon: Zap, status: 'pending' as OrgStatus },
  { key: 'landlord', label: 'Bailleur / Propriétaire', sub: 'Immobilière Martin', icon: Home, status: 'todo' as OrgStatus },
  { key: 'taxes', label: 'Impôts', sub: 'Direction des Finances Publiques', icon: Receipt, status: 'todo' as OrgStatus },
  { key: 'notaire', label: 'Notaire', sub: 'Me Clément Rousseau', icon: Scale, status: 'pending' as OrgStatus },
  { key: 'employer', label: 'Employeur', sub: 'Droits : solde, participation', icon: Briefcase, status: 'todo' as OrgStatus },
];

const statusConfig = {
  sent: { badge: 'success' as const, label: 'Envoyé', icon: CircleCheck, color: Colors.success[500] },
  pending: { badge: 'warning' as const, label: 'En cours', icon: Clock, color: Colors.warning[500] },
  todo: { badge: 'neutral' as const, label: 'À faire', icon: AlertCircle, color: Colors.neutral[400] },
};

const goodsItems = [
  { key: 'furniture', label: 'Mobilier & meubles', icon: Home, desc: 'Famille, association ou déménageur', done: true },
  { key: 'personal', label: 'Objets personnels', icon: Package, desc: 'Distribution définie', done: false },
  { key: 'animals', label: 'Animaux de compagnie', icon: Dog, desc: 'Famille ou association désignée', done: true },
  { key: 'appointments', label: 'Rendez-vous & retraits', icon: Users, desc: 'Organisation logistique', done: false },
];

export default function DemarchesScreen() {
  const insets = useSafeAreaInsets();
  const [activeTab, setActiveTab] = useState<'admin' | 'biens'>('admin');

  const sentCount = organisms.filter(o => o.status === 'sent').length;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.content, { paddingTop: insets.top + Spacing.md }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Démarches</Text>
        <Text style={styles.subtitle}>Administration & gestion des biens</Text>
      </View>

      {/* Tab selector */}
      <View style={styles.tabRow}>
        <TouchableOpacity
          style={[styles.tabBtn, activeTab === 'admin' && styles.tabBtnActive]}
          onPress={() => setActiveTab('admin')}
          activeOpacity={0.7}
        >
          <FileText size={14} color={activeTab === 'admin' ? Colors.primary[500] : Colors.neutral[400]} strokeWidth={1.5} />
          <Text style={[styles.tabLabel, activeTab === 'admin' && styles.tabLabelActive]}>Administration</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabBtn, activeTab === 'biens' && styles.tabBtnActive]}
          onPress={() => setActiveTab('biens')}
          activeOpacity={0.7}
        >
          <Package size={14} color={activeTab === 'biens' ? Colors.primary[500] : Colors.neutral[400]} strokeWidth={1.5} />
          <Text style={[styles.tabLabel, activeTab === 'biens' && styles.tabLabelActive]}>Mes biens</Text>
        </TouchableOpacity>
      </View>

      {activeTab === 'admin' ? (
        <>
          {/* AI Generation CTA */}
          <Card variant="elevated" style={styles.aiCard}>
            <View style={styles.aiCardContent}>
              <View style={styles.aiIconWrap}>
                <Sparkles size={24} color={Colors.primary[500]} strokeWidth={1.5} />
              </View>
              <View style={styles.aiCardText}>
                <Text style={styles.aiCardTitle}>Génération automatique par IA</Text>
                <Text style={styles.aiCardSub}>
                  Notre IA génère des emails et courriers personnalisés pour informer chaque organisme du décès et déclencher les procédures.
                </Text>
              </View>
            </View>
            <TouchableOpacity style={styles.aiGenerateBtn} activeOpacity={0.85}>
              <Send size={16} color="#fff" strokeWidth={1.5} />
              <Text style={styles.aiGenerateBtnText}>Générer et envoyer les courriers</Text>
            </TouchableOpacity>
          </Card>

          {/* Stats */}
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{sentCount}</Text>
              <Text style={styles.statLabel}>Envoyés</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{organisms.filter(o => o.status === 'pending').length}</Text>
              <Text style={styles.statLabel}>En cours</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{organisms.filter(o => o.status === 'todo').length}</Text>
              <Text style={styles.statLabel}>À faire</Text>
            </View>
          </View>

          {/* Organisms list */}
          <Text style={styles.sectionTitle}>Organismes à notifier</Text>
          <View style={styles.orgList}>
            {organisms.map((org) => {
              const Icon = org.icon;
              const cfg = statusConfig[org.status];
              const StatusIcon = cfg.icon;
              return (
                <TouchableOpacity key={org.key} activeOpacity={0.85}>
                  <Card variant="default" style={styles.orgCard}>
                    <View style={styles.orgRow}>
                      <View style={[styles.orgIcon, { backgroundColor: Colors.primary[50] }]}>
                        <Icon size={18} color={Colors.primary[500]} strokeWidth={1.5} />
                      </View>
                      <View style={styles.orgInfo}>
                        <Text style={styles.orgLabel}>{org.label}</Text>
                        <Text style={styles.orgSub}>{org.sub}</Text>
                      </View>
                      <View style={styles.orgRight}>
                        <StatusIcon size={14} color={cfg.color} strokeWidth={1.5} />
                        <Badge label={cfg.label} variant={cfg.badge} />
                      </View>
                    </View>
                  </Card>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Acte de décès */}
          <Text style={styles.sectionTitle}>Acte de décès</Text>
          <Card variant="bordered" style={styles.acteCard}>
            <View style={styles.acteHeader}>
              <View style={styles.acteIconWrap}>
                <FileText size={20} color={Colors.neutral[500]} strokeWidth={1.5} />
              </View>
              <View style={styles.acteInfo}>
                <Text style={styles.acteTitle}>Transmission dématérialisée</Text>
                <Text style={styles.acteSub}>En attente d'activation par la personne de confiance ou un professionnel habilité</Text>
              </View>
            </View>
            <View style={styles.actePath}>
              {['Constat de décès', 'Pompes funèbres', 'Acte de décès (mairie)', 'Activation 4MT'].map((step, i) => (
                <View key={i} style={styles.acteStep}>
                  <View style={[styles.acteStepDot, i < 2 && styles.acteStepDotDone]} />
                  {i < 3 && <View style={[styles.acteStepLine, i < 1 && styles.acteStepLineDone]} />}
                  <Text style={[styles.acteStepLabel, i < 2 && styles.acteStepLabelDone]}>{step}</Text>
                </View>
              ))}
            </View>
          </Card>
        </>
      ) : (
        <>
          <Card variant="tinted" style={styles.biensBanner}>
            <View style={styles.biensBannerRow}>
              <Package size={18} color={Colors.primary[500]} strokeWidth={1.5} />
              <Text style={styles.biensBannerText}>
                Définissez le devenir de vos biens pour éviter toute décision difficile à vos proches.
              </Text>
            </View>
          </Card>

          <View style={styles.goodsList}>
            {goodsItems.map((item) => {
              const Icon = item.icon;
              return (
                <TouchableOpacity key={item.key} activeOpacity={0.85}>
                  <Card variant="default" style={styles.goodsCard}>
                    <View style={styles.goodsRow}>
                      <View style={[styles.goodsIcon, { backgroundColor: item.done ? Colors.success[50] : Colors.neutral[100] }]}>
                        <Icon size={20} color={item.done ? Colors.success[500] : Colors.neutral[500]} strokeWidth={1.5} />
                      </View>
                      <View style={styles.goodsInfo}>
                        <Text style={styles.goodsLabel}>{item.label}</Text>
                        <Text style={styles.goodsDesc}>{item.desc}</Text>
                      </View>
                      <View style={styles.goodsRight}>
                        {item.done
                          ? <Badge label="Défini" variant="success" />
                          : <Badge label="À définir" variant="neutral" />
                        }
                        <ChevronRight size={14} color={Colors.neutral[300]} strokeWidth={2} />
                      </View>
                    </View>
                  </Card>
                </TouchableOpacity>
              );
            })}
          </View>

          <Card variant="bordered" style={styles.infoCard}>
            <View style={styles.infoRow}>
              <Info size={16} color={Colors.neutral[400]} strokeWidth={1.5} />
              <Text style={styles.infoText}>
                Les informations sur vos biens seront transmises à votre personne de confiance et à votre notaire après validation de votre décès.
              </Text>
            </View>
          </Card>
        </>
      )}

      <View style={{ height: Spacing.xl }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[50] },
  content: { paddingHorizontal: Spacing.md, gap: Spacing.md },
  header: {},
  title: { fontFamily: Fonts.bold, fontSize: 22, color: Colors.neutral[800] },
  subtitle: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[500], marginTop: 2 },
  tabRow: {
    flexDirection: 'row',
    backgroundColor: Colors.neutral[100],
    borderRadius: Radius.md,
    padding: 3,
    gap: 3,
  },
  tabBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.sm,
  },
  tabBtnActive: {
    backgroundColor: Colors.neutral[0],
    ...Shadow.sm,
  },
  tabLabel: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[400] },
  tabLabelActive: { color: Colors.neutral[800] },

  aiCard: { gap: Spacing.md },
  aiCardContent: { flexDirection: 'row', gap: Spacing.md, alignItems: 'flex-start' },
  aiIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.primary[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  aiCardText: { flex: 1 },
  aiCardTitle: { fontFamily: Fonts.semiBold, fontSize: 15, color: Colors.neutral[800] },
  aiCardSub: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[500], marginTop: 4, lineHeight: 18 },
  aiGenerateBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.primary[500],
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
  },
  aiGenerateBtnText: { fontFamily: Fonts.semiBold, fontSize: 14, color: '#fff' },

  statsRow: {
    flexDirection: 'row',
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.lg,
    padding: Spacing.md,
    ...Shadow.sm,
  },
  statItem: { flex: 1, alignItems: 'center', gap: 4 },
  statDivider: { width: 1, backgroundColor: Colors.neutral[200] },
  statValue: { fontFamily: Fonts.bold, fontSize: 22, color: Colors.neutral[800] },
  statLabel: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500] },

  sectionTitle: { fontFamily: Fonts.semiBold, fontSize: 16, color: Colors.neutral[700] },
  orgList: { gap: Spacing.sm },
  orgCard: {},
  orgRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  orgIcon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  orgInfo: { flex: 1 },
  orgLabel: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.neutral[800] },
  orgSub: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500], marginTop: 2 },
  orgRight: { alignItems: 'flex-end', gap: 4 },

  acteCard: {},
  acteHeader: { flexDirection: 'row', gap: Spacing.md, alignItems: 'flex-start', marginBottom: Spacing.md },
  acteIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  acteInfo: { flex: 1 },
  acteTitle: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.neutral[800] },
  acteSub: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500], marginTop: 2, lineHeight: 16 },
  actePath: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  acteStep: { alignItems: 'center', flex: 1, position: 'relative' },
  acteStepDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: Colors.neutral[300],
    marginBottom: 6,
    zIndex: 1,
  },
  acteStepDotDone: { backgroundColor: Colors.success[500] },
  acteStepLine: {
    position: 'absolute',
    top: 5,
    left: '50%',
    right: '-50%',
    height: 2,
    backgroundColor: Colors.neutral[200],
  },
  acteStepLineDone: { backgroundColor: Colors.success[500] },
  acteStepLabel: { fontFamily: Fonts.regular, fontSize: 9, color: Colors.neutral[400], textAlign: 'center', lineHeight: 12 },
  acteStepLabelDone: { color: Colors.success[700] },

  biensBanner: {},
  biensBannerRow: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'flex-start' },
  biensBannerText: { flex: 1, fontFamily: Fonts.regular, fontSize: 13, color: Colors.primary[700], lineHeight: 18 },
  goodsList: { gap: Spacing.sm },
  goodsCard: {},
  goodsRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  goodsIcon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  goodsInfo: { flex: 1 },
  goodsLabel: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.neutral[800] },
  goodsDesc: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500], marginTop: 2 },
  goodsRight: { alignItems: 'flex-end', gap: 4 },

  infoCard: {},
  infoRow: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'flex-start' },
  infoText: { flex: 1, fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500], lineHeight: 18 },
});
