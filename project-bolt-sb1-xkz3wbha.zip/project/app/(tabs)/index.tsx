import { ScrollView, View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import Card from '@/components/Card';
import Badge from '@/components/Badge';
import ProgressBar from '@/components/ProgressBar';
import {
  Bell, Sparkles, Heart, Flower2, FileText, Users,
  ChevronRight, Lock, Shield, CircleCheck, Clock
} from 'lucide-react-native';

const completionSections = [
  { label: 'Héritage émotionnel', progress: 0.6, color: Colors.teal[400] },
  { label: 'Volontés funéraires', progress: 0.3, color: Colors.primary[400] },
  { label: 'Démarches admin.', progress: 0.1, color: Colors.sage[500] },
  { label: 'Personne de confiance', progress: 1.0, color: Colors.success[500] },
];

const quickActions = [
  { label: 'Questionnaire IA', icon: Sparkles, route: '/questionnaire', color: Colors.primary[500], bg: Colors.primary[50] },
  { label: 'Nouveau message', icon: Heart, route: '/message/new', color: Colors.teal[500], bg: Colors.teal[50] },
  { label: 'Mes volontés', icon: Flower2, route: '/(tabs)/funerailles', color: Colors.sage[600], bg: Colors.sage[50] },
  { label: 'Démarches', icon: FileText, route: '/(tabs)/demarches', color: Colors.neutral[600], bg: Colors.neutral[100] },
];

const recentActivity = [
  { icon: CircleCheck, text: 'Personne de confiance désignée', time: 'Hier', color: Colors.success[500] },
  { icon: Heart, text: 'Message ajouté pour Marie', time: 'Il y a 3 jours', color: Colors.teal[500] },
  { icon: Clock, text: 'Questionnaire IA en cours (40%)', time: 'Il y a 5 jours', color: Colors.warning[500] },
];

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const overallProgress = 0.45;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.content, { paddingTop: insets.top + Spacing.md }]}
      showsVerticalScrollIndicator={false}
    >
      {/* Top bar */}
      <View style={styles.topBar}>
        <View>
          <Text style={styles.greeting}>Bonjour, Marie</Text>
          <Text style={styles.greetingDate}>Vendredi 24 avril 2026</Text>
        </View>
        <View style={styles.topRight}>
          <TouchableOpacity style={styles.notifBtn} activeOpacity={0.7}>
            <Bell size={20} color={Colors.neutral[600]} strokeWidth={1.5} />
            <View style={styles.notifDot} />
          </TouchableOpacity>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>MD</Text>
          </View>
        </View>
      </View>

      {/* Progress card */}
      <Card style={styles.progressCard} variant="elevated">
        <View style={styles.progressHeader}>
          <View>
            <Text style={styles.progressTitle}>Mon dossier 4MT</Text>
            <Text style={styles.progressSub}>Complétion globale</Text>
          </View>
          <View style={styles.percentCircle}>
            <Text style={styles.percentText}>45%</Text>
          </View>
        </View>

        <ProgressBar progress={overallProgress} color={Colors.primary[500]} height={8} />

        <View style={styles.sectionProgress}>
          {completionSections.map((s, i) => (
            <View key={i} style={styles.sectionRow}>
              <Text style={styles.sectionLabel}>{s.label}</Text>
              <View style={styles.sectionBarWrap}>
                <ProgressBar progress={s.progress} color={s.color} height={4} />
              </View>
              <Text style={[styles.sectionPct, { color: s.color }]}>{Math.round(s.progress * 100)}%</Text>
            </View>
          ))}
        </View>
      </Card>

      {/* AI Banner */}
      <TouchableOpacity
        style={styles.aiBanner}
        activeOpacity={0.9}
        onPress={() => router.push('/questionnaire')}
      >
        <View style={styles.aiBannerLeft}>
          <View style={styles.aiIconWrap}>
            <Sparkles size={22} color={Colors.primary[500]} strokeWidth={1.5} />
          </View>
          <View>
            <Text style={styles.aiBannerTitle}>Questionnaire IA</Text>
            <Text style={styles.aiBannerSub}>Continuez votre questionnaire guidé</Text>
          </View>
        </View>
        <ChevronRight size={18} color={Colors.primary[500]} strokeWidth={2} />
      </TouchableOpacity>

      {/* Quick Actions */}
      <Text style={styles.sectionTitle}>Actions rapides</Text>
      <View style={styles.quickGrid}>
        {quickActions.map((a, i) => {
          const Icon = a.icon;
          return (
            <TouchableOpacity
              key={i}
              style={styles.quickItem}
              activeOpacity={0.8}
              onPress={() => router.push(a.route as any)}
            >
              <View style={[styles.quickIcon, { backgroundColor: a.bg }]}>
                <Icon size={24} color={a.color} strokeWidth={1.5} />
              </View>
              <Text style={styles.quickLabel}>{a.label}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Security notice */}
      <Card variant="bordered" style={styles.securityCard}>
        <View style={styles.securityRow}>
          <View style={[styles.securityIcon]}>
            <Shield size={20} color={Colors.success[500]} strokeWidth={1.5} />
          </View>
          <View style={styles.securityText}>
            <Text style={styles.securityTitle}>Données chiffrées et protégées</Text>
            <Text style={styles.securityBody}>
              Votre dossier est sécurisé. Seule votre personne de confiance peut l'activer, avec validation.
            </Text>
          </View>
        </View>
      </Card>

      {/* Trusted person */}
      <Text style={styles.sectionTitle}>Personne de confiance</Text>
      <Card variant="default" style={styles.trustedCard}>
        <View style={styles.trustedRow}>
          <View style={styles.trustedAvatar}>
            <Text style={styles.trustedAvatarText}>JD</Text>
          </View>
          <View style={styles.trustedInfo}>
            <Text style={styles.trustedName}>Jean Dupont</Text>
            <Text style={styles.trustedRole}>Personne de confiance désignée</Text>
            <Badge label="Validé" variant="success" />
          </View>
          <ChevronRight size={16} color={Colors.neutral[400]} strokeWidth={2} />
        </View>
      </Card>

      {/* Recent activity */}
      <Text style={styles.sectionTitle}>Activité récente</Text>
      <Card variant="bordered">
        {recentActivity.map((a, i) => {
          const Icon = a.icon;
          return (
            <View key={i} style={[styles.activityRow, i < recentActivity.length - 1 && styles.activityDivider]}>
              <View style={[styles.activityIcon, { backgroundColor: `${a.color}18` }]}>
                <Icon size={14} color={a.color} strokeWidth={2} />
              </View>
              <View style={styles.activityContent}>
                <Text style={styles.activityText}>{a.text}</Text>
                <Text style={styles.activityTime}>{a.time}</Text>
              </View>
            </View>
          );
        })}
      </Card>

      <View style={{ height: Spacing.xl }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[50] },
  content: { paddingHorizontal: Spacing.md, gap: Spacing.md },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.xs,
  },
  greeting: {
    fontFamily: Fonts.bold,
    fontSize: 22,
    color: Colors.neutral[800],
  },
  greetingDate: {
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: Colors.neutral[500],
    marginTop: 2,
  },
  topRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  notifBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.neutral[0],
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.sm,
  },
  notifDot: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.error[500],
    borderWidth: 1.5,
    borderColor: Colors.neutral[0],
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontFamily: Fonts.bold,
    fontSize: 13,
    color: '#fff',
  },
  progressCard: { gap: Spacing.md },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  progressTitle: {
    fontFamily: Fonts.bold,
    fontSize: 17,
    color: Colors.neutral[800],
  },
  progressSub: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.neutral[500],
    marginTop: 2,
  },
  percentCircle: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: Colors.primary[50],
    borderWidth: 2,
    borderColor: Colors.primary[200],
    alignItems: 'center',
    justifyContent: 'center',
  },
  percentText: {
    fontFamily: Fonts.bold,
    fontSize: 15,
    color: Colors.primary[600],
  },
  sectionProgress: { gap: Spacing.sm },
  sectionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  sectionLabel: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.neutral[600],
    width: 120,
  },
  sectionBarWrap: { flex: 1 },
  sectionPct: {
    fontFamily: Fonts.semiBold,
    fontSize: 11,
    width: 30,
    textAlign: 'right',
  },
  aiBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.primary[50],
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1.5,
    borderColor: Colors.primary[100],
  },
  aiBannerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  aiIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.neutral[0],
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.sm,
  },
  aiBannerTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 15,
    color: Colors.primary[700],
  },
  aiBannerSub: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.primary[500],
    marginTop: 2,
  },
  sectionTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 16,
    color: Colors.neutral[700],
    marginBottom: -Spacing.xs,
  },
  quickGrid: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  quickItem: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: Colors.neutral[0],
    borderRadius: Radius.md,
    padding: Spacing.md,
    gap: Spacing.sm,
    ...Shadow.sm,
  },
  quickIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickLabel: {
    fontFamily: Fonts.medium,
    fontSize: 11,
    color: Colors.neutral[700],
    textAlign: 'center',
    lineHeight: 14,
  },
  securityCard: { marginTop: -Spacing.xs },
  securityRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.md,
  },
  securityIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.success[50],
    alignItems: 'center',
    justifyContent: 'center',
  },
  securityText: { flex: 1, gap: 3 },
  securityTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 13,
    color: Colors.neutral[800],
  },
  securityBody: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.neutral[500],
    lineHeight: 17,
  },
  trustedCard: {},
  trustedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  trustedAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.teal[500],
    alignItems: 'center',
    justifyContent: 'center',
  },
  trustedAvatarText: {
    fontFamily: Fonts.bold,
    fontSize: 15,
    color: '#fff',
  },
  trustedInfo: { flex: 1, gap: 3 },
  trustedName: {
    fontFamily: Fonts.semiBold,
    fontSize: 15,
    color: Colors.neutral[800],
  },
  trustedRole: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.neutral[500],
    marginBottom: 4,
  },
  activityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  activityDivider: {
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  activityIcon: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activityContent: { flex: 1 },
  activityText: {
    fontFamily: Fonts.medium,
    fontSize: 13,
    color: Colors.neutral[700],
  },
  activityTime: {
    fontFamily: Fonts.regular,
    fontSize: 11,
    color: Colors.neutral[400],
    marginTop: 2,
  },
});
