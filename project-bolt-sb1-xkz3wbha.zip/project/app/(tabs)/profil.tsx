import { useState } from 'react';
import { ScrollView, View, Text, StyleSheet, TouchableOpacity, Switch } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import Card from '@/components/Card';
import Badge from '@/components/Badge';
import {
  User, Shield, Bell, Eye, Accessibility, ChevronRight,
  LogOut, UserCheck, Lock, Download, Trash2, Building2,
  Star, Info, Volume2, Captions
} from 'lucide-react-native';

export default function ProfilScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [voiceOver, setVoiceOver] = useState(false);
  const [captions, setCaptions] = useState(false);
  const [notifications, setNotifications] = useState(true);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.content, { paddingTop: insets.top + Spacing.md }]}
      showsVerticalScrollIndicator={false}
    >
      {/* Profile header */}
      <View style={styles.profileHeader}>
        <View style={styles.avatarLarge}>
          <Text style={styles.avatarText}>MD</Text>
        </View>
        <Text style={styles.profileName}>Marie Dupont</Text>
        <Text style={styles.profileEmail}>marie.dupont@exemple.fr</Text>
        <Badge label="Compte gratuit" variant="neutral" size="md" />
      </View>

      {/* Upgrade card */}
      <TouchableOpacity style={styles.upgradeCard} activeOpacity={0.88}>
        <View style={styles.upgradeLeft}>
          <Star size={22} color={Colors.warning[500]} strokeWidth={1.5} />
          <View>
            <Text style={styles.upgradeTitle}>Passer à Premium</Text>
            <Text style={styles.upgradeSub}>Vidéo posthume, hologramme, réalité augmentée</Text>
          </View>
        </View>
        <ChevronRight size={18} color={Colors.warning[500]} strokeWidth={2} />
      </TouchableOpacity>

      {/* Trusted person */}
      <Text style={styles.sectionTitle}>Personne de confiance</Text>
      <Card variant="default" style={styles.trustedCard}>
        <View style={styles.trustedRow}>
          <View style={styles.trustedAvatar}>
            <Text style={styles.trustedAvatarText}>JD</Text>
          </View>
          <View style={styles.trustedInfo}>
            <Text style={styles.trustedName}>Jean Dupont</Text>
            <Text style={styles.trustedContact}>jean.dupont@exemple.fr · 06 12 34 56 78</Text>
            <Badge label="Confirmé" variant="success" />
          </View>
          <ChevronRight size={16} color={Colors.neutral[300]} strokeWidth={2} />
        </View>
      </Card>

      {/* Account */}
      <Text style={styles.sectionTitle}>Mon compte</Text>
      <Card variant="default" padding="none">
        {[
          { icon: User, label: 'Mes informations personnelles' },
          { icon: Lock, label: 'Sécurité & mot de passe' },
          { icon: Shield, label: 'Connexion FranceConnect', badge: 'Active' },
          { icon: Download, label: 'Exporter mes données' },
        ].map((item, i, arr) => {
          const Icon = item.icon;
          return (
            <TouchableOpacity
              key={i}
              style={[styles.menuItem, i < arr.length - 1 && styles.menuItemBorder]}
              activeOpacity={0.7}
            >
              <View style={styles.menuItemLeft}>
                <View style={styles.menuIcon}>
                  <Icon size={16} color={Colors.neutral[600]} strokeWidth={1.5} />
                </View>
                <Text style={styles.menuLabel}>{item.label}</Text>
              </View>
              <View style={styles.menuItemRight}>
                {item.badge && <Badge label={item.badge} variant="success" />}
                <ChevronRight size={14} color={Colors.neutral[300]} strokeWidth={2} />
              </View>
            </TouchableOpacity>
          );
        })}
      </Card>

      {/* Accessibility */}
      <Text style={styles.sectionTitle}>Accessibilité</Text>
      <Card variant="default" padding="none">
        <View style={[styles.menuItem, styles.menuItemBorder]}>
          <View style={styles.menuItemLeft}>
            <View style={styles.menuIcon}>
              <Volume2 size={16} color={Colors.neutral[600]} strokeWidth={1.5} />
            </View>
            <View>
              <Text style={styles.menuLabel}>Synthèse vocale</Text>
              <Text style={styles.menuSub}>Navigation accessible aux malvoyants</Text>
            </View>
          </View>
          <Switch
            value={voiceOver}
            onValueChange={setVoiceOver}
            trackColor={{ false: Colors.neutral[200], true: Colors.primary[400] }}
            thumbColor="#fff"
          />
        </View>
        <View style={styles.menuItem}>
          <View style={styles.menuItemLeft}>
            <View style={styles.menuIcon}>
              <Captions size={16} color={Colors.neutral[600]} strokeWidth={1.5} />
            </View>
            <View>
              <Text style={styles.menuLabel}>Sous-titres & transcription</Text>
              <Text style={styles.menuSub}>Pour les contenus audio et vidéo</Text>
            </View>
          </View>
          <Switch
            value={captions}
            onValueChange={setCaptions}
            trackColor={{ false: Colors.neutral[200], true: Colors.primary[400] }}
            thumbColor="#fff"
          />
        </View>
      </Card>

      {/* Notifications */}
      <Text style={styles.sectionTitle}>Notifications</Text>
      <Card variant="default" padding="none">
        <View style={styles.menuItem}>
          <View style={styles.menuItemLeft}>
            <View style={styles.menuIcon}>
              <Bell size={16} color={Colors.neutral[600]} strokeWidth={1.5} />
            </View>
            <View>
              <Text style={styles.menuLabel}>Rappels de complétion</Text>
              <Text style={styles.menuSub}>Être rappelé de compléter son dossier</Text>
            </View>
          </View>
          <Switch
            value={notifications}
            onValueChange={setNotifications}
            trackColor={{ false: Colors.neutral[200], true: Colors.primary[400] }}
            thumbColor="#fff"
          />
        </View>
      </Card>

      {/* B2B section */}
      <Text style={styles.sectionTitle}>Espace professionnel</Text>
      <Card variant="tinted">
        <View style={styles.b2bContent}>
          <View style={styles.b2bIconWrap}>
            <Building2 size={22} color={Colors.primary[500]} strokeWidth={1.5} />
          </View>
          <View style={styles.b2bText}>
            <Text style={styles.b2bTitle}>Vous êtes professionnel ?</Text>
            <Text style={styles.b2bSub}>
              Pompes funèbres, notaire, assurance, mairie — accédez à l'interface B2B 4MT.
            </Text>
          </View>
        </View>
        <TouchableOpacity style={styles.b2bBtn} activeOpacity={0.85}>
          <Text style={styles.b2bBtnText}>Accéder à l'espace professionnel</Text>
          <ChevronRight size={14} color={Colors.primary[600]} strokeWidth={2} />
        </TouchableOpacity>
      </Card>

      {/* Legal & info */}
      <Card variant="bordered" padding="none">
        {[
          { icon: Info, label: 'Mentions légales & CGU' },
          { icon: Shield, label: 'Politique de confidentialité' },
          { icon: Eye, label: 'Traçabilité de mes données' },
        ].map((item, i, arr) => {
          const Icon = item.icon;
          return (
            <TouchableOpacity
              key={i}
              style={[styles.menuItem, i < arr.length - 1 && styles.menuItemBorder]}
              activeOpacity={0.7}
            >
              <View style={styles.menuItemLeft}>
                <View style={styles.menuIcon}>
                  <Icon size={16} color={Colors.neutral[500]} strokeWidth={1.5} />
                </View>
                <Text style={[styles.menuLabel, { color: Colors.neutral[600] }]}>{item.label}</Text>
              </View>
              <ChevronRight size={14} color={Colors.neutral[300]} strokeWidth={2} />
            </TouchableOpacity>
          );
        })}
      </Card>

      {/* Logout & delete */}
      <TouchableOpacity
        style={styles.logoutBtn}
        activeOpacity={0.85}
        onPress={() => router.replace('/')}
      >
        <LogOut size={16} color={Colors.neutral[600]} strokeWidth={1.5} />
        <Text style={styles.logoutText}>Se déconnecter</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.deleteBtn} activeOpacity={0.85}>
        <Trash2 size={14} color={Colors.error[500]} strokeWidth={1.5} />
        <Text style={styles.deleteText}>Supprimer mon compte</Text>
      </TouchableOpacity>

      <Text style={styles.version}>4MT v1.0.0 · RGPD · Données chiffrées</Text>

      <View style={{ height: Spacing.xl }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[50] },
  content: { paddingHorizontal: Spacing.md, gap: Spacing.md },

  profileHeader: {
    alignItems: 'center',
    gap: Spacing.sm,
    paddingBottom: Spacing.md,
  },
  avatarLarge: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.md,
  },
  avatarText: { fontFamily: Fonts.bold, fontSize: 26, color: '#fff' },
  profileName: { fontFamily: Fonts.bold, fontSize: 22, color: Colors.neutral[800] },
  profileEmail: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[500] },

  upgradeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FEF9EC',
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1.5,
    borderColor: '#FDE68A',
  },
  upgradeLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flex: 1 },
  upgradeTitle: { fontFamily: Fonts.semiBold, fontSize: 15, color: Colors.warning[700] },
  upgradeSub: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.warning[500], marginTop: 2 },

  sectionTitle: { fontFamily: Fonts.semiBold, fontSize: 15, color: Colors.neutral[600] },

  trustedCard: {},
  trustedRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  trustedAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.teal[500],
    alignItems: 'center',
    justifyContent: 'center',
  },
  trustedAvatarText: { fontFamily: Fonts.bold, fontSize: 16, color: '#fff' },
  trustedInfo: { flex: 1, gap: 3 },
  trustedName: { fontFamily: Fonts.semiBold, fontSize: 15, color: Colors.neutral[800] },
  trustedContact: { fontFamily: Fonts.regular, fontSize: 11, color: Colors.neutral[500] },

  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    gap: Spacing.sm,
  },
  menuItemBorder: { borderBottomWidth: 1, borderBottomColor: Colors.neutral[100] },
  menuItemLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flex: 1 },
  menuItemRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  menuIcon: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuLabel: { fontFamily: Fonts.medium, fontSize: 14, color: Colors.neutral[800] },
  menuSub: { fontFamily: Fonts.regular, fontSize: 11, color: Colors.neutral[400], marginTop: 1 },

  b2bContent: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.md },
  b2bIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primary[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  b2bText: { flex: 1 },
  b2bTitle: { fontFamily: Fonts.semiBold, fontSize: 14, color: Colors.primary[700] },
  b2bSub: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.primary[600], marginTop: 3, lineHeight: 17 },
  b2bBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    backgroundColor: Colors.primary[100],
    borderRadius: Radius.sm,
    paddingVertical: Spacing.sm + 2,
  },
  b2bBtnText: { fontFamily: Fonts.semiBold, fontSize: 13, color: Colors.primary[600] },

  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.neutral[100],
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
  },
  logoutText: { fontFamily: Fonts.medium, fontSize: 14, color: Colors.neutral[700] },
  deleteBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.sm,
  },
  deleteText: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.error[500] },
  version: { fontFamily: Fonts.regular, fontSize: 11, color: Colors.neutral[300], textAlign: 'center' },
});
