import { View, Text, StyleSheet, Image, Dimensions, Platform } from 'react-native';
import { useRouter, Redirect } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Fonts, Spacing } from '@/constants/theme';
import Button from '@/components/Button';
import { Shield, Heart, FileText } from 'lucide-react-native';

const { width, height } = Dimensions.get('window');

export default function WelcomeScreen() {
  const router = useRouter();

  if (Platform.OS === 'web') {
    return <Redirect href={'/web' as any} />;
  }

  return (
    <View style={styles.container}>
      <Image
        source={{ uri: 'https://images.pexels.com/photos/1366957/pexels-photo-1366957.jpeg?auto=compress&cs=tinysrgb&w=800' }}
        style={styles.backgroundImage}
        resizeMode="cover"
      />
      <LinearGradient
        colors={['rgba(13,22,32,0.3)', 'rgba(13,22,32,0.7)', 'rgba(13,22,32,0.97)']}
        style={styles.gradient}
        locations={[0, 0.4, 1]}
      />

      <View style={styles.content}>
        <View style={styles.logoArea}>
          <View style={styles.logoCircle}>
            <Text style={styles.logoText}>4MT</Text>
          </View>
          <Text style={styles.tagline}>For My Transition</Text>
        </View>

        <View style={styles.heroText}>
          <Text style={styles.headline}>Transmettez ce{'\n'}qui compte vraiment</Text>
          <Text style={styles.subheadline}>
            Préparez votre héritage émotionnel, organisez vos volontés et allégez la charge de vos proches — avec sérénité.
          </Text>
        </View>

        <View style={styles.pillars}>
          <View style={styles.pillar}>
            <Heart size={16} color={Colors.teal[300]} strokeWidth={1.5} />
            <Text style={styles.pillarText}>Héritage émotionnel</Text>
          </View>
          <View style={styles.pillar}>
            <FileText size={16} color={Colors.teal[300]} strokeWidth={1.5} />
            <Text style={styles.pillarText}>Volontés funéraires</Text>
          </View>
          <View style={styles.pillar}>
            <Shield size={16} color={Colors.teal[300]} strokeWidth={1.5} />
            <Text style={styles.pillarText}>Démarches simplifiées</Text>
          </View>
        </View>

        <View style={styles.actions}>
          <Button
            label="Commencer gratuitement"
            onPress={() => router.push('/onboarding')}
            variant="primary"
            size="lg"
            fullWidth
            style={styles.btnPrimary}
          />
          <Button
            label="J'ai déjà un compte"
            onPress={() => router.push('/auth/login')}
            variant="ghost"
            size="md"
            fullWidth
            textStyle={{ color: Colors.neutral[200] }}
          />
        </View>

        <Text style={styles.legal}>
          Vos données sont chiffrées et protégées.{'\n'}Conforme RGPD.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[900] },
  backgroundImage: {
    position: 'absolute',
    width,
    height,
    top: 0,
    left: 0,
  },
  gradient: {
    position: 'absolute',
    width,
    height,
    top: 0,
    left: 0,
  },
  content: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
    paddingTop: height * 0.1,
    paddingBottom: Spacing.xl,
    justifyContent: 'flex-end',
  },
  logoArea: {
    alignItems: 'center',
    marginBottom: Spacing.xl,
  },
  logoCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.sm,
  },
  logoText: {
    fontFamily: Fonts.bold,
    fontSize: 24,
    color: '#fff',
    letterSpacing: 1,
  },
  tagline: {
    fontFamily: Fonts.medium,
    fontSize: 13,
    color: Colors.neutral[400],
    letterSpacing: 2,
    textTransform: 'uppercase',
  },
  heroText: {
    marginBottom: Spacing.lg,
  },
  headline: {
    fontFamily: Fonts.bold,
    fontSize: 34,
    color: '#fff',
    lineHeight: 42,
    marginBottom: Spacing.md,
  },
  subheadline: {
    fontFamily: Fonts.regular,
    fontSize: 16,
    color: Colors.neutral[300],
    lineHeight: 24,
  },
  pillars: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginBottom: Spacing.xl,
  },
  pillar: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    padding: Spacing.sm,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  pillarText: {
    fontFamily: Fonts.medium,
    fontSize: 11,
    color: Colors.neutral[300],
    textAlign: 'center',
    lineHeight: 14,
  },
  actions: {
    gap: Spacing.xs,
    marginBottom: Spacing.md,
  },
  btnPrimary: {
    marginBottom: Spacing.xs,
  },
  legal: {
    fontFamily: Fonts.regular,
    fontSize: 11,
    color: Colors.neutral[500],
    textAlign: 'center',
    lineHeight: 16,
  },
});
