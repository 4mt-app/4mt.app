import { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  ScrollView, KeyboardAvoidingView, Platform
} from 'react-native';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius } from '@/constants/theme';
import Button from '@/components/Button';
import { Eye, EyeOff, Lock, Mail, User, Phone } from 'lucide-react-native';

export default function RegisterScreen() {
  const router = useRouter();
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '', password: '' });
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<1 | 2>(1);

  const update = (key: string, val: string) => setForm(prev => ({ ...prev, [key]: val }));

  const handleNext = () => {
    if (!form.firstName || !form.lastName || !form.email) {
      setError('Veuillez remplir tous les champs obligatoires.');
      return;
    }
    setError(null);
    setStep(2);
  };

  const handleRegister = () => {
    if (!form.password) {
      setError('Veuillez choisir un mot de passe.');
      return;
    }
    setLoading(true);
    setError(null);
    setTimeout(() => {
      setLoading(false);
      router.replace('/(tabs)');
    }, 1400);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <TouchableOpacity onPress={() => step === 2 ? setStep(1) : router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <Text style={styles.backText}>← Retour</Text>
        </TouchableOpacity>

        <View style={styles.header}>
          <View style={styles.logoCircle}>
            <Text style={styles.logoText}>4MT</Text>
          </View>
          <Text style={styles.title}>Créer mon compte</Text>
          <Text style={styles.subtitle}>
            {step === 1 ? 'Quelques informations sur vous' : 'Sécurisez votre accès'}
          </Text>
          <View style={styles.stepRow}>
            {[1, 2].map(s => (
              <View key={s} style={[styles.stepDot, s <= step && styles.stepDotActive]} />
            ))}
          </View>
        </View>

        <View style={styles.form}>
          {error && (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          {step === 1 ? (
            <>
              <View style={styles.row2}>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.label}>Prénom *</Text>
                  <View style={styles.inputRow}>
                    <User size={16} color={Colors.neutral[400]} strokeWidth={1.5} />
                    <TextInput
                      style={styles.input}
                      placeholder="Marie"
                      placeholderTextColor={Colors.neutral[400]}
                      value={form.firstName}
                      onChangeText={v => update('firstName', v)}
                    />
                  </View>
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.label}>Nom *</Text>
                  <View style={styles.inputRow}>
                    <TextInput
                      style={styles.input}
                      placeholder="Dupont"
                      placeholderTextColor={Colors.neutral[400]}
                      value={form.lastName}
                      onChangeText={v => update('lastName', v)}
                    />
                  </View>
                </View>
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.label}>Adresse email *</Text>
                <View style={styles.inputRow}>
                  <Mail size={16} color={Colors.neutral[400]} strokeWidth={1.5} />
                  <TextInput
                    style={styles.input}
                    placeholder="marie@exemple.fr"
                    placeholderTextColor={Colors.neutral[400]}
                    value={form.email}
                    onChangeText={v => update('email', v)}
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                </View>
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.label}>Téléphone</Text>
                <View style={styles.inputRow}>
                  <Phone size={16} color={Colors.neutral[400]} strokeWidth={1.5} />
                  <TextInput
                    style={styles.input}
                    placeholder="+33 6 00 00 00 00"
                    placeholderTextColor={Colors.neutral[400]}
                    value={form.phone}
                    onChangeText={v => update('phone', v)}
                    keyboardType="phone-pad"
                  />
                </View>
              </View>

              <Button label="Continuer" onPress={handleNext} variant="primary" size="lg" fullWidth />
            </>
          ) : (
            <>
              <View style={styles.securityInfo}>
                <Text style={styles.securityTitle}>Votre mot de passe</Text>
                <Text style={styles.securityBody}>
                  Choisissez un mot de passe fort. Il protège l'accès à vos données personnelles et à votre héritage.
                </Text>
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.label}>Mot de passe *</Text>
                <View style={styles.inputRow}>
                  <Lock size={16} color={Colors.neutral[400]} strokeWidth={1.5} />
                  <TextInput
                    style={styles.input}
                    placeholder="8 caractères minimum"
                    placeholderTextColor={Colors.neutral[400]}
                    value={form.password}
                    onChangeText={v => update('password', v)}
                    secureTextEntry={!showPwd}
                  />
                  <TouchableOpacity onPress={() => setShowPwd(!showPwd)} activeOpacity={0.7}>
                    {showPwd
                      ? <EyeOff size={16} color={Colors.neutral[400]} strokeWidth={1.5} />
                      : <Eye size={16} color={Colors.neutral[400]} strokeWidth={1.5} />
                    }
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.cguRow}>
                <Text style={styles.cguText}>
                  En créant un compte, vous acceptez nos{' '}
                  <Text style={styles.cguLink}>Conditions d'utilisation</Text>
                  {' '}et notre{' '}
                  <Text style={styles.cguLink}>Politique de confidentialité</Text>.
                </Text>
              </View>

              <Button
                label="Créer mon compte"
                onPress={handleRegister}
                variant="primary"
                size="lg"
                fullWidth
                loading={loading}
              />
            </>
          )}
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>Déjà un compte ?</Text>
          <TouchableOpacity onPress={() => router.push('/auth/login')} activeOpacity={0.7}>
            <Text style={styles.footerLink}>Se connecter</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  scroll: {
    flexGrow: 1,
    backgroundColor: Colors.neutral[0],
    paddingHorizontal: Spacing.lg,
    paddingTop: 60,
    paddingBottom: Spacing.xl,
  },
  backBtn: { marginBottom: Spacing.lg },
  backText: {
    fontFamily: Fonts.medium,
    fontSize: 14,
    color: Colors.primary[500],
  },
  header: {
    alignItems: 'center',
    marginBottom: Spacing.xl,
  },
  logoCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary[500],
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
  },
  logoText: {
    fontFamily: Fonts.bold,
    fontSize: 18,
    color: '#fff',
    letterSpacing: 1,
  },
  title: {
    fontFamily: Fonts.bold,
    fontSize: 24,
    color: Colors.neutral[800],
    marginBottom: Spacing.xs,
  },
  subtitle: {
    fontFamily: Fonts.regular,
    fontSize: 14,
    color: Colors.neutral[500],
    marginBottom: Spacing.md,
  },
  stepRow: {
    flexDirection: 'row',
    gap: Spacing.xs,
  },
  stepDot: {
    width: 24,
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.neutral[200],
  },
  stepDotActive: {
    backgroundColor: Colors.primary[500],
  },
  form: { gap: Spacing.md },
  row2: { flexDirection: 'row', gap: Spacing.sm },
  errorBox: {
    backgroundColor: Colors.error[50],
    borderRadius: Radius.sm,
    padding: Spacing.md,
    borderLeftWidth: 3,
    borderLeftColor: Colors.error[500],
  },
  errorText: {
    fontFamily: Fonts.medium,
    fontSize: 13,
    color: Colors.error[700],
  },
  fieldGroup: { gap: Spacing.xs },
  label: {
    fontFamily: Fonts.medium,
    fontSize: 13,
    color: Colors.neutral[700],
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm + 2,
    gap: Spacing.sm,
  },
  input: {
    flex: 1,
    fontFamily: Fonts.regular,
    fontSize: 15,
    color: Colors.neutral[800],
  },
  securityInfo: {
    backgroundColor: Colors.primary[50],
    borderRadius: Radius.md,
    padding: Spacing.md,
    gap: Spacing.xs,
  },
  securityTitle: {
    fontFamily: Fonts.semiBold,
    fontSize: 14,
    color: Colors.primary[700],
  },
  securityBody: {
    fontFamily: Fonts.regular,
    fontSize: 13,
    color: Colors.primary[600],
    lineHeight: 19,
  },
  cguRow: {
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.sm,
    padding: Spacing.md,
  },
  cguText: {
    fontFamily: Fonts.regular,
    fontSize: 12,
    color: Colors.neutral[500],
    lineHeight: 18,
  },
  cguLink: {
    color: Colors.primary[500],
    fontFamily: Fonts.medium,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: Spacing.xs,
    marginTop: Spacing.xl,
  },
  footerText: {
    fontFamily: Fonts.regular,
    fontSize: 14,
    color: Colors.neutral[500],
  },
  footerLink: {
    fontFamily: Fonts.semiBold,
    fontSize: 14,
    color: Colors.primary[500],
  },
});
