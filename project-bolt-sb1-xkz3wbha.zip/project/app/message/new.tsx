import { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  ScrollView, KeyboardAvoidingView, Platform
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Colors, Fonts, Spacing, Radius, Shadow } from '@/constants/theme';
import Button from '@/components/Button';
import { X, FileText, Mic, Video, User, Plus, CircleCheck, Lock } from 'lucide-react-native';

type MsgType = 'text' | 'audio' | 'video';

const messageTypes = [
  { key: 'text' as MsgType, label: 'Texte', icon: FileText, desc: 'Rédigez un message écrit', premium: false },
  { key: 'audio' as MsgType, label: 'Audio', icon: Mic, desc: 'Enregistrez votre voix', premium: false },
  { key: 'video' as MsgType, label: 'Vidéo', icon: Video, desc: 'Message vidéo posthume', premium: true },
];

const suggestedRecipients = [
  { id: '1', name: 'Léa Dupont', role: 'Fille' },
  { id: '2', name: 'Thomas Dupont', role: 'Fils' },
  { id: '3', name: 'Marie-Claire', role: 'Épouse' },
  { id: '4', name: 'Jean Dupont', role: 'Frère' },
];

export default function NewMessageScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [msgType, setMsgType] = useState<MsgType>('text');
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [selectedRecipients, setSelectedRecipients] = useState<string[]>([]);
  const [step, setStep] = useState<1 | 2 | 3>(1);

  const toggleRecipient = (id: string) => {
    setSelectedRecipients(prev =>
      prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]
    );
  };

  const canContinue = () => {
    if (step === 1) return msgType != null;
    if (step === 2) return title.trim().length > 0 && (msgType !== 'text' || body.trim().length > 0);
    return selectedRecipients.length > 0;
  };

  const handleNext = () => {
    if (step < 3) setStep((step + 1) as 1 | 2 | 3);
    else router.back();
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => step > 1 ? setStep((step - 1) as 1 | 2 | 3) : router.back()} style={styles.closeBtn} activeOpacity={0.7}>
            <X size={20} color={Colors.neutral[600]} strokeWidth={2} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Nouveau message</Text>
          <View style={styles.stepIndicator}>
            {[1, 2, 3].map(s => (
              <View key={s} style={[styles.stepDot, s <= step && styles.stepDotActive]} />
            ))}
          </View>
        </View>

        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {step === 1 && (
            <>
              <Text style={styles.stepTitle}>Quel type de message ?</Text>
              <Text style={styles.stepSub}>Choisissez comment vous souhaitez vous exprimer</Text>

              <View style={styles.typeList}>
                {messageTypes.map((t) => {
                  const Icon = t.icon;
                  const isSelected = msgType === t.key;
                  return (
                    <TouchableOpacity
                      key={t.key}
                      style={[styles.typeCard, isSelected && styles.typeCardSelected]}
                      onPress={() => !t.premium && setMsgType(t.key)}
                      activeOpacity={t.premium ? 1 : 0.8}
                    >
                      <View style={[styles.typeIconWrap, isSelected && styles.typeIconWrapSelected]}>
                        <Icon size={24} color={isSelected ? Colors.primary[500] : Colors.neutral[500]} strokeWidth={1.5} />
                      </View>
                      <View style={styles.typeInfo}>
                        <View style={styles.typeLabelRow}>
                          <Text style={[styles.typeLabel, isSelected && styles.typeLabelSelected]}>{t.label}</Text>
                          {t.premium && (
                            <View style={styles.premiumTag}>
                              <Lock size={10} color={Colors.warning[700]} strokeWidth={2} />
                              <Text style={styles.premiumTagText}>Premium</Text>
                            </View>
                          )}
                        </View>
                        <Text style={styles.typeDesc}>{t.desc}</Text>
                      </View>
                      {isSelected && !t.premium && (
                        <CircleCheck size={20} color={Colors.primary[500]} strokeWidth={2} />
                      )}
                    </TouchableOpacity>
                  );
                })}
              </View>
            </>
          )}

          {step === 2 && (
            <>
              <Text style={styles.stepTitle}>Rédigez votre message</Text>
              <Text style={styles.stepSub}>Prenez le temps qu'il vous faut. Vous pourrez le modifier à tout moment.</Text>

              <View style={styles.fieldGroup}>
                <Text style={styles.label}>Titre du message</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Ex : À mes enfants, Pour mon anniversaire..."
                  placeholderTextColor={Colors.neutral[400]}
                  value={title}
                  onChangeText={setTitle}
                />
              </View>

              {msgType === 'text' && (
                <View style={styles.fieldGroup}>
                  <Text style={styles.label}>Votre message</Text>
                  <TextInput
                    style={styles.textArea}
                    placeholder="Écrivez ce que vous souhaitez transmettre..."
                    placeholderTextColor={Colors.neutral[400]}
                    value={body}
                    onChangeText={setBody}
                    multiline
                    numberOfLines={8}
                    textAlignVertical="top"
                  />
                  <Text style={styles.charCount}>{body.length} caractères</Text>
                </View>
              )}

              {msgType === 'audio' && (
                <View style={styles.recordZone}>
                  <View style={styles.recordBtn}>
                    <Mic size={32} color={Colors.teal[500]} strokeWidth={1.5} />
                  </View>
                  <Text style={styles.recordText}>Appuyez pour enregistrer</Text>
                  <Text style={styles.recordSub}>Votre enregistrement sera chiffré et stocké en sécurité</Text>
                </View>
              )}
            </>
          )}

          {step === 3 && (
            <>
              <Text style={styles.stepTitle}>À qui est destiné ce message ?</Text>
              <Text style={styles.stepSub}>Sélectionnez un ou plusieurs destinataires parmi vos proches</Text>

              <View style={styles.recipientList}>
                {suggestedRecipients.map((r) => {
                  const isSelected = selectedRecipients.includes(r.id);
                  return (
                    <TouchableOpacity
                      key={r.id}
                      style={[styles.recipientCard, isSelected && styles.recipientCardSelected]}
                      onPress={() => toggleRecipient(r.id)}
                      activeOpacity={0.8}
                    >
                      <View style={[styles.recipientAvatar, isSelected && styles.recipientAvatarSelected]}>
                        <Text style={[styles.recipientAvatarText, isSelected && { color: '#fff' }]}>
                          {r.name.split(' ').map(n => n[0]).join('')}
                        </Text>
                      </View>
                      <View style={styles.recipientInfo}>
                        <Text style={[styles.recipientName, isSelected && styles.recipientNameSelected]}>{r.name}</Text>
                        <Text style={styles.recipientRole}>{r.role}</Text>
                      </View>
                      {isSelected && <CircleCheck size={20} color={Colors.primary[500]} strokeWidth={2} />}
                    </TouchableOpacity>
                  );
                })}
              </View>

              <TouchableOpacity style={styles.addRecipientBtn} activeOpacity={0.8}>
                <Plus size={16} color={Colors.primary[500]} strokeWidth={2} />
                <Text style={styles.addRecipientText}>Ajouter un nouveau destinataire</Text>
              </TouchableOpacity>

              <View style={styles.deliveryNote}>
                <Lock size={14} color={Colors.neutral[400]} strokeWidth={1.5} />
                <Text style={styles.deliveryNoteText}>
                  Ce message sera transmis uniquement après validation par votre personne de confiance, suite à votre décès.
                </Text>
              </View>
            </>
          )}
        </ScrollView>

        <View style={[styles.footer, { paddingBottom: insets.bottom + Spacing.md }]}>
          <Button
            label={step === 3 ? 'Enregistrer le message' : 'Continuer'}
            onPress={handleNext}
            variant="primary"
            size="lg"
            fullWidth
            disabled={!canContinue()}
          />
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.neutral[0] },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[100],
  },
  closeBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: { fontFamily: Fonts.semiBold, fontSize: 16, color: Colors.neutral[800] },
  stepIndicator: { flexDirection: 'row', gap: 6 },
  stepDot: { width: 20, height: 4, borderRadius: 2, backgroundColor: Colors.neutral[200] },
  stepDotActive: { backgroundColor: Colors.primary[500] },

  scroll: { flex: 1 },
  scrollContent: { padding: Spacing.lg, gap: Spacing.lg },

  stepTitle: { fontFamily: Fonts.bold, fontSize: 22, color: Colors.neutral[800], lineHeight: 30 },
  stepSub: { fontFamily: Fonts.regular, fontSize: 14, color: Colors.neutral[500], lineHeight: 20, marginTop: -Spacing.sm },

  typeList: { gap: Spacing.sm },
  typeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.lg,
    padding: Spacing.md,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
  },
  typeCardSelected: { borderColor: Colors.primary[400], backgroundColor: Colors.primary[50] },
  typeIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: Colors.neutral[100],
    alignItems: 'center',
    justifyContent: 'center',
  },
  typeIconWrapSelected: { backgroundColor: Colors.primary[100] },
  typeInfo: { flex: 1 },
  typeLabelRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  typeLabel: { fontFamily: Fonts.semiBold, fontSize: 16, color: Colors.neutral[700] },
  typeLabelSelected: { color: Colors.primary[700] },
  typeDesc: { fontFamily: Fonts.regular, fontSize: 13, color: Colors.neutral[500], marginTop: 2 },
  premiumTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: '#FEF9EC',
    borderRadius: Radius.full,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  premiumTagText: { fontFamily: Fonts.semiBold, fontSize: 10, color: Colors.warning[700] },

  fieldGroup: { gap: Spacing.xs },
  label: { fontFamily: Fonts.medium, fontSize: 13, color: Colors.neutral[700] },
  input: {
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm + 4,
    fontFamily: Fonts.regular,
    fontSize: 15,
    color: Colors.neutral[800],
  },
  textArea: {
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    fontFamily: Fonts.regular,
    fontSize: 15,
    color: Colors.neutral[800],
    minHeight: 180,
    lineHeight: 22,
  },
  charCount: { fontFamily: Fonts.regular, fontSize: 11, color: Colors.neutral[400], alignSelf: 'flex-end' },

  recordZone: {
    alignItems: 'center',
    gap: Spacing.md,
    backgroundColor: Colors.teal[50],
    borderRadius: Radius.xl,
    padding: Spacing.xl,
    borderWidth: 1.5,
    borderColor: Colors.teal[100],
  },
  recordBtn: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.neutral[0],
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.md,
  },
  recordText: { fontFamily: Fonts.semiBold, fontSize: 16, color: Colors.teal[700] },
  recordSub: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.teal[500], textAlign: 'center' },

  recipientList: { gap: Spacing.sm },
  recipientCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.md,
    padding: Spacing.md,
    borderWidth: 1.5,
    borderColor: Colors.neutral[200],
  },
  recipientCardSelected: { borderColor: Colors.primary[400], backgroundColor: Colors.primary[50] },
  recipientAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.neutral[200],
    alignItems: 'center',
    justifyContent: 'center',
  },
  recipientAvatarSelected: { backgroundColor: Colors.primary[500] },
  recipientAvatarText: { fontFamily: Fonts.bold, fontSize: 14, color: Colors.neutral[600] },
  recipientInfo: { flex: 1 },
  recipientName: { fontFamily: Fonts.semiBold, fontSize: 15, color: Colors.neutral[800] },
  recipientNameSelected: { color: Colors.primary[700] },
  recipientRole: { fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500], marginTop: 2 },

  addRecipientBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.primary[200],
    borderStyle: 'dashed',
  },
  addRecipientText: { fontFamily: Fonts.medium, fontSize: 14, color: Colors.primary[500] },

  deliveryNote: {
    flexDirection: 'row',
    gap: Spacing.sm,
    backgroundColor: Colors.neutral[50],
    borderRadius: Radius.sm,
    padding: Spacing.md,
  },
  deliveryNoteText: { flex: 1, fontFamily: Fonts.regular, fontSize: 12, color: Colors.neutral[500], lineHeight: 17 },

  footer: {
    padding: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.neutral[100],
    backgroundColor: Colors.neutral[0],
  },
});
