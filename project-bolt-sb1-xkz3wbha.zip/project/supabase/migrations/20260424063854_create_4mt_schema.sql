/*
  # 4MT - For My Transition: Schema Initial

  ## Nouvelles tables

  ### `profiles`
  Profil utilisateur étendu lié à auth.users
  - `id` (uuid, PK, référence auth.users)
  - `first_name`, `last_name`, `phone`
  - `plan` : 'free' | 'premium'
  - `france_connect` : authentification FranceConnect activée
  - `voice_over`, `captions` : options d'accessibilité

  ### `trusted_persons`
  La personne de confiance désignée par l'utilisateur
  - `id`, `user_id`, `name`, `email`, `phone`, `status`

  ### `messages`
  Messages posthumes (texte, audio, vidéo)
  - `id`, `user_id`, `type`, `title`, `body`, `is_premium`

  ### `message_recipients`
  Destinataires des messages
  - `message_id`, `recipient_name`, `recipient_email`

  ### `funeral_preferences`
  Volontés funéraires de l'utilisateur
  - `id`, `user_id`, `belief`, `ambiance`, `location_type`
  - `celebrant`, `texts`, `music_styles`, `flowers`, `outfit`
  - `objects_in_coffin`, `ai_suggestion`

  ### `questionnaire_responses`
  Réponses au questionnaire IA
  - `id`, `user_id`, `question_id`, `answer`

  ### `organisms`
  Organismes à notifier (banques, assurances, etc.)
  - `id`, `user_id`, `label`, `category`, `contact_name`, `status`

  ### `goods_items`
  Gestion des biens personnels
  - `id`, `user_id`, `category`, `description`, `assignee`, `is_defined`

  ## Sécurité
  - RLS activé sur toutes les tables
  - Accès restreint à l'utilisateur propriétaire uniquement
*/

-- ===============================
-- PROFILES
-- ===============================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name text DEFAULT '',
  last_name text DEFAULT '',
  phone text DEFAULT '',
  plan text DEFAULT 'free' CHECK (plan IN ('free', 'premium')),
  france_connect boolean DEFAULT false,
  voice_over boolean DEFAULT false,
  captions boolean DEFAULT false,
  notifications boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- ===============================
-- TRUSTED PERSONS
-- ===============================
CREATE TABLE IF NOT EXISTS trusted_persons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT '',
  email text DEFAULT '',
  phone text DEFAULT '',
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'declined')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE trusted_persons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own trusted person"
  ON trusted_persons FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own trusted person"
  ON trusted_persons FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own trusted person"
  ON trusted_persons FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own trusted person"
  ON trusted_persons FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ===============================
-- MESSAGES
-- ===============================
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL DEFAULT 'text' CHECK (type IN ('text', 'audio', 'video')),
  title text NOT NULL DEFAULT '',
  body text DEFAULT '',
  media_url text DEFAULT '',
  is_premium boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own messages"
  ON messages FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own messages"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own messages"
  ON messages FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own messages"
  ON messages FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ===============================
-- MESSAGE RECIPIENTS
-- ===============================
CREATE TABLE IF NOT EXISTS message_recipients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  recipient_name text NOT NULL DEFAULT '',
  recipient_email text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE message_recipients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own message recipients"
  ON message_recipients FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own message recipients"
  ON message_recipients FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own message recipients"
  ON message_recipients FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ===============================
-- FUNERAL PREFERENCES
-- ===============================
CREATE TABLE IF NOT EXISTS funeral_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  belief text DEFAULT '',
  ambiance text[] DEFAULT '{}',
  location_type text DEFAULT '',
  celebrant text DEFAULT '',
  texts text DEFAULT '',
  music_styles text[] DEFAULT '{}',
  flowers text DEFAULT '',
  outfit text DEFAULT '',
  objects_in_coffin text DEFAULT '',
  ai_suggestion jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE funeral_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own funeral preferences"
  ON funeral_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own funeral preferences"
  ON funeral_preferences FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own funeral preferences"
  ON funeral_preferences FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ===============================
-- QUESTIONNAIRE RESPONSES
-- ===============================
CREATE TABLE IF NOT EXISTS questionnaire_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  question_id text NOT NULL DEFAULT '',
  answer jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (user_id, question_id)
);

ALTER TABLE questionnaire_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own questionnaire responses"
  ON questionnaire_responses FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own questionnaire responses"
  ON questionnaire_responses FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own questionnaire responses"
  ON questionnaire_responses FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- ===============================
-- ORGANISMS
-- ===============================
CREATE TABLE IF NOT EXISTS organisms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  label text NOT NULL DEFAULT '',
  category text DEFAULT '' CHECK (category IN ('bank', 'insurance', 'energy', 'landlord', 'taxes', 'notaire', 'employer', 'other', '')),
  contact_name text DEFAULT '',
  contact_email text DEFAULT '',
  status text DEFAULT 'todo' CHECK (status IN ('sent', 'pending', 'todo')),
  sent_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE organisms ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own organisms"
  ON organisms FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own organisms"
  ON organisms FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own organisms"
  ON organisms FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own organisms"
  ON organisms FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ===============================
-- GOODS ITEMS
-- ===============================
CREATE TABLE IF NOT EXISTS goods_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category text DEFAULT 'personal' CHECK (category IN ('furniture', 'personal', 'animals', 'appointments', 'other')),
  description text DEFAULT '',
  assignee text DEFAULT '',
  assignee_type text DEFAULT 'person' CHECK (assignee_type IN ('person', 'association', 'other')),
  is_defined boolean DEFAULT false,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE goods_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own goods items"
  ON goods_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own goods items"
  ON goods_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own goods items"
  ON goods_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own goods items"
  ON goods_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- ===============================
-- INDEXES
-- ===============================
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages(user_id);
CREATE INDEX IF NOT EXISTS idx_organisms_user_id ON organisms(user_id);
CREATE INDEX IF NOT EXISTS idx_goods_items_user_id ON goods_items(user_id);
CREATE INDEX IF NOT EXISTS idx_questionnaire_user_id ON questionnaire_responses(user_id);
