export const Colors = {
  primary: {
    50: '#EBF5FB',
    100: '#D0E8F5',
    200: '#A1D2EB',
    300: '#6DB8DF',
    400: '#3A9ED3',
    500: '#1A7DB8',
    600: '#155F8E',
    700: '#104669',
    800: '#0B2E45',
    900: '#061622',
  },
  teal: {
    50: '#E8F8F5',
    100: '#C8EFE8',
    200: '#91DFD1',
    300: '#5ACFBA',
    400: '#29BFA3',
    500: '#1FA08A',
    600: '#177A69',
    700: '#0F5549',
    800: '#083029',
    900: '#041510',
  },
  sage: {
    50: '#F0F7F0',
    100: '#DCF0DC',
    200: '#B8E1B8',
    300: '#94D294',
    400: '#70C370',
    500: '#52A852',
    600: '#3E7E3E',
    700: '#2A542A',
    800: '#162A16',
    900: '#0B150B',
  },
  neutral: {
    0: '#FFFFFF',
    50: '#F8FAFB',
    100: '#F1F4F6',
    200: '#E2E8EC',
    300: '#C8D3D9',
    400: '#9AADB8',
    500: '#6B8494',
    600: '#4A6070',
    700: '#334455',
    800: '#1E2C38',
    900: '#0D1620',
  },
  success: {
    50: '#EDFAF3',
    500: '#22C55E',
    700: '#15803D',
  },
  warning: {
    50: '#FEF9EC',
    500: '#F59E0B',
    700: '#B45309',
  },
  error: {
    50: '#FEF2F2',
    500: '#EF4444',
    700: '#B91C1C',
  },
};

export const Fonts = {
  regular: 'Inter-Regular',
  medium: 'Inter-Medium',
  semiBold: 'Inter-SemiBold',
  bold: 'Inter-Bold',
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
  xxxl: 64,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
};

export const Shadow = {
  sm: {
    shadowColor: Colors.neutral[900],
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  md: {
    shadowColor: Colors.neutral[900],
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 4,
  },
  lg: {
    shadowColor: Colors.neutral[900],
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.14,
    shadowRadius: 24,
    elevation: 8,
  },
};
