import { createContext, useContext, useState, ReactNode } from 'react';

export type DemoStep = 'idle' | 'declaration' | 'mairie' | 'acte' | 'activation' | 'active';

interface DemoContextType {
  isDemo: boolean;
  step: DemoStep;
  startDemo: () => void;
  advanceStep: () => void;
  resetDemo: () => void;
}

const DemoContext = createContext<DemoContextType>({
  isDemo: false,
  step: 'idle',
  startDemo: () => {},
  advanceStep: () => {},
  resetDemo: () => {},
});

const STEP_ORDER: DemoStep[] = ['idle', 'declaration', 'mairie', 'acte', 'activation', 'active'];

export function DemoProvider({ children }: { children: ReactNode }) {
  const [step, setStep] = useState<DemoStep>('idle');

  const startDemo = () => setStep('declaration');

  const advanceStep = () => {
    setStep(current => {
      const idx = STEP_ORDER.indexOf(current);
      return idx < STEP_ORDER.length - 1 ? STEP_ORDER[idx + 1] : current;
    });
  };

  const resetDemo = () => setStep('idle');

  return (
    <DemoContext.Provider value={{ isDemo: step !== 'idle', step, startDemo, advanceStep, resetDemo }}>
      {children}
    </DemoContext.Provider>
  );
}

export function useDemo() {
  return useContext(DemoContext);
}
